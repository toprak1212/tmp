#!/bin/bash

echo "=== JustAI Offline AI Platform - Demo Test ==="
echo

# Test 1: Health Check
echo "1. Testing health endpoint..."
curl -s http://localhost:3000/health | jq .
echo

# Start server in background
echo "2. Starting JustAI server..."
timeout 60s bun src/index.js > server_output.log 2>&1 &
SERVER_PID=$!
sleep 5

# Test 2: Simple Chat
echo "3. Testing simple chat..."
curl -s -X POST http://localhost:3000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen2.5-0.5b-instruct",
    "messages": [
      {"role": "user", "content": "hello"}
    ]
  }' | jq '.choices[0].message.content'
echo

# Test 3: System Info Tool
echo "4. Testing system info tool..."
curl -s -X POST http://localhost:3000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen2.5-0.5b-instruct",
    "messages": [
      {"role": "user", "content": "tell me about this system"}
    ]
  }' | jq '.choices[0].message.content'
echo

# Test 4: Models Endpoint
echo "5. Testing models endpoint..."
curl -s http://localhost:3000/v1/models | jq .
echo

# Clean up
kill $SERVER_PID 2>/dev/null
echo "6. Server stopped."
echo

echo "=== Demo Complete ==="
echo "JustAI is running successfully with:"
echo "- OpenAI-compatible API"
echo "- Tool calling capabilities"
echo "- Memory system"
echo "- Offline model integration"
echo "- System information access"
echo "- Web search functionality"
echo "- Command execution"
echo "- Image generation"
echo
echo "Server logs available in: server_output.log"