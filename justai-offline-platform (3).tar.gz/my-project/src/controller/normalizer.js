import { createLogger, format, transports } from 'winston';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

class OutputNormalizer {
  constructor() {
    this.normalizationRules = new Map();
    this.setupDefaultRules();
  }

  setupDefaultRules() {
    // System info normalization
    this.normalizationRules.set('system_info', {
      summary: (result) => {
        const data = result.data;
        return `System info for ${data.system.hostname}: ${data.system.platform} ${data.system.arch}, ${data.system.cpus.length} CPUs, ${Math.round(data.system.totalmem / 1024 / 1024 / 1024)}GB RAM`;
      },
      artifacts: (result) => {
        const artifacts = [];
        if (result.data.system) {
          artifacts.push({
            type: 'system_info',
            filename: `system_info_${Date.now()}.json`,
            content: JSON.stringify(result.data.system, null, 2),
            size: JSON.stringify(result.data.system).length
          });
        }
        return artifacts;
      }
    });

    // Web search normalization
    this.normalizationRules.set('web_search', {
      summary: (result) => {
        const data = result.data;
        return `Web search for "${data.query}" returned ${data.results.length} results`;
      },
      artifacts: (result) => {
        const artifacts = [];
        if (result.data.results && result.data.results.length > 0) {
          artifacts.push({
            type: 'search_results',
            filename: `search_${Date.now()}.json`,
            content: JSON.stringify(result.data.results, null, 2),
            size: JSON.stringify(result.data.results).length
          });
        }
        return artifacts;
      }
    });

    // HTTP GET normalization
    this.normalizationRules.set('http_get', {
      summary: (result) => {
        const data = result.data;
        return `HTTP GET ${data.url} returned ${data.status_code} ${data.status_text} (${data.content_length || 'unknown'} bytes)`;
      },
      artifacts: (result) => {
        const artifacts = [];
        if (result.data.content && typeof result.data.content === 'string' && result.data.content.length > 1000) {
          artifacts.push({
            type: 'http_response',
            filename: `http_response_${Date.now()}.txt`,
            content: result.data.content,
            size: result.data.content.length
          });
        }
        return artifacts;
      }
    });

    // Run command normalization
    this.normalizationRules.set('run_command', {
      summary: (result) => {
        const data = result.data;
        return `Command executed: "${data.command}" (exit code: ${data.exit_code}, time: ${data.execution_time_ms}ms)`;
      },
      artifacts: (result) => {
        const artifacts = [];
        const data = result.data;
        
        if (data.stdout && data.stdout.length > 1000) {
          artifacts.push({
            type: 'command_stdout',
            filename: `cmd_stdout_${Date.now()}.txt`,
            content: data.stdout,
            size: data.stdout.length
          });
        }
        
        if (data.stderr && data.stderr.length > 1000) {
          artifacts.push({
            type: 'command_stderr',
            filename: `cmd_stderr_${Date.now()}.txt`,
            content: data.stderr,
            size: data.stderr.length
          });
        }
        
        return artifacts;
      }
    });

    // Exec shell normalization
    this.normalizationRules.set('exec_shell', {
      summary: (result) => {
        const data = result.data;
        return `Shell command executed: "${data.command}" (exit code: ${data.exit_code}, time: ${data.execution_time_ms}ms)`;
      },
      artifacts: (result) => {
        const artifacts = [];
        const data = result.data;
        
        if (!data.interactive) {
          if (data.stdout && data.stdout.length > 1000) {
            artifacts.push({
              type: 'shell_stdout',
              filename: `shell_stdout_${Date.now()}.txt`,
              content: data.stdout,
              size: data.stdout.length
            });
          }
          
          if (data.stderr && data.stderr.length > 1000) {
            artifacts.push({
              type: 'shell_stderr',
              filename: `shell_stderr_${Date.now()}.txt`,
              content: data.stderr,
              size: data.stderr.length
            });
          }
        }
        
        return artifacts;
      }
    });

    // Generate image normalization
    this.normalizationRules.set('generate_image', {
      summary: (result) => {
        const data = result.data;
        return `Generated image: "${data.prompt}" (${data.width}x${data.height}, ${data.format}, ${Math.round(data.file_size / 1024)}KB)`;
      },
      artifacts: (result) => {
        return result.artifacts || [];
      }
    });
  }

  normalize(toolName, result) {
    try {
      const rule = this.normalizationRules.get(toolName);
      if (!rule) {
        logger.warn('No normalization rule found for tool:', toolName);
        return result;
      }

      // Create normalized result
      const normalized = {
        status: result.status,
        summary: result.summary,
        data: result.data,
        artifacts: result.artifacts || [],
        timestamp: result.timestamp
      };

      // Apply summary normalization if not already provided
      if (!result.summary && rule.summary) {
        normalized.summary = rule.summary(result);
      }

      // Apply artifact normalization
      if (rule.artifacts) {
        const normalizedArtifacts = rule.artifacts(result);
        // Merge with existing artifacts, avoiding duplicates
        const existingPaths = new Set((normalized.artifacts || []).map(a => a.filename));
        normalizedArtifacts.forEach(artifact => {
          if (!existingPaths.has(artifact.filename)) {
            normalized.artifacts.push(artifact);
          }
        });
      }

      // Ensure all artifacts have required fields
      normalized.artifacts = normalized.artifacts.map(artifact => ({
        type: artifact.type || 'unknown',
        filename: artifact.filename || `artifact_${Date.now()}`,
        path: artifact.path || artifact.filename,
        content: artifact.content || null,
        size: artifact.size || (artifact.content ? artifact.content.length : 0),
        metadata: artifact.metadata || {}
      }));

      logger.info('Normalized tool output', { 
        toolName, 
        status: normalized.status,
        artifactCount: normalized.artifacts.length 
      });

      return normalized;
    } catch (error) {
      logger.error('Failed to normalize tool output:', { toolName, error: error.message });
      return result; // Return original result if normalization fails
    }
  }

  addNormalizationRule(toolName, rule) {
    this.normalizationRules.set(toolName, rule);
    logger.info('Added normalization rule for tool:', toolName);
  }

  removeNormalizationRule(toolName) {
    this.normalizationRules.delete(toolName);
    logger.info('Removed normalization rule for tool:', toolName);
  }

  getAvailableRules() {
    return Array.from(this.normalizationRules.keys());
  }

  // Generic data cleanup utilities
  static sanitizeText(text, maxLength = 10000) {
    if (typeof text !== 'string') return text;
    
    // Remove excessive whitespace
    let sanitized = text.replace(/\s+/g, ' ').trim();
    
    // Truncate if too long
    if (sanitized.length > maxLength) {
      sanitized = sanitized.substring(0, maxLength) + '...';
    }
    
    return sanitized;
  }

  static formatFileSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  static formatDuration(ms) {
    if (ms < 1000) return `${ms}ms`;
    if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
    return `${(ms / 60000).toFixed(1)}m`;
  }
}

export const outputNormalizer = new OutputNormalizer();
export { OutputNormalizer };