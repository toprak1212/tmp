import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { createLogger, transports, format } from 'winston';
import { apiRouter } from './server/router.js';
import { initializeMemory } from './memory/database.js';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.errors({ stack: true }),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() }),
    new transports.File({ filename: 'logs/error.log', level: 'error' }),
    new transports.File({ filename: 'logs/combined.log' })
  ]
});

const app = express();
const PORT = 3000;

// Middleware - Removed helmet to avoid CSP restrictions
// app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Serve static files from public directory
app.use(express.static(path.join(__dirname, '../public')));

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// API routes
app.use('/v1', apiRouter);

// Serve index.html for root route
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
  logger.error('Unhandled error:', err);
  res.status(500).json({
    error: {
      message: 'Internal server error',
      type: 'internal_error'
    }
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    error: {
      message: 'Not found',
      type: 'not_found'
    }
  });
});

async function startServer() {
  try {
    // Initialize memory system
    await initializeMemory();
    logger.info('Memory system initialized');

    // Start server
    app.listen(PORT, '0.0.0.0', () => {
      logger.info(`JustAI server running on http://0.0.0.0:${PORT}`);
      logger.info(`Health check: http://0.0.0.0:${PORT}/health`);
      logger.info(`API endpoint: http://0.0.0.0:${PORT}/v1/chat/completions`);
      logger.info(`Web interface: http://0.0.0.0:${PORT}/`);
    });
  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Handle graceful shutdown
process.on('SIGINT', () => {
  logger.info('Received SIGINT, shutting down gracefully...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  logger.info('Received SIGTERM, shutting down gracefully...');
  process.exit(0);
});

startServer();