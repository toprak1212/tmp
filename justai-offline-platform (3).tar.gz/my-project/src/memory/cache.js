import { createLogger, format, transports } from 'winston';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

class MemoryCache {
  constructor(maxSize = 1000, ttlMs = 300000) { // 5 minutes default TTL
    this.cache = new Map();
    this.maxSize = maxSize;
    this.ttlMs = ttlMs;
    this.stats = {
      hits: 0,
      misses: 0,
      sets: 0,
      evictions: 0
    };
  }

  set(key, value, customTtl = null) {
    // Check if we need to evict
    if (this.cache.size >= this.maxSize && !this.cache.has(key)) {
      this.evictOldest();
    }

    const ttl = customTtl || this.ttlMs;
    const expiry = Date.now() + ttl;

    this.cache.set(key, {
      value: value,
      expiry: expiry,
      created: Date.now(),
      accessed: Date.now(),
      accessCount: 1
    });

    this.stats.sets++;
    
    logger.debug('Cache entry set', { key, ttl, size: this.cache.size });
  }

  get(key) {
    const entry = this.cache.get(key);
    
    if (!entry) {
      this.stats.misses++;
      return null;
    }

    // Check if expired
    if (Date.now() > entry.expiry) {
      this.cache.delete(key);
      this.stats.misses++;
      return null;
    }

    // Update access info
    entry.accessed = Date.now();
    entry.accessCount++;
    this.stats.hits++;

    logger.debug('Cache entry hit', { key, accessCount: entry.accessCount });
    
    return entry.value;
  }

  has(key) {
    const entry = this.cache.get(key);
    if (!entry) return false;
    
    if (Date.now() > entry.expiry) {
      this.cache.delete(key);
      return false;
    }
    
    return true;
  }

  delete(key) {
    return this.cache.delete(key);
  }

  clear() {
    const size = this.cache.size;
    this.cache.clear();
    this.stats = {
      hits: 0,
      misses: 0,
      sets: 0,
      evictions: 0
    };
    
    logger.info('Cache cleared', { previousSize: size });
  }

  evictOldest() {
    let oldestKey = null;
    let oldestTime = Date.now();

    for (const [key, entry] of this.cache.entries()) {
      if (entry.accessed < oldestTime) {
        oldestTime = entry.accessed;
        oldestKey = key;
      }
    }

    if (oldestKey) {
      this.cache.delete(oldestKey);
      this.stats.evictions++;
      logger.debug('Cache entry evicted', { key: oldestKey });
    }
  }

  cleanup() {
    const now = Date.now();
    let cleaned = 0;

    for (const [key, entry] of this.cache.entries()) {
      if (now > entry.expiry) {
        this.cache.delete(key);
        cleaned++;
      }
    }

    logger.debug('Cache cleanup completed', { cleaned, remaining: this.cache.size });
    return cleaned;
  }

  getStats() {
    const total = this.stats.hits + this.stats.misses;
    return {
      ...this.stats,
      size: this.cache.size,
      maxSize: this.maxSize,
      hitRate: total > 0 ? (this.stats.hits / total * 100).toFixed(2) + '%' : '0%',
      memoryUsage: this.getMemoryUsage()
    };
  }

  getMemoryUsage() {
    let totalSize = 0;
    for (const [key, entry] of this.cache.entries()) {
      totalSize += this.estimateObjectSize(key) + this.estimateObjectSize(entry);
    }
    return this.formatBytes(totalSize);
  }

  estimateObjectSize(obj) {
    try {
      return JSON.stringify(obj).length * 2; // Rough estimate
    } catch (error) {
      return 100; // Default estimate
    }
  }

  formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  getEntries() {
    const entries = [];
    const now = Date.now();

    for (const [key, entry] of this.cache.entries()) {
      entries.push({
        key: key,
        created: entry.created,
        accessed: entry.accessed,
        accessCount: entry.accessCount,
        ttl: Math.max(0, entry.expiry - now),
        size: this.estimateObjectSize(entry.value)
      });
    }

    return entries.sort((a, b) => b.accessed - a.accessed);
  }

  // Start automatic cleanup
  startAutoCleanup(intervalMs = 60000) { // 1 minute default
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }

    this.cleanupInterval = setInterval(() => {
      this.cleanup();
    }, intervalMs);

    logger.info('Auto cleanup started', { intervalMs });
  }

  stopAutoCleanup() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
      logger.info('Auto cleanup stopped');
    }
  }
}

// Create global cache instances
export const responseCache = new MemoryCache(500, 300000); // 500 entries, 5 minutes
export const toolResultCache = new MemoryCache(200, 600000); // 200 entries, 10 minutes
export const memoryCache = new MemoryCache(1000, 180000); // 1000 entries, 3 minutes

// Start auto cleanup
responseCache.startAutoCleanup();
toolResultCache.startAutoCleanup();
memoryCache.startAutoCleanup();

export { MemoryCache };