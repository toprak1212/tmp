import { createLogger, format, transports } from 'winston';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

// In-memory database replacement
let memoryData = [];
let toolResultsData = [];
let conversationsData = [];
let nextId = 1;

export async function initializeMemory() {
  logger.info('Using in-memory database (SQLite bypassed)');
  return Promise.resolve();
}

export function getDatabase() {
  // Return a mock database object
  return {
    memory: memoryData,
    toolResults: toolResultsData,
    conversations: conversationsData
  };
}

// Memory operations
export async function storeMemory(key, value, type = 'fact') {
  const existingIndex = memoryData.findIndex(item => item.key === key);
  const memoryItem = {
    id: existingIndex !== -1 ? memoryData[existingIndex].id : nextId++,
    key,
    value,
    type,
    created_at: existingIndex !== -1 ? memoryData[existingIndex].created_at : new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  if (existingIndex !== -1) {
    memoryData[existingIndex] = memoryItem;
  } else {
    memoryData.push(memoryItem);
  }

  return memoryItem;
}

export async function getMemory(key) {
  return memoryData.find(item => item.key === key) || null;
}

export async function getAllMemories() {
  return [...memoryData].sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
}

// Tool result caching
export async function cacheToolResult(toolName, inputHash, result, summary) {
  const existingIndex = toolResultsData.findIndex(item => 
    item.tool_name === toolName && item.input_hash === inputHash
  );

  const toolResult = {
    id: existingIndex !== -1 ? toolResultsData[existingIndex].id : nextId++,
    tool_name: toolName,
    input_hash: inputHash,
    result: JSON.stringify(result),
    summary,
    created_at: existingIndex !== -1 ? toolResultsData[existingIndex].created_at : new Date().toISOString()
  };

  if (existingIndex !== -1) {
    toolResultsData[existingIndex] = toolResult;
  } else {
    toolResultsData.push(toolResult);
  }

  return { ...toolResult, result };
}

export async function getCachedToolResult(toolName, inputHash) {
  const cached = toolResultsData.find(item => 
    item.tool_name === toolName && item.input_hash === inputHash
  );
  
  if (cached) {
    return { ...cached, result: JSON.parse(cached.result) };
  }
  
  return null;
}