import { createLogger, format, transports } from 'winston';
import { memoryCache } from './cache.js';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

class Summarizer {
  constructor() {
    this.summarizationRules = new Map();
    this.setupDefaultRules();
  }

  setupDefaultRules() {
    // System info summarization
    this.summarizationRules.set('system_info', (result) => {
      const data = result.data;
      return {
        key: 'system_info',
        value: `System: ${data.system.hostname} (${data.system.platform} ${data.system.arch}), ${data.system.cpus.length} CPUs, ${Math.round(data.system.totalmem / 1024 / 1024 / 1024)}GB RAM, uptime: ${Math.round(data.system.uptime / 3600)}h`,
        type: 'system_fact',
        priority: 'medium',
        expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 hours
      };
    });

    // Web search summarization
    this.summarizationRules.set('web_search', (result) => {
      const data = result.data;
      const topResults = data.results.slice(0, 3);
      const summary = topResults.map(r => `- ${r.title}: ${r.snippet.substring(0, 100)}...`).join('\n');
      
      return {
        key: `search_${data.query.substring(0, 20)}`,
        value: `Search for "${data.query}" found ${data.results.length} results. Top results:\n${summary}`,
        type: 'search_result',
        priority: 'low',
        expires_at: new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString() // 6 hours
      };
    });

    // Command execution summarization
    this.summarizationRules.set('run_command', (result) => {
      const data = result.data;
      const success = data.exit_code === 0;
      const output = data.stdout ? data.stdout.substring(0, 200) + (data.stdout.length > 200 ? '...' : '') : '';
      
      return {
        key: `cmd_${data.command.substring(0, 20)}`,
        value: `Command "${data.command}" ${success ? 'succeeded' : 'failed'} (exit code: ${data.exit_code})${output ? '. Output: ' + output : ''}`,
        type: 'command_result',
        priority: 'low',
        expires_at: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString() // 2 hours
      };
    });

    // HTTP request summarization
    this.summarizationRules.set('http_get', (result) => {
      const data = result.data;
      const success = data.status_code >= 200 && data.status_code < 300;
      
      return {
        key: `http_${new URL(data.url).hostname}`,
        value: `HTTP GET ${data.url} returned ${data.status_code} ${data.status_text} (${Math.round((data.content_length || 0) / 1024)}KB)`,
        type: 'http_result',
        priority: 'low',
        expires_at: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString() // 4 hours
      };
    });

    // Image generation summarization
    this.summarizationRules.set('generate_image', (result) => {
      const data = result.data;
      
      return {
        key: `image_${data.prompt.substring(0, 20)}`,
        value: `Generated image: "${data.prompt}" (${data.width}x${data.height}, ${Math.round(data.file_size / 1024)}KB)`,
        type: 'creation_result',
        priority: 'medium',
        expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // 7 days
      };
    });
  }

  async summarizeToolResult(toolName, result) {
    try {
      const rule = this.summarizationRules.get(toolName);
      if (!rule) {
        logger.warn('No summarization rule found for tool:', toolName);
        return null;
      }

      if (result.status !== 'success') {
        logger.debug('Skipping summarization for failed result', { toolName, status: result.status });
        return null;
      }

      const summary = rule(result);
      
      // Add metadata
      summary.created_at = new Date().toISOString();
      summary.tool_name = toolName;
      summary.result_id = result.execution?.id || 'unknown';
      
      logger.info('Created summary', { 
        toolName, 
        summaryKey: summary.key,
        type: summary.type 
      });

      return summary;
    } catch (error) {
      logger.error('Failed to summarize tool result:', { toolName, error: error.message });
      return null;
    }
  }

  async summarizeConversation(messages, maxMessages = 10) {
    try {
      const recentMessages = messages.slice(-maxMessages);
      const userMessages = recentMessages.filter(m => m.role === 'user');
      const assistantMessages = recentMessages.filter(m => m.role === 'assistant');
      
      const summary = {
        key: `conversation_${Date.now()}`,
        value: `Recent conversation: ${userMessages.length} user messages, ${assistantMessages.length} assistant responses. Last topic: ${userMessages[userMessages.length - 1]?.content?.substring(0, 100) || 'Unknown'}`,
        type: 'conversation_summary',
        priority: 'low',
        expires_at: new Date(Date.now() + 30 * 60 * 1000).toISOString() // 30 minutes
      };

      summary.created_at = new Date().toISOString();
      summary.message_count = messages.length;
      summary.recent_message_count = recentMessages.length;
      
      return summary;
    } catch (error) {
      logger.error('Failed to summarize conversation:', error);
      return null;
    }
  }

  async extractKeyFacts(text) {
    try {
      const facts = [];
      
      // Extract patterns that look like facts
      const patterns = [
        /(\w+)\s+is\s+([^,.!?]+)/gi,
        /(\w+)\s+are\s+([^,.!?]+)/gi,
        /(\w+)\s+has\s+([^,.!?]+)/gi,
        /(\w+)\s+was\s+([^,.!?]+)/gi,
        /(\w+)\s+were\s+([^,.!?]+)/gi
      ];

      for (const pattern of patterns) {
        let match;
        while ((match = pattern.exec(text)) !== null) {
          const fact = `${match[1]} ${match[0].split(/\s+/).slice(1).join(' ')}`;
          
          if (fact.length > 10 && fact.length < 200) {
            facts.push({
              key: `fact_${match[1].toLowerCase()}_${Date.now()}`,
              value: fact,
              type: 'extracted_fact',
              priority: 'low',
              expires_at: new Date(Date.now() + 60 * 60 * 1000).toISOString() // 1 hour
            });
          }
        }
      }

      return facts.slice(0, 5); // Limit to 5 facts per extraction
    } catch (error) {
      logger.error('Failed to extract key facts:', error);
      return [];
    }
  }

  async createSummaryDigest(memories, maxItems = 20) {
    try {
      const validMemories = memories.filter(m => 
        m.type !== 'conversation_summary' && 
        m.value && 
        m.value.length > 10
      );

      const grouped = {};
      validMemories.forEach(memory => {
        if (!grouped[memory.type]) {
          grouped[memory.type] = [];
        }
        grouped[memory.type].push(memory);
      });

      const digest = {
        key: `digest_${Date.now()}`,
        value: this.formatDigest(grouped),
        type: 'memory_digest',
        priority: 'medium',
        expires_at: new Date(Date.now() + 15 * 60 * 1000).toISOString() // 15 minutes
      };

      digest.created_at = new Date().toISOString();
      digest.item_count = validMemories.length;
      digest.type_counts = Object.keys(grouped).reduce((acc, type) => {
        acc[type] = grouped[type].length;
        return acc;
      }, {});

      return digest;
    } catch (error) {
      logger.error('Failed to create summary digest:', error);
      return null;
    }
  }

  formatDigest(groupedMemories) {
    const lines = ['Memory Summary Digest:'];
    
    for (const [type, memories] of Object.entries(groupedMemories)) {
      lines.push(`\n${type.toUpperCase()} (${memories.length}):`);
      
      memories.slice(0, 3).forEach(memory => {
        const preview = memory.value.substring(0, 80) + (memory.value.length > 80 ? '...' : '');
        lines.push(`  - ${preview}`);
      });
      
      if (memories.length > 3) {
        lines.push(`  ... and ${memories.length - 3} more`);
      }
    }
    
    return lines.join('\n');
  }

  addSummarizationRule(toolName, rule) {
    this.summarizationRules.set(toolName, rule);
    logger.info('Added summarization rule for tool:', toolName);
  }

  removeSummarizationRule(toolName) {
    this.summarizationRules.delete(toolName);
    logger.info('Removed summarization rule for tool:', toolName);
  }

  getAvailableRules() {
    return Array.from(this.summarizationRules.keys());
  }

  async cleanupExpiredMemories(memories) {
    const now = new Date();
    const expired = [];
    const valid = [];

    memories.forEach(memory => {
      if (memory.expires_at && new Date(memory.expires_at) < now) {
        expired.push(memory);
      } else {
        valid.push(memory);
      }
    });

    logger.info('Memory cleanup completed', {
      total: memories.length,
      expired: expired.length,
      remaining: valid.length
    });

    return { expired, valid };
  }

  async prioritizeMemories(memories, maxCount = 100) {
    const priorityOrder = {
      'high': 3,
      'medium': 2,
      'low': 1
    };

    return memories
      .sort((a, b) => {
        const aPriority = priorityOrder[a.priority] || 0;
        const bPriority = priorityOrder[b.priority] || 0;
        
        if (aPriority !== bPriority) {
          return bPriority - aPriority;
        }
        
        // If same priority, sort by creation time (newest first)
        return new Date(b.created_at) - new Date(a.created_at);
      })
      .slice(0, maxCount);
  }
}

export const summarizer = new Summarizer();
export { Summarizer };