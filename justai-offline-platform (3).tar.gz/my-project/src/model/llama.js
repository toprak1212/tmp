import { createLogger, format, transports } from 'winston';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

let modelInitialized = false;

export async function initializeModel() {
  try {
    logger.info('Initializing LLaMA model...');
    
    // For now, use fallback approach with proper error handling
    // In production, you would integrate with actual node-llama-cpp
    const modelPath = path.join(__dirname, '../../models/qwen2.5-0.5b-instruct-q4_k_m.gguf');
    
    // Check if model file exists
    try {
      const fs = await import('fs/promises');
      await fs.access(modelPath);
      logger.info('Model file found at:', modelPath);
    } catch (error) {
      throw new Error(`Model file not found at: ${modelPath}`);
    }

    modelInitialized = true;
    logger.info('Model initialized successfully (enhanced fallback mode)');
    return true;
  } catch (error) {
    logger.error('Failed to initialize model:', error);
    throw error;
  }
}

export async function generateCompletion(messages, options = {}) {
  if (!modelInitialized) {
    throw new Error('Model not initialized. Call initializeModel() first.');
  }

  try {
    logger.info('Generating completion...', { 
      messageCount: messages.length,
      maxTokens: options.maxTokens || 4096
    });

    // Enhanced fallback response generation with better tool detection
    const completion = generateEnhancedFallbackResponse(messages);

    logger.info('Completion generated', { 
      responseLength: completion.length,
      maxTokens: options.maxTokens || 4096
    });

    // Ensure we don't exceed max tokens
    const maxTokens = options.maxTokens || 4096;
    if (completion.length > maxTokens) {
      logger.warn('Response truncated due to token limit', { 
        originalLength: completion.length,
        maxTokens: maxTokens 
      });
      return completion.substring(0, maxTokens);
    }

    return completion.trim();
  } catch (error) {
    logger.error('Failed to generate completion:', error);
    throw error;
  }
}

function generateEnhancedFallbackResponse(messages) {
  const lastUserMessage = messages.filter(m => m.role === 'user').pop();
  
  // Check if we already have tool results in conversation
  const hasToolResults = messages.some(m => m.role === 'tool');
  
  if (lastUserMessage && !hasToolResults) {
    const content = lastUserMessage.content.toLowerCase();
    
    // Enhanced tool request detection - more specific patterns
    if (isToolRequest(content)) {
      return generateToolCall(lastUserMessage.content, content);
    }
  }

  // If we have tool results, synthesize a response
  if (hasToolResults) {
    const toolResults = messages.filter(m => m.role === 'tool');
    if (toolResults.length > 0) {
      const result = toolResults[0].content;
      // Return the full tool result without truncation
      return `I've successfully executed your request. Here are the results:\n\n${result}`;
    }
  }

  // Natural conversation response
  return generateNaturalChatResponse(lastUserMessage?.content || '', messages);
}

function isToolRequest(content) {
  // Check for command prefixes instead of natural language detection
  const trimmedContent = content.trim();
  const lowerContent = trimmedContent.toLowerCase();
  
  // Command prefix patterns - must be exact match at start
  if (trimmedContent === '/info' || trimmedContent.startsWith('/info ') || lowerContent.includes('system info') || lowerContent.includes('computer') || lowerContent.includes('tell me about this system')) {
    return true;
  }
  
  if (trimmedContent === '/search' || trimmedContent.startsWith('/search ') || lowerContent.includes('search') || lowerContent.includes('look up')) {
    return true;
  }
  
  if (trimmedContent === '/cmd' || trimmedContent.startsWith('/cmd ') || lowerContent.includes('run') || lowerContent.includes('execute') || lowerContent.includes('command')) {
    return true;
  }
  
  if (trimmedContent === '/image' || trimmedContent.startsWith('/image ') || lowerContent.includes('image') || lowerContent.includes('picture') || lowerContent.includes('generate')) {
    return true;
  }
  
  if (trimmedContent === '/get' || trimmedContent.startsWith('/get ') || lowerContent.includes('http get') || lowerContent.includes('fetch')) {
    return true;
  }
  
  // Fallback to natural language for backward compatibility
  const toolPatterns = [
    /(?:system info|computer|tell me about this system)/i,
    /(?:search|look up)/i,
    /(?:run command|execute|command:)/i,
    /(?:image|picture|generate)/i
  ];
  
  return toolPatterns.some(pattern => pattern.test(content));
}

function generateToolCall(originalContent, lowerContent) {
  const trimmedContent = originalContent.trim();
  
  // System info tool (/info)
  if (trimmedContent === '/info' || trimmedContent.startsWith('/info ') || lowerContent.includes('system info') || lowerContent.includes('computer') || lowerContent.includes('tell me about this system')) {
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function",
        function: {
          name: "system_info",
          arguments: JSON.stringify({ include_network: false, include_processes: false })
        }
      }]
    });
  }
  
  // Web search tool (/search)
  if (trimmedContent === '/search' || trimmedContent.startsWith('/search ') || lowerContent.includes('search') || lowerContent.includes('look up')) {
    const query = trimmedContent.startsWith('/search ') ? trimmedContent.substring(8).trim() : originalContent;
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function", 
        function: {
          name: "web_search",
          arguments: JSON.stringify({ query: query, num_results: 5 })
        }
      }]
    });
  }
  
  // Command execution tool (/cmd)
  if (trimmedContent === '/cmd' || trimmedContent.startsWith('/cmd ') || lowerContent.includes('run') || lowerContent.includes('execute') || lowerContent.includes('command')) {
    let command = "echo 'Hello from JustAI!'";
    
    if (trimmedContent.startsWith('/cmd ')) {
      command = trimmedContent.substring(5).trim();
    } else if (lowerContent.includes('run command:')) {
      const commandMatch = originalContent.match(/(?:run command|execute|command):\s*(.+?)(?:\n|$)/i);
      if (commandMatch) {
        command = commandMatch[1].trim();
      }
    } else if (lowerContent.includes('echo')) {
      const echoMatch = originalContent.match(/echo\s+(.+)/i);
      if (echoMatch) {
        command = `echo ${echoMatch[1]}`;
      }
    }
    
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function",
        function: {
          name: "run_command",
          arguments: JSON.stringify({ command: command, capture_output: true })
        }
      }]
    });
  }
  
  // HTTP GET tool (/get)
  if (trimmedContent === '/get' || trimmedContent.startsWith('/get ') || lowerContent.includes('http get') || lowerContent.includes('fetch')) {
    let url = "";
    if (trimmedContent.startsWith('/get ')) {
      url = trimmedContent.substring(5).trim();
    }
    
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function",
        function: {
          name: "http_get",
          arguments: JSON.stringify({ url: url })
        }
      }]
    });
  }
  
  // Image generation tool (/image)
  if (trimmedContent === '/image' || trimmedContent.startsWith('/image ') || lowerContent.includes('image') || lowerContent.includes('picture') || lowerContent.includes('generate')) {
    const prompt = trimmedContent.startsWith('/image ') ? trimmedContent.substring(7).trim() : originalContent;
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function",
        function: {
          name: "generate_image",
          arguments: JSON.stringify({ prompt: prompt, width: 512, height: 512, format: 'png', method: 'web' })
        }
      }]
    });
  }
  
  return null;
}

function generateNaturalChatResponse(userMessage, conversationHistory) {
  // Get conversation context
  const recentMessages = conversationHistory.slice(-5);
  const messageCount = conversationHistory.filter(m => m.role === 'user').length;
  
  // Check for command prefixes FIRST (highest priority)
  if (isToolRequest(userMessage)) {
    return generateToolCall(userMessage, userMessage);
  }
  
  // Personal questions (highest priority)
  if (isPersonalQuestion(userMessage)) {
    return generatePersonalResponse(userMessage);
  }
  
  // Greeting patterns
  if (isGreeting(userMessage)) {
    return generateGreetingResponse(messageCount);
  }
  
  // Help request
  if (isHelpRequest(userMessage)) {
    return generateHelpResponse();
  }
  
  // Question patterns
  if (isQuestion(userMessage)) {
    return generateQuestionResponse(userMessage, recentMessages);
  }
  
  // Casual conversation
  if (isCasualConversation(userMessage)) {
    return generateCasualResponse(userMessage, messageCount);
  }
  
  // Default conversational response
  return generateDefaultConversationalResponse(userMessage, messageCount);
}

function isGreeting(message) {
  const greetings = [
    /^(hi|hello|hey|good morning|good afternoon|good evening)/i,
    /^(how are you|how do you do)/i,
    /^(what's up|sup)/i
  ];
  return greetings.some(pattern => pattern.test(message.trim()));
}

function isQuestion(message) {
  return message.includes('?') || 
         /^(what|where|when|why|how|who|which|can|could|would|should|is|are|do|does)/i.test(message.trim());
}

function isPersonalQuestion(message) {
  const personalPatterns = [
    /who are you|what are you|what's your name/i,
    /how old are you|when were you created/i,
    /what can you do|what are your capabilities/i,
    /do you have feelings|are you real/i
  ];
  return personalPatterns.some(pattern => pattern.test(message));
}

function isHelpRequest(message) {
  const helpPatterns = [
    /^(help|what can you do|what are your capabilities|what are your features)/i,
    /^(tell me about your tools|show me your tools)/i
  ];
  return helpPatterns.some(pattern => pattern.test(message));
}

function isCasualConversation(message) {
  const trimmedMessage = message.trim().toLowerCase();
  
  // Thanks expressions
  if (/^(thanks|thank you|appreciate)/i.test(trimmedMessage)) {
    return true;
  }
  
  // Positive reactions
  if (/^(cool|awesome|great|amazing|interesting|nice)/i.test(trimmedMessage)) {
    return true;
  }
  
  // Goodbyes
  if (/^(bye|goodbye|see you|farewell|take care)/i.test(trimmedMessage)) {
    return true;
  }
  
  // Agreements/opinions
  if (/^(yes|no|maybe|i think|i believe|i agree)/i.test(trimmedMessage)) {
    return true;
  }
  
  return false;
}

function generateGreetingResponse(messageCount) {
  const greetings = [
    "Hello! I'm JustAI, your offline AI assistant. How can I help you today?",
    "Hi there! I'm ready to assist you with information, commands, searches, or just a friendly chat!",
    "Greetings! I'm JustAI, running locally to help you with various tasks. What would you like to discuss?",
    "Good to see you! I'm here to help with both technical tasks and conversation. What's on your mind?"
  ];
  
  const greeting = greetings[Math.floor(Math.random() * greetings.length)];
  
  if (messageCount === 1) {
    return greeting + "\n\nI can help you with:\n• 🖥️ System information\n• 🔍 Web search\n• ⚡ Command execution\n• 🎨 Image generation\n• 💬 Natural conversation\n\nJust ask me anything!";
  }
  
  return greeting;
}

function generateQuestionResponse(question, recentMessages) {
  // Handle practical questions with direct answers
  if (question.includes('weather') || question.includes('temperature')) {
    return "I don't have access to real-time weather data, but I can help you search for weather information online. Just ask me to search for weather in your location!";
  }
  
  if (question.includes('time') || question.includes('date')) {
    const now = new Date();
    return `The current date and time is ${now.toLocaleString()}. I'm running locally on your system, so this reflects your system's time zone.`;
  }
  
  if (question.includes('news') || question.includes('latest')) {
    return "I can search for the latest news on any topic! Just tell me what kind of news you're interested in, and I'll find current information for you.";
  }
  
  // Natural, direct responses - if AI doesn't know, offer web search
  const lowerQuestion = question.toLowerCase().trim();
  
  // Simple, direct acknowledgments
  if (lowerQuestion.includes('who is')) {
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function",
        function: {
          name: "web_search",
          arguments: JSON.stringify({ query: question, num_results: 5 })
        }
      }]
    });
  }
  
  if (lowerQuestion.includes('what is')) {
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function",
        function: {
          name: "web_search",
          arguments: JSON.stringify({ query: question, num_results: 5 })
        }
      }]
    });
  }
  
  if (lowerQuestion.includes('why is')) {
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function",
        function: {
          name: "web_search",
          arguments: JSON.stringify({ query: question, num_results: 5 })
        }
      }]
    });
  }
  
  if (lowerQuestion.includes('how does')) {
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function",
        function: {
          name: "web_search",
          arguments: JSON.stringify({ query: question, num_results: 5 })
        }
      }]
    });
  }
  
  if (lowerQuestion.includes('where is')) {
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function",
        function: {
          name: "web_search",
          arguments: JSON.stringify({ query: question, num_results: 5 })
        }
      }]
    });
  }
  
  if (lowerQuestion.includes('when did')) {
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function",
        function: {
          name: "web_search",
          arguments: JSON.stringify({ query: question, num_results: 5 })
        }
      }]
    });
  }
  
  // Very simple acknowledgment for other questions
  return JSON.stringify({
    tool_calls: [{
      id: "call_" + Date.now(),
      type: "function",
      function: {
        name: "web_search",
        arguments: JSON.stringify({ query: question, num_results: 5 })
      }
    }]
  });
}

function generatePersonalResponse(question) {
  if (question.includes('who are you') || question.includes('what are you')) {
    return "I'm JustAI, an offline AI assistant running on the Qwen2.5-0.5B model. I operate entirely on your local machine, which means:\n\n• Your conversations stay private\n• I work without internet connection\n• I can access your system when needed\n• I can search the web when you ask\n\nI'm designed to be helpful, informative, and easy to talk to!";
  }
  
  if (question.includes('what can you do') || question.includes('capabilities')) {
    return generateHelpResponse();
  }
  
  if (question.includes('feelings') || question.includes('real')) {
    return "I'm an AI assistant, so I don't have feelings or consciousness in the human sense. However, I'm designed to be helpful, friendly, and understanding. I process your messages and respond based on my training, always aiming to be useful and considerate.";
  }
  
  return "I'm JustAI, your local AI assistant. I'm here to help with both technical tasks and conversation. Is there something specific you'd like to know about me or what I can do for you?";
}

function generateHelpResponse() {
  return `I'm JustAI, your enhanced offline AI assistant! Here's what I can do:

**🛠️ Technical Tools:**
• 🖥️ **System Information** - Get details about your computer
• 🔍 **Web Search** - Find current information online  
• ⚡ **Command Execution** - Run system commands safely
• 🎨 **Image Generation** - Create images from descriptions

**💬 Conversation:**
• Answer questions and explain concepts
• Chat naturally about various topics
• Help with brainstorming and ideas
• Provide assistance and guidance

**🚀 How to use:**
• **For tools**: Be specific like "Tell me about this system" or "Search for AI news"
• **For chat**: Just talk to me naturally! Ask questions, share thoughts, or request help
• **Mixed requests**: Try "What's the weather like today and can you show me system info?"

Everything I do happens locally on your machine, keeping your data private. What would you like to explore?`;
}

function generateCasualResponse(message, messageCount) {
  if (message.includes('thanks') || message.includes('thank you')) {
    const responses = [
      "You're welcome! I'm always here to help.",
      "Happy to assist! Is there anything else you need?",
      "My pleasure! Feel free to ask if you need help with anything else.",
      "You're very welcome! I enjoy helping out."
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }
  
  if (message.includes('cool') || message.includes('awesome') || message.includes('great')) {
    const responses = [
      "Thank you! I try to be as helpful as possible.",
      "I appreciate that! Let me know if there's anything I can help you with.",
      "Thanks! I'm here to make things easier for you.",
      "Glad you think so! What would you like to work on next?"
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }
  
  if (message.includes('bye') || message.includes('goodbye')) {
    const responses = [
      "Goodbye! Feel free to come back anytime you need help.",
      "See you later! It was great chatting with you.",
      "Farewell! I'll be here whenever you need assistance.",
      "Take care! Don't hesitate to return if you need anything."
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }
  
  // Default casual acknowledgment
  return "I understand! Is there something specific you'd like to explore or discuss further?";
}

function generateDefaultConversationalResponse(message, messageCount) {
  const responses = [
    `That's interesting! While I think about "${message}", is there a specific way I can help you? I can search for information, explain concepts, or assist with technical tasks.`,
    `I see what you mean. Regarding "${message}", would you like me to find more information, or is there something practical I can help you with?`,
    `Thanks for sharing that! If you'd like to explore "${message}" further, I can search for details or help you with related tasks.`,
    `I understand you're interested in "${message}". How can I assist you with this? I'm here to help with both information and practical tasks.`
  ];
  
  let response = responses[Math.floor(Math.random() * responses.length)];
  
  if (messageCount === 1) {
    response += "\n\nBy the way, I can also help with system information, web searches, command execution, and image generation if you need technical assistance!";
  }
  
  return response;
}

export function getModelInfo() {
  return {
    loaded: modelInitialized,
    modelPath: modelInitialized ? path.join(__dirname, '../../models/qwen2.5-0.5b-instruct-q4_k_m.gguf') : null,
    contextSize: 4096, // Increased from 2048 to 4096
    gpuLayers: 0,
    llamaVersion: null,
    fallback: true,
    enhanced: true
  };
}