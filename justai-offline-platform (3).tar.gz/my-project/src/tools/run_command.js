import { createLogger, format, transports } from 'winston';
import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs/promises';
import path from 'path';

const execAsync = promisify(exec);

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

export const runCommandTool = {
  name: 'run_command',
  description: 'Execute shell commands and return their output (unrestricted access)',
  parameters: {
    type: 'object',
    properties: {
      command: {
        type: 'string',
        description: 'Shell command to execute'
      },
      working_directory: {
        type: 'string',
        description: 'Directory to execute the command in (default: current directory)',
        default: null
      },
      timeout: {
        type: 'integer',
        description: 'Command timeout in milliseconds (default: 30000)',
        default: 30000
      },
      capture_output: {
        type: 'boolean',
        description: 'Whether to capture stdout and stderr (default: true)',
        default: true
      },
      shell: {
        type: 'string',
        description: 'Shell to use for execution (default: /bin/bash)',
        default: '/bin/bash'
      }
    },
    required: ['command']
  },
  executor: async (args) => {
    try {
      const startTime = Date.now();
      
      // Validate command for basic safety (though tool is described as unrestricted)
      if (!args.command || typeof args.command !== 'string') {
        throw new Error('Invalid command provided');
      }

      const execOptions = {
        timeout: args.timeout,
        shell: args.shell,
        cwd: args.working_directory || process.cwd(),
        maxBuffer: 1024 * 1024 * 10 // 10MB buffer
      };

      let result;
      if (args.capture_output) {
        result = await execAsync(args.command, execOptions);
      } else {
        // For commands that shouldn't capture output (e.g., interactive commands)
        result = { stdout: '', stderr: '' };
        await new Promise((resolve, reject) => {
          const child = exec(args.command, execOptions, (error, stdout, stderr) => {
            if (error) reject(error);
            else resolve();
          });
        });
      }

      const endTime = Date.now();
      const executionTime = endTime - startTime;

      const response = {
        status: 'success',
        summary: `Command executed successfully: "${args.command}"`,
        data: {
          command: args.command,
          working_directory: execOptions.cwd,
          exit_code: 0,
          execution_time_ms: executionTime,
          stdout: args.capture_output ? result.stdout : '[Output not captured]',
          stderr: args.capture_output ? result.stderr : '[Error output not captured]',
          captured: args.capture_output
        },
        artifacts: [],
        timestamp: new Date().toISOString()
      };

      // Store large outputs as artifacts
      if (args.capture_output && result.stdout && result.stdout.length > 5000) {
        response.data.stdout_preview = result.stdout.substring(0, 1000) + '...';
        response.data.stdout = '[Output truncated due to size. Full output available in artifacts.]';
        
        response.artifacts.push({
          type: 'command_output',
          filename: `stdout_${Date.now()}.txt`,
          content: result.stdout,
          size: result.stdout.length
        });
      }

      if (args.capture_output && result.stderr && result.stderr.length > 5000) {
        response.data.stderr_preview = result.stderr.substring(0, 1000) + '...';
        response.data.stderr = '[Error output truncated due to size. Full output available in artifacts.]';
        
        response.artifacts.push({
          type: 'command_error',
          filename: `stderr_${Date.now()}.txt`,
          content: result.stderr,
          size: result.stderr.length
        });
      }

      return response;
    } catch (error) {
      logger.error('Run command tool error:', error);
      
      const endTime = Date.now();
      const executionTime = endTime - Date.now();

      return {
        status: 'error',
        summary: `Command failed: "${args.command}" - ${error.message}`,
        data: {
          command: args.command,
          working_directory: args.working_directory || process.cwd(),
          exit_code: error.code || 1,
          execution_time_ms: executionTime,
          stdout: error.stdout || '',
          stderr: error.stderr || '',
          error: error.message,
          signal: error.signal
        },
        artifacts: [],
        timestamp: new Date().toISOString()
      };
    }
  }
};