import { createLogger, format, transports } from 'winston';
import os from 'os';
import fs from 'fs/promises';
import path from 'path';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

export const systemInfoTool = {
  name: 'system_info',
  description: 'Get comprehensive system information including OS, hardware, and process details',
  parameters: {
    type: 'object',
    properties: {
      include_network: {
        type: 'boolean',
        description: 'Include network interface information',
        default: false
      },
      include_processes: {
        type: 'boolean',
        description: 'Include running processes information',
        default: false
      }
    }
  },
  executor: async (args) => {
    try {
      const info = {
        timestamp: new Date().toISOString(),
        system: {
          platform: os.platform(),
          arch: os.arch(),
          release: os.release(),
          hostname: os.hostname(),
          uptime: os.uptime(),
          loadavg: os.loadavg(),
          totalmem: os.totalmem(),
          freemem: os.freemem(),
          cpus: os.cpus().map(cpu => ({
            model: cpu.model,
            speed: cpu.speed,
            cores: 1
          }))
        },
        nodejs: {
          version: process.version,
          pid: process.pid,
          ppid: process.ppid,
          uptime: process.uptime(),
            memoryUsage: process.memoryUsage(),
          cpuUsage: process.cpuUsage()
        }
      };

      if (args.include_network) {
        const networkInterfaces = os.networkInterfaces();
        info.network = {};
        for (const [name, interfaces] of Object.entries(networkInterfaces)) {
          info.network[name] = interfaces.map(iface => ({
            address: iface.address,
            netmask: iface.netmask,
            family: iface.family,
            mac: iface.mac,
            internal: iface.internal
          }));
        }
      }

      if (args.include_processes) {
        // Get current working directory and environment
        info.processes = {
          cwd: process.cwd(),
          env: Object.keys(process.env).reduce((acc, key) => {
            if (!key.toLowerCase().includes('password') && 
                !key.toLowerCase().includes('secret') &&
                !key.toLowerCase().includes('token')) {
              acc[key] = process.env[key];
            }
            return acc;
          }, {})
        };
      }

      return {
        status: 'success',
        summary: `System information gathered for ${info.system.hostname} (${info.system.platform} ${info.system.arch})`,
        data: info,
        artifacts: [],
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      logger.error('System info tool error:', error);
      return {
        status: 'error',
        summary: `Failed to get system information: ${error.message}`,
        data: null,
        artifacts: [],
        timestamp: new Date().toISOString()
      };
    }
  }
};