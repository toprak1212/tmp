import { createLogger, format, transports } from 'winston';
import { toolRegistry } from '../tools/registry.js';
import { getCachedToolResult, cacheToolResult } from '../memory/database.js';
import { outputNormalizer } from './normalizer.js';
import { summarizer } from '../memory/summarize.js';
import { storeMemory } from '../memory/database.js';
import crypto from 'crypto';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

class ToolExecutor {
  constructor() {
    this.activeExecutions = new Map();
    this.maxConcurrentExecutions = 5;
  }

  async executeToolCalls(toolCalls, context = {}) {
    const results = [];
    
    for (const toolCall of toolCalls) {
      try {
        const result = await this.executeSingleToolCall(toolCall, context);
        results.push(result);
      } catch (error) {
        logger.error('Tool call execution failed:', { toolCall, error: error.message });
        
        results.push({
          tool_call_id: toolCall.id,
          tool_name: toolCall.function.name,
          status: 'error',
          error: error.message,
          result: null
        });
      }
    }

    return results;
  }

  async executeSingleToolCall(toolCall, context = {}) {
    const { id, function: func } = toolCall;
    const toolName = func.name;
    let toolArgs;

    try {
      toolArgs = typeof func.arguments === 'string' 
        ? JSON.parse(func.arguments) 
        : func.arguments;
    } catch (error) {
      throw new Error(`Invalid JSON in tool arguments: ${error.message}`);
    }

    // Check for concurrent execution limit
    if (this.activeExecutions.size >= this.maxConcurrentExecutions) {
      throw new Error('Maximum concurrent tool executions reached');
    }

    // Generate input hash for caching
    const inputHash = this.generateInputHash(toolName, toolArgs);

    // Check cache first
    const cachedResult = await getCachedToolResult(toolName, inputHash);
    if (cachedResult && !context.skipCache) {
      logger.info('Using cached tool result', { toolName, inputHash });
      
      return {
        tool_call_id: id,
        tool_name: toolName,
        status: 'success',
        result: cachedResult.result,
        cached: true,
        execution_id: cachedResult.id
      };
    }

    // Execute the tool
    const executionId = crypto.randomUUID();
    this.activeExecutions.set(executionId, { toolName, startTime: Date.now() });

    try {
      logger.info('Executing tool call', { 
        executionId, 
        toolName, 
        toolArgs,
        context 
      });

      const result = await toolRegistry.executeTool(toolName, toolArgs, context);

      // Normalize the result
      const normalizedResult = outputNormalizer.normalize(toolName, result);

      // Create and store summary for successful results
      if (normalizedResult.status === 'success') {
        try {
          const summary = await summarizer.summarizeToolResult(toolName, normalizedResult);
          if (summary) {
            await storeMemory(summary.key, summary.value, summary.type);
          }
        } catch (error) {
          logger.warn('Failed to create summary for tool result:', { toolName, error: error.message });
        }
      }

      // Cache successful results
      if (normalizedResult.status === 'success' && !context.skipCache) {
        await cacheToolResult(
          toolName, 
          inputHash, 
          normalizedResult, 
          normalizedResult.summary
        );
      }

      const response = {
        tool_call_id: id,
        tool_name: toolName,
        status: normalizedResult.status,
        result: normalizedResult,
        cached: false,
        execution_id: executionId
      };

      logger.info('Tool call completed', {
        executionId,
        toolName,
        status: normalizedResult.status,
        execution_time: normalizedResult.execution?.execution_time_ms
      });

      return response;
    } finally {
      this.activeExecutions.delete(executionId);
    }
  }

  generateInputHash(toolName, args) {
    const hashInput = `${toolName}:${JSON.stringify(args)}`;
    return crypto.createHash('sha256').update(hashInput).digest('hex');
  }

  parseToolCallsFromContent(content) {
    const toolCalls = [];

    // Try to parse as JSON first
    try {
      const parsed = JSON.parse(content);
      if (parsed.tool_calls && Array.isArray(parsed.tool_calls)) {
        return parsed.tool_calls.map(tc => ({
          id: tc.id || crypto.randomUUID(),
          type: 'function',
          function: {
            name: tc.name,
            arguments: typeof tc.arguments === 'string' ? tc.arguments : JSON.stringify(tc.arguments)
          }
        }));
      }
    } catch (error) {
      // Not JSON, continue with text parsing
    }

    // Look for tool call patterns in text
    const patterns = [
      /```json\s*({\s*"tool_calls"\s*:\s*\[[\s\S]*?\]\s*})\s*```/g,
      /{\s*"tool_calls"\s*:\s*\[[\s\S]*?\]\s*}/g,
      /Tool call:\s*(\w+)\s*\(([\s\S]*?)\)/gi
    ];

    for (const pattern of patterns) {
      let match;
      while ((match = pattern.exec(content)) !== null) {
        try {
          const toolCallData = match[1] || match[0];
          const parsed = JSON.parse(toolCallData);
          
          if (parsed.tool_calls) {
            toolCalls.push(...parsed.tool_calls.map(tc => ({
              id: tc.id || crypto.randomUUID(),
              type: 'function',
              function: {
                name: tc.name,
                arguments: typeof tc.arguments === 'string' ? tc.arguments : JSON.stringify(tc.arguments)
              }
            })));
          }
        } catch (error) {
          // Try to extract simple tool calls
          const simpleMatch = match[0].match(/Tool call:\s*(\w+)\s*\(([\s\S]*?)\)/i);
          if (simpleMatch) {
            toolCalls.push({
              id: crypto.randomUUID(),
              type: 'function',
              function: {
                name: simpleMatch[1],
                arguments: simpleMatch[2] || '{}'
              }
            });
          }
        }
      }
    }

    return toolCalls;
  }

  formatToolResultsForModel(toolResults) {
    let formattedContent = '';

    for (const result of toolResults) {
      formattedContent += `Tool Result for ${result.tool_name}:\n`;
      
      if (result.status === 'success') {
        formattedContent += `Status: Success\n`;
        formattedContent += `Summary: ${result.result.summary}\n`;
        
        if (result.result.data) {
          formattedContent += `Data: ${JSON.stringify(result.result.data, null, 2)}\n`;
        }
        
        if (result.result.artifacts && result.result.artifacts.length > 0) {
          formattedContent += `Artifacts: ${result.result.artifacts.length} items generated\n`;
          for (const artifact of result.result.artifacts) {
            formattedContent += `- ${artifact.type}: ${artifact.filename || artifact.path} (${artifact.size} bytes)\n`;
          }
        }
        
        if (result.cached) {
          formattedContent += `Note: This result was retrieved from cache\n`;
        }
      } else {
        formattedContent += `Status: Error\n`;
        formattedContent += `Error: ${result.error}\n`;
      }
      
      formattedContent += '---\n';
    }

    return formattedContent;
  }

  getActiveExecutions() {
    return Array.from(this.activeExecutions.entries()).map(([id, info]) => ({
      execution_id: id,
      tool_name: info.toolName,
      running_time_ms: Date.now() - info.startTime
    }));
  }

  async cancelExecution(executionId) {
    const execution = this.activeExecutions.get(executionId);
    if (execution) {
      this.activeExecutions.delete(executionId);
      logger.info('Tool execution cancelled', { executionId, toolName: execution.toolName });
      return true;
    }
    return false;
  }

  getAvailableTools() {
    return toolRegistry.getAllTools();
  }

  getToolStats() {
    return toolRegistry.getToolStats();
  }
}

export const toolExecutor = new ToolExecutor();
export { ToolExecutor };