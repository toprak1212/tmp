import sqlite3 from 'sqlite3';
import { promisify } from 'util';
import { createLogger, format, transports } from 'winston';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

let db = null;

export async function initializeMemory() {
  return new Promise((resolve, reject) => {
    db = new sqlite3.Database('data/memory.db', (err) => {
      if (err) {
        logger.error('Failed to open database:', err);
        reject(err);
        return;
      }
      
      logger.info('Connected to SQLite database');
      
      // Create tables
      db.serialize(() => {
        // Memory table for storing facts and context
        db.run(`
          CREATE TABLE IF NOT EXISTS memory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT UNIQUE NOT NULL,
            value TEXT NOT NULL,
            type TEXT NOT NULL DEFAULT 'fact',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `);

        // Tool results table for caching tool outputs
        db.run(`
          CREATE TABLE IF NOT EXISTS tool_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tool_name TEXT NOT NULL,
            input_hash TEXT NOT NULL,
            result TEXT NOT NULL,
            summary TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(tool_name, input_hash)
          )
        `);

        // Conversations table for chat history
        db.run(`
          CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `);

        logger.info('Database tables initialized');
        resolve();
      });
    });
  });
}

export function getDatabase() {
  if (!db) {
    throw new Error('Database not initialized. Call initializeMemory() first.');
  }
  return db;
}

// Memory operations
export async function storeMemory(key, value, type = 'fact') {
  const db = getDatabase();
  const stmt = db.prepare(`
    INSERT OR REPLACE INTO memory (key, value, type, updated_at)
    VALUES (?, ?, ?, CURRENT_TIMESTAMP)
  `);
  
  return new Promise((resolve, reject) => {
    stmt.run([key, value, type], function(err) {
      if (err) {
        reject(err);
      } else {
        resolve({ id: this.lastID, key, value, type });
      }
    });
    stmt.finalize();
  });
}

export async function getMemory(key) {
  const db = getDatabase();
  const stmt = db.prepare('SELECT * FROM memory WHERE key = ?');
  
  return new Promise((resolve, reject) => {
    stmt.get([key], (err, row) => {
      if (err) {
        reject(err);
      } else {
        resolve(row);
      }
    });
    stmt.finalize();
  });
}

export async function getAllMemories() {
  const db = getDatabase();
  const stmt = db.prepare('SELECT * FROM memory ORDER BY created_at DESC');
  
  return new Promise((resolve, reject) => {
    stmt.all([], (err, rows) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows);
      }
    });
    stmt.finalize();
  });
}

// Tool result caching
export async function cacheToolResult(toolName, inputHash, result, summary) {
  const db = getDatabase();
  const stmt = db.prepare(`
    INSERT OR REPLACE INTO tool_results (tool_name, input_hash, result, summary)
    VALUES (?, ?, ?, ?)
  `);
  
  return new Promise((resolve, reject) => {
    stmt.run([toolName, inputHash, JSON.stringify(result), summary], function(err) {
      if (err) {
        reject(err);
      } else {
        resolve({ id: this.lastID, toolName, inputHash, result, summary });
      }
    });
    stmt.finalize();
  });
}

export async function getCachedToolResult(toolName, inputHash) {
  const db = getDatabase();
  const stmt = db.prepare('SELECT * FROM tool_results WHERE tool_name = ? AND input_hash = ?');
  
  return new Promise((resolve, reject) => {
    stmt.get([toolName, inputHash], (err, row) => {
      if (err) {
        reject(err);
      } else if (row) {
        resolve({ ...row, result: JSON.parse(row.result) });
      } else {
        resolve(null);
      }
    });
    stmt.finalize();
  });
}