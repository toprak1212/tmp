import { createLogger, format, transports } from 'winston';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

let modelInitialized = false;

export async function initializeModel() {
  try {
    logger.info('Initializing LLaMA model...');
    
    // For now, use fallback approach with proper error handling
    // In production, you would integrate with actual node-llama-cpp
    const modelPath = path.join(__dirname, '../../models/qwen2.5-0.5b-instruct-q4_k_m.gguf');
    
    // Check if model file exists
    try {
      const fs = await import('fs/promises');
      await fs.access(modelPath);
      logger.info('Model file found at:', modelPath);
    } catch (error) {
      throw new Error(`Model file not found at: ${modelPath}`);
    }

    modelInitialized = true;
    logger.info('Model initialized successfully (enhanced fallback mode)');
    return true;
  } catch (error) {
    logger.error('Failed to initialize model:', error);
    throw error;
  }
}

export async function generateCompletion(messages, options = {}) {
  if (!modelInitialized) {
    throw new Error('Model not initialized. Call initializeModel() first.');
  }

  try {
    logger.info('Generating completion...', { 
      messageCount: messages.length
    });

    // Enhanced fallback response generation with better tool detection
    const completion = generateEnhancedFallbackResponse(messages);

    logger.info('Completion generated', { 
      responseLength: completion.length 
    });

    return completion.trim();
  } catch (error) {
    logger.error('Failed to generate completion:', error);
    throw error;
  }
}

function generateEnhancedFallbackResponse(messages) {
  const lastUserMessage = messages.filter(m => m.role === 'user').pop();
  
  // Check if we already have tool results in conversation
  const hasToolResults = messages.some(m => m.role === 'tool');
  
  if (lastUserMessage && !hasToolResults) {
    const content = lastUserMessage.content.toLowerCase();
    
    // Enhanced tool request detection
    if (content.includes('system info') || content.includes('computer') || content.includes('tell me about this system')) {
      return JSON.stringify({
        tool_calls: [{
          id: "call_" + Date.now(),
          type: "function",
          function: {
            name: "system_info",
            arguments: JSON.stringify({ include_network: false, include_processes: false })
          }
        }]
      });
    }
    
    if (content.includes('search') || content.includes('look up')) {
      return JSON.stringify({
        tool_calls: [{
          id: "call_" + Date.now(),
          type: "function", 
          function: {
            name: "web_search",
            arguments: JSON.stringify({ query: lastUserMessage.content, num_results: 5 })
          }
        }]
      });
    }
    
    if (content.includes('run') || content.includes('execute') || content.includes('command')) {
      return JSON.stringify({
        tool_calls: [{
          id: "call_" + Date.now(),
          type: "function",
          function: {
            name: "run_command",
            arguments: JSON.stringify({ command: "echo 'Hello from enhanced JustAI!'" })
          }
        }]
      });
    }
    
    if (content.includes('image') || content.includes('picture') || content.includes('generate')) {
      return JSON.stringify({
        tool_calls: [{
          id: "call_" + Date.now(),
          type: "function",
          function: {
            name: "generate_image",
            arguments: JSON.stringify({ prompt: lastUserMessage.content, width: 512, height: 512, method: 'web' })
          }
        }]
      });
    }
  }

  // If we have tool results, synthesize a response
  if (hasToolResults) {
    const toolResults = messages.filter(m => m.role === 'tool');
    if (toolResults.length > 0) {
      return "I've successfully executed your request. Based on the results I gathered: " + toolResults[0].content.substring(0, 200) + "...";
    }
  }

  // Default response
  return "Hello! I'm JustAI, your enhanced offline AI assistant. I can help you with:\n\n🖥️ **System Information** - Get details about your computer system\n🔍 **Web Search** - Search the internet for current information\n⚡ **Command Execution** - Run system commands and scripts\n🎨 **Image Generation** - Create images from text descriptions\n\nTry asking me things like 'tell me about this system' or 'search for latest AI news' or 'generate image: sunset over mountains'.";
}

export function getModelInfo() {
  return {
    loaded: modelInitialized,
    modelPath: modelInitialized ? path.join(__dirname, '../../models/qwen2.5-0.5b-instruct-q4_k_m.gguf') : null,
    contextSize: 2048,
    gpuLayers: 0,
    llamaVersion: null,
    fallback: true,
    enhanced: true
  };
}