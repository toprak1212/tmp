import { createLogger, format, transports } from 'winston';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

export class PromptFormatter {
  constructor() {
    this.toolSchemas = new Map();
  }

  registerToolSchema(toolName, schema) {
    this.toolSchemas.set(toolName, schema);
  }

  formatMessagesToPrompt(messages, tools = []) {
    let prompt = '';
    
    // Add system message with tool definitions if available
    const systemMessage = messages.find(m => m.role === 'system');
    if (systemMessage) {
      prompt += `<|im_start|>system\n${systemMessage.content}`;
      
      // Add tool definitions to system message
      if (tools.length > 0) {
        prompt += '\n\nYou have access to the following tools:\n';
        tools.forEach(tool => {
          prompt += `\n${tool.name}: ${tool.description}\n`;
          if (tool.parameters) {
            prompt += `Parameters: ${JSON.stringify(tool.parameters, null, 2)}\n`;
          }
        });
        prompt += '\nTo use a tool, respond with a JSON object containing:\n';
        prompt += '- "tool_calls": array of tool call objects with "name", "arguments", and "id"\n';
        prompt += '- "content": null (when making tool calls)\n';
      }
      
      prompt += '<|im_end|>\n';
    } else {
      // Default system message
      prompt += `<|im_start|>system\nYou are a helpful AI assistant.`;
      
      if (tools.length > 0) {
        prompt += '\n\nYou have access to the following tools:\n';
        tools.forEach(tool => {
          prompt += `\n${tool.name}: ${tool.description}\n`;
        });
        prompt += '\nTo use a tool, respond with a JSON object containing:\n';
        prompt += '- "tool_calls": array of tool call objects with "name", "arguments", and "id"\n';
        prompt += '- "content": null (when making tool calls)\n';
      }
      
      prompt += '<|im_end|>\n';
    }

    // Add other messages
    for (const message of messages) {
      if (message.role === 'system') continue; // Already handled
      
      switch (message.role) {
        case 'user':
          prompt += `<|im_start|>user\n${message.content}<|im_end|>\n`;
          break;
        case 'assistant':
          if (message.tool_calls) {
            // Assistant is making tool calls
            prompt += `<|im_start|>assistant\n${JSON.stringify({ tool_calls: message.tool_calls })}<|im_end|>\n`;
          } else if (message.content) {
            // Regular assistant response
            prompt += `<|im_start|>assistant\n${message.content}<|im_end|>\n`;
          }
          break;
        case 'tool':
          // Tool response
          prompt += `<|im_start|>tool\nTool result for ${message.tool_call_id}:\n${message.content}<|im_end|>\n`;
          break;
      }
    }
    
    // Add the final assistant prompt
    prompt += '<|im_start|>assistant\n';
    
    return prompt;
  }

  parseToolCalls(content) {
    try {
      const parsed = JSON.parse(content);
      if (parsed.tool_calls && Array.isArray(parsed.tool_calls)) {
        return parsed.tool_calls;
      }
    } catch (error) {
      // Not JSON, try to extract tool calls from text
      return this.extractToolCallsFromText(content);
    }
    return [];
  }

  extractToolCallsFromText(text) {
    const toolCalls = [];
    const toolCallPattern = /\{\s*"tool_calls"\s*:\s*\[([\s\S]*?)\]\s*\}/g;
    const matches = text.match(toolCallPattern);
    
    if (matches) {
      for (const match of matches) {
        try {
          const parsed = JSON.parse(match);
          if (parsed.tool_calls) {
            toolCalls.push(...parsed.tool_calls);
          }
        } catch (error) {
          logger.warn('Failed to parse tool call from text:', match);
        }
      }
    }
    
    return toolCalls;
  }

  createToolResponse(toolCallId, result) {
    return {
      role: 'tool',
      tool_call_id: toolCallId,
      content: typeof result === 'string' ? result : JSON.stringify(result)
    };
  }

  createAssistantResponse(content, toolCalls = []) {
    const response = {
      role: 'assistant',
      content: toolCalls.length > 0 ? null : content
    };
    
    if (toolCalls.length > 0) {
      response.tool_calls = toolCalls;
    }
    
    return response;
  }
}