import { createLogger, format, transports } from 'winston';
import { generateCompletion, initializeModel, getModelInfo } from '../model/llama.js';
import { PromptFormatter } from '../model/prompt.js';
import { toolExecutor } from '../controller/tool_executor.js';
import { storeMemory, getAllMemories } from '../memory/database.js';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

const promptFormatter = new PromptFormatter();

// Initialize model on startup
let modelInitialized = false;

async function ensureModelInitialized() {
  if (!modelInitialized) {
    try {
      await initializeModel();
      modelInitialized = true;
      logger.info('Model initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize model:', error);
      throw error;
    }
  }
}

async function handleToolCalls(toolCalls, messages) {
  logger.info('Handling tool calls', { toolCallCount: toolCalls.length });
  
  // Execute tools
  const toolResults = await toolExecutor.executeToolCalls(toolCalls, {
    conversation_id: messages[0]?.conversation_id || 'default'
  });

  // Format tool results for model
  const toolResultMessages = toolResults.map(result => ({
    role: 'tool',
    tool_call_id: result.tool_call_id,
    content: toolExecutor.formatToolResultsForModel([result])
  }));

  return toolResultMessages;
}

export async function chatCompletionsHandler(req, res) {
  try {
    const { messages, model, temperature, max_tokens, stream = false, tools } = req.body;

    // Validate request
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({
        error: {
          message: 'Messages array is required',
          type: 'invalid_request_error'
        }
      });
    }

    logger.info('Chat completion request:', { 
      messageCount: messages.length, 
      model, 
      temperature, 
      max_tokens,
      stream,
      toolsCount: tools?.length || 0
    });

    // Ensure model is initialized
    await ensureModelInitialized();

    // Get available tools for context
    const availableTools = tools || toolExecutor.getAvailableTools();

    // Add memory context to system message
    let enhancedMessages = [...messages];
    try {
      const memories = await getAllMemories();
      if (memories.length > 0) {
        const memoryContext = memories
          .filter(m => m.type === 'fact')
          .map(m => `- ${m.key}: ${m.value}`)
          .join('\n');
        
        const systemMessage = enhancedMessages.find(m => m.role === 'system');
        if (systemMessage) {
          systemMessage.content += `\n\nRelevant Memory:\n${memoryContext}`;
        } else {
          enhancedMessages.unshift({
            role: 'system',
            content: `Relevant Memory:\n${memoryContext}`
          });
        }
      }
    } catch (error) {
      logger.warn('Failed to load memory context:', error);
    }

    // Multi-turn conversation with tool calls
    let currentMessages = enhancedMessages;
    let maxIterations = 5; // Prevent infinite loops
    let iteration = 0;

    while (iteration < maxIterations) {
      iteration++;
      logger.info('Processing conversation turn', { iteration, maxIterations });

      // Format messages into prompt
      const prompt = promptFormatter.formatMessagesToPrompt(currentMessages, availableTools);
      
      // Generate completion
      const completion = await generateCompletion(currentMessages, {
        temperature: temperature || 0.7,
        maxTokens: max_tokens || 1024
      });

      // Parse for tool calls
      const toolCalls = promptFormatter.parseToolCalls(completion);
      
      if (toolCalls.length === 0) {
        // No tool calls, return final response
        const response = {
          id: `chatcmpl-${Date.now()}`,
          object: 'chat.completion',
          created: Math.floor(Date.now() / 1000),
          model: model || 'qwen2.5-0.5b-instruct',
          choices: [{
            index: 0,
            message: promptFormatter.createAssistantResponse(completion, []),
            finish_reason: 'stop'
          }],
          usage: {
            prompt_tokens: Math.floor(prompt.length / 4),
            completion_tokens: Math.floor(completion.length / 4),
            total_tokens: Math.floor((prompt.length + completion.length) / 4)
          }
        };

        if (stream) {
          res.setHeader('Content-Type', 'text/event-stream');
          res.setHeader('Cache-Control', 'no-cache');
          res.setHeader('Connection', 'keep-alive');

          const chunk = {
            id: response.id,
            object: 'chat.completion.chunk',
            created: response.created,
            model: response.model,
            choices: [{
              index: 0,
              delta: { content: completion },
              finish_reason: 'stop'
            }]
          };

          res.write(`data: ${JSON.stringify(chunk)}\n\n`);
          res.write('data: [DONE]\n\n');
          res.end();
        } else {
          res.json(response);
        }
        return;
      }

      // Handle tool calls
      logger.info('Detected tool calls', { toolCallCount: toolCalls.length, iteration });
      
      // Add assistant message with tool calls
      currentMessages.push(promptFormatter.createAssistantResponse(null, toolCalls));
      
      // Execute tools and get results
      const toolResultMessages = await handleToolCalls(toolCalls, currentMessages);
      currentMessages.push(...toolResultMessages);

      // Continue loop to get final response after tool execution
    }

    // If we reach here, we exceeded max iterations
    throw new Error('Maximum tool call iterations exceeded. Please try a simpler request.');

  } catch (error) {
    logger.error('Chat completion error:', error);
    
    // If model initialization failed, return a helpful error
    if (error.message.includes('Model not initialized')) {
      return res.status(503).json({
        error: {
          message: 'Model is still loading. Please try again in a moment.',
          type: 'model_not_ready'
        }
      });
    }
    
    res.status(500).json({
      error: {
        message: 'Internal server error',
        type: 'internal_error'
      }
    });
  }
}