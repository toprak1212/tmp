import { createLogger, format, transports } from 'winston';
import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import puppeteer from 'puppeteer';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

export const generateImageTool = {
  name: 'generate_image',
  description: 'Generate images using AI image generation services or web-based methods',
  parameters: {
    type: 'object',
    properties: {
      prompt: {
        type: 'string',
        description: 'Text description of the image to generate'
      },
      width: {
        type: 'integer',
        description: 'Image width in pixels (default: 512)',
        default: 512,
        minimum: 64,
        maximum: 2048
      },
      height: {
        type: 'integer',
        description: 'Image height in pixels (default: 512)',
        default: 512,
        minimum: 64,
        maximum: 2048
      },
      style: {
        type: 'string',
        description: 'Image style (realistic, artistic, cartoon, etc.)',
        default: 'realistic'
      },
      format: {
        type: 'string',
        description: 'Output image format (png, jpeg, webp)',
        default: 'png',
        enum: ['png', 'jpeg', 'webp']
      },
      method: {
        type: 'string',
        description: 'Generation method (web, placeholder, ascii)',
        default: 'web',
        enum: ['web', 'placeholder', 'ascii']
      },
      save_path: {
        type: 'string',
        description: 'Custom save path for the generated image',
        default: null
      }
    },
    required: ['prompt']
  },
  executor: async (args) => {
    try {
      const timestamp = Date.now();
      const filename = `generated_${timestamp}_${crypto.randomBytes(4).toString('hex')}.${args.format}`;
      const outputPath = args.save_path || path.join('images/outputs', filename);
      
      // Ensure output directory exists
      await fs.mkdir(path.dirname(outputPath), { recursive: true });

      let imageBuffer;
      let generationMethod = 'unknown';

      // Method 1: Try web-based image generation
      if (args.method === 'web') {
        try {
          imageBuffer = await generateWebImage(args);
          generationMethod = 'web_generation';
        } catch (webError) {
          logger.warn('Web-based generation failed, falling back to placeholder:', webError);
          imageBuffer = await generatePlaceholderImage(args);
          generationMethod = 'placeholder_fallback';
        }
      } else if (args.method === 'placeholder') {
        imageBuffer = await generatePlaceholderImage(args);
        generationMethod = 'svg_placeholder';
      } else if (args.method === 'ascii') {
        imageBuffer = await generateAsciiImage(args);
        generationMethod = 'ascii_art';
      } else {
        // Default to web with fallback
        try {
          imageBuffer = await generateWebImage(args);
          generationMethod = 'web_generation';
        } catch (error) {
          imageBuffer = await generatePlaceholderImage(args);
          generationMethod = 'placeholder_fallback';
        }
      }

      // Save the image
      await fs.writeFile(outputPath, imageBuffer);

      const response = {
        status: 'success',
        summary: `Generated image: "${args.prompt}" (${args.width}x${args.height}, ${args.format}, ${Math.round(imageBuffer.length / 1024)}KB)`,
        data: {
          prompt: args.prompt,
          width: args.width,
          height: args.height,
          style: args.style,
          format: args.format,
          method: args.method || 'web',
          file_path: outputPath,
          file_size: imageBuffer.length,
          generation_method: generationMethod,
          generation_time_ms: Date.now() - timestamp
        },
        artifacts: [{
          type: 'image',
          filename: filename,
          path: outputPath,
          size: imageBuffer.length,
          format: args.format,
          metadata: {
            prompt: args.prompt,
            dimensions: `${args.width}x${args.height}`,
            style: args.style,
            generation_method: generationMethod
          }
        }],
        timestamp: new Date().toISOString()
      };

      return response;
    } catch (error) {
      logger.error('Generate image tool error:', error);
      return {
        status: 'error',
        summary: `Failed to generate image: ${error.message}`,
        data: {
          prompt: args.prompt,
          error: error.message
        },
        artifacts: [],
        timestamp: new Date().toISOString()
      };
    }
  }
};

async function generateWebImage(args) {
  // Try to use a free image generation API
  // Using Pollinations AI as an example (free, no API key required)
  const apiUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(args.prompt)}?width=${args.width}&height=${args.height}&seed=${Math.floor(Math.random() * 1000000)}`;
  
  const response = await fetch(apiUrl, {
    headers: {
      'User-Agent': 'JustAI/1.0 (Educational Purpose)'
    },
    timeout: 30000
  });

  if (!response.ok) {
    throw new Error(`Image generation API failed: ${response.status} ${response.statusText}`);
  }

  const arrayBuffer = await response.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

async function generatePlaceholderImage(args) {
  // Create a better SVG placeholder with gradient and styling
  const svgContent = `
    <svg width="${args.width}" height="${args.height}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:#667eea;stop-opacity:1" />
          <stop offset="100%" style="stop-color:#764ba2;stop-opacity:1" />
        </linearGradient>
      </defs>
      <rect width="100%" height="100%" fill="url(#grad1)"/>
      <rect x="20" y="20" width="${args.width - 40}" height="${args.height - 40}" fill="none" stroke="white" stroke-width="2" rx="10"/>
      <text x="50%" y="40%" text-anchor="middle" font-family="Arial, sans-serif" font-size="16" fill="white" font-weight="bold">
        AI Generated Image
      </text>
      <text x="50%" y="50%" text-anchor="middle" font-family="Arial, sans-serif" font-size="12" fill="white">
        "${args.prompt.substring(0, 50)}${args.prompt.length > 50 ? '...' : ''}"
      </text>
      <text x="50%" y="60%" text-anchor="middle" font-family="Arial, sans-serif" font-size="10" fill="#e0e0e0">
        ${args.width}x${args.height} • ${args.style} • ${args.format}
      </text>
      <text x="50%" y="70%" text-anchor="middle" font-family="Arial, sans-serif" font-size="8" fill="#c0c0c0">
        Generated with JustAI Offline Platform
      </text>
      <circle cx="30" cy="${args.height - 30}" r="5" fill="#4CAF50"/>
      <text x="40" y="${args.height - 26}" font-family="Arial, sans-serif" font-size="8" fill="#4CAF50">
        Ready
      </text>
    </svg>
  `;
  
  return Buffer.from(svgContent);
}

async function generateAsciiImage(args) {
  // Create ASCII art representation
  const prompt = args.prompt.substring(0, 30);
  const width = Math.min(args.width / 8, 80); // ASCII width
  const height = Math.min(args.height / 16, 25); // ASCII height
  
  let ascii = '';
  
  // Create a simple ASCII frame
  ascii += '┌' + '─'.repeat(width - 2) + '┐\n';
  
  for (let i = 0; i < height - 2; i++) {
    if (i === Math.floor(height / 2) - 1) {
      // Add prompt text in the middle
      const textLine = `│ ${prompt.padEnd(width - 4)} │\n`;
      ascii += textLine;
    } else if (i === Math.floor(height / 2) + 1) {
      // Add dimensions
      const dimLine = `│ ${args.width}x${args.height} ${args.format} │\n`;
      ascii += dimLine.padStart(width + 3);
    } else {
      ascii += '│' + ' '.repeat(width - 2) + '│\n';
    }
  }
  
  ascii += '└' + '─'.repeat(width - 2) + '┘';
  
  // Convert to PNG using Puppeteer
  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { 
          margin: 0; 
          padding: 20px; 
          background: #1a1a1a; 
          color: #00ff00; 
          font-family: 'Courier New', monospace; 
          font-size: 12px;
          white-space: pre;
        }
      </style>
    </head>
    <body>${ascii}</body>
    </html>
  `;
  
  return await htmlToImage(htmlContent, args);
}

async function htmlToImage(htmlContent, args) {
  let browser;
  try {
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    const page = await browser.newPage();
    await page.setContent(htmlContent);
    
    const imageBuffer = await page.screenshot({
      type: args.format,
      clip: {
        x: 0,
        y: 0,
        width: args.width,
        height: args.height
      }
    });
    
    return imageBuffer;
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}