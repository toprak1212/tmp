import { createLogger, format, transports } from 'winston';
import axios from 'axios';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

export const httpGetTool = {
  name: 'http_get',
  description: 'Make HTTP GET requests to fetch web content, APIs, or resources',
  parameters: {
    type: 'object',
    properties: {
      url: {
        type: 'string',
        description: 'URL to make GET request to'
      },
      headers: {
        type: 'object',
        description: 'Additional headers to include in the request',
        default: {}
      },
      timeout: {
        type: 'integer',
        description: 'Request timeout in milliseconds (default: 10000)',
        default: 10000
      },
      follow_redirects: {
        type: 'boolean',
        description: 'Whether to follow HTTP redirects (default: true)',
        default: true
      }
    },
    required: ['url']
  },
  executor: async (args) => {
    try {
      const config = {
        method: 'GET',
        url: args.url,
        timeout: args.timeout,
        maxRedirects: args.follow_redirects ? 5 : 0,
        headers: {
          'User-Agent': 'JustAI/1.0 (Educational Purpose)',
          ...args.headers
        }
      };

      const response = await axios(config);
      
      const result = {
        status: 'success',
        summary: `Successfully fetched ${args.url} (${response.status} ${response.statusText})`,
        data: {
          url: args.url,
          status_code: response.status,
          status_text: response.statusText,
          headers: response.headers,
          content: response.data,
          content_type: response.headers['content-type'],
          content_length: response.headers['content-length'] || response.data.length,
          response_time: response.headers['x-response-time'] || 'unknown'
        },
        artifacts: [],
        timestamp: new Date().toISOString()
      };

      // For large content, provide a summary
      if (typeof response.data === 'string' && response.data.length > 10000) {
        result.data.content_preview = response.data.substring(0, 1000) + '...';
        result.data.full_content_available = true;
        result.data.content = '[Content truncated due to size. Full content available in artifacts.]';
        
        // Store full content as artifact
        result.artifacts.push({
          type: 'text_content',
          filename: `response_${Date.now()}.txt`,
          content: response.data,
          size: response.data.length
        });
      }

      return result;
    } catch (error) {
      logger.error('HTTP GET tool error:', error);
      
      let errorDetails = {};
      if (error.response) {
        errorDetails = {
          status_code: error.response.status,
          status_text: error.response.statusText,
          headers: error.response.headers
        };
      } else if (error.request) {
        errorDetails = {
          message: 'No response received',
          code: error.code
        };
      }

      return {
        status: 'error',
        summary: `Failed to fetch ${args.url}: ${error.message}`,
        data: {
          url: args.url,
          error: error.message,
          details: errorDetails
        },
        artifacts: [],
        timestamp: new Date().toISOString()
      };
    }
  }
};