import { createLogger, format, transports } from 'winston';
import axios from 'axios';
import crypto from 'crypto';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

export const webSearchTool = {
  name: 'web_search',
  description: 'Search the web for current information using a search engine',
  parameters: {
    type: 'object',
    properties: {
      query: {
        type: 'string',
        description: 'Search query string'
      },
      num_results: {
        type: 'integer',
        description: 'Number of results to return (default: 10)',
        default: 10,
        minimum: 1,
        maximum: 50
      },
      language: {
        type: 'string',
        description: 'Language code (e.g., en, es, fr)',
        default: 'en'
      }
    },
    required: ['query']
  },
  executor: async (args) => {
    try {
      // For now, we'll use a simple approach with DuckDuckGo's HTML results
      // In a production environment, you might want to use a proper search API
      
      const searchUrl = `https://duckduckgo.com/html/?q=${encodeURIComponent(args.query)}&kl=${args.language}`;
      
      const response = await axios.get(searchUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        },
        timeout: 10000
      });

      // Parse HTML results (simple regex-based approach)
      const html = response.data;
      const results = [];
      
      // Extract search results using regex patterns
      const resultPattern = /<a[^>]*class="result__a"[^>]*href="([^"]*)"[^>]*>([^<]*)<\/a>/g;
      const snippetPattern = /<a[^>]*class="result__a"[^>]*>.*?<\/a>.*?<a[^>]*class="result__snippet"[^>]*>([^<]*)<\/a>/gs;
      
      let match;
      let resultIndex = 0;
      
      while ((match = resultPattern.exec(html)) !== null && resultIndex < args.num_results) {
        const url = match[1];
        const title = match[2];
        
        // Try to find snippet
        const snippetMatch = new RegExp(`<a[^>]*class="result__a"[^>]*href="${url}"[^>]*>.*?<\/a>.*?<a[^>]*class="result__snippet"[^>]*>([^<]*)<\/a>`, 's').exec(html);
        const snippet = snippetMatch ? snippetMatch[1] : '';
        
        if (url && title) {
          results.push({
            url: url.startsWith('/l/?uddg=') ? decodeURIComponent(url.split('uddg=')[1].split('&')[0]) : url,
            title: title.replace(/<[^>]*>/g, '').trim(),
            snippet: snippet.replace(/<[^>]*>/g, '').trim(),
            rank: resultIndex + 1
          });
          resultIndex++;
        }
      }

      return {
        status: 'success',
        summary: `Found ${results.length} search results for "${args.query}"`,
        data: {
          query: args.query,
          results: results,
          total_results: results.length
        },
        artifacts: [],
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      logger.error('Web search tool error:', error);
      return {
        status: 'error',
        summary: `Failed to search web: ${error.message}`,
        data: null,
        artifacts: [],
        timestamp: new Date().toISOString()
      };
    }
  }
};