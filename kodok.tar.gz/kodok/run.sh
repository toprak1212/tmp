#!/bin/bash


/usr/bin/python3 agent.py -runonfly 
