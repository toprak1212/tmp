# JustAI - Offline AI Platform

A comprehensive local, offline AI server that runs on GGUF language models and provides an OpenAI-compatible API with advanced tool calling capabilities.

## Features

- **🤖 Offline AI Model**: Runs Qwen2.5-0.5B-Instruct GGUF model locally
- **🔌 OpenAI-Compatible API**: Drop-in replacement for OpenAI's chat completions endpoint
- **🛠️ Tool Calling**: Execute system commands, search the web, generate images, and more
- **🧠 Persistent Memory**: Smart caching and memory system for context retention
- **📊 Output Normalization**: Consistent formatting and artifact management
- **🎯 Planning System**: Intelligent multi-step request execution
- **🖼️ Image Generation**: Create images using various generation methods
- **🔍 Web Search**: Real-time web information retrieval
- **💻 Command Execution**: Unrestricted system command execution
- **📡 HTTP Requests**: Fetch and process web content

## Quick Start

### Prerequisites

- Node.js 20 or higher
- Bun package manager (recommended) or npm
- 4GB+ RAM recommended
- 2GB+ disk space for model

### Installation

1. Clone or download the project
2. Install dependencies:
   ```bash
   bun install
   ```

### Running the Server

```bash
# Development mode with auto-restart
bun run dev

# Production mode
bun start
```

The server will start on `http://localhost:3000`

### API Usage

The server provides an OpenAI-compatible API at `/v1/chat/completions`:

```bash
curl -X POST http://localhost:3000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen2.5-0.5b-instruct",
    "messages": [
      {"role": "user", "content": "Hello, how are you?"}
    ]
  }'
```

## Available Tools

### System Information
```json
{
  "name": "system_info",
  "description": "Get comprehensive system information",
  "parameters": {
    "include_network": "boolean",
    "include_processes": "boolean"
  }
}
```

### Web Search
```json
{
  "name": "web_search",
  "description": "Search the web for current information",
  "parameters": {
    "query": "string (required)",
    "num_results": "integer (default: 10)",
    "language": "string (default: 'en')"
  }
}
```

### HTTP Requests
```json
{
  "name": "http_get",
  "description": "Make HTTP GET requests",
  "parameters": {
    "url": "string (required)",
    "headers": "object",
    "timeout": "integer"
  }
}
```

### Command Execution
```json
{
  "name": "run_command",
  "description": "Execute shell commands",
  "parameters": {
    "command": "string (required)",
    "working_directory": "string",
    "timeout": "integer"
  }
}
```

### Image Generation
```json
{
  "name": "generate_image",
  "description": "Generate images from text prompts",
  "parameters": {
    "prompt": "string (required)",
    "width": "integer (default: 512)",
    "height": "integer (default: 512)",
    "format": "string (default: 'png')"
  }
}
```

## Architecture

```
JustAi/
├── models/                    # AI model files
├── src/
│   ├── server/               # HTTP server and API
│   ├── model/                # Model integration
│   ├── tools/                # Tool implementations
│   ├── memory/               # Memory and caching
│   └── controller/           # Orchestration logic
├── data/                     # Database files
├── images/outputs/           # Generated images
└── logs/                     # Log files
```

### Core Components

- **Server**: Express.js HTTP server with OpenAI-compatible endpoints
- **Model**: node-llama-cpp integration for GGUF model inference
- **Tools**: Modular tool system with registry and execution
- **Memory**: SQLite database + in-memory caching
- **Controller**: Planning, normalization, and orchestration

## Tool Calling Examples

### System Information
```json
{
  "messages": [
    {"role": "user", "content": "Tell me about this computer system"}
  ]
}
```

### Web Search
```json
{
  "messages": [
    {"role": "user", "content": "Search for the latest news about AI"}
  ]
}
```

### Command Execution
```json
{
  "messages": [
    {"role": "user", "content": "List the files in the current directory"}
  ]
}
```

### Image Generation
```json
{
  "messages": [
    {"role": "user", "content": "Generate an image of a sunset over mountains"}
  ]
}
```

## Memory System

The system includes a sophisticated memory layer:

- **Short-term Cache**: In-memory caching for frequently accessed data
- **Long-term Storage**: SQLite database for persistent memories
- **Auto-summarization**: Automatic extraction and storage of key information
- **Context Injection**: Relevant memories automatically included in conversations

## Configuration

### Environment Variables

- `PORT`: Server port (default: 3000)
- `LOG_LEVEL`: Logging level (default: info)
- `MODEL_PATH`: Path to GGUF model file
- `CACHE_TTL`: Cache time-to-live in milliseconds

### Model Configuration

The system is configured to use `Qwen2.5-0.5B-Instruct-GGUF` by default. You can replace the model file in the `models/` directory with any compatible GGUF model.

## Development

### Project Structure

- `src/server/`: HTTP server and API endpoints
- `src/model/`: Model loading and inference
- `src/tools/`: Individual tool implementations
- `src/memory/`: Database, caching, and summarization
- `src/controller/`: Tool execution, planning, and normalization

### Adding New Tools

1. Create tool file in `src/tools/`
2. Implement required interface: `{ name, description, parameters, executor }`
3. Register tool in `src/tools/registry.js`
4. Add normalization rules in `src/controller/normalizer.js`
5. Add summarization rules in `src/memory/summarize.js`

### Testing

```bash
# Test health endpoint
curl http://localhost:3000/health

# Test models endpoint
curl http://localhost:3000/v1/models

# Test chat completion
curl -X POST http://localhost:3000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"Hello"}]}'
```

## Monitoring

### Health Check

- `GET /health`: Server health status
- `GET /v1/models`: Available models

### Logging

Logs are written to:
- Console (real-time)
- `logs/combined.log`: All logs
- `logs/error.log`: Error logs only

### Performance Metrics

The system tracks:
- Tool execution statistics
- Cache hit rates
- Memory usage
- Response times

## Security Considerations

- **Command Execution**: Tools have unrestricted system access
- **Network Access**: Web search and HTTP tools can access any URL
- **File System**: Generated content stored in configured directories
- **Memory**: Sensitive data may be cached in memory/database

## License

MIT License - see LICENSE file for details

## Contributing

1. Fork the repository
2. Create a feature branch
3. Implement your changes
4. Add tests and documentation
5. Submit a pull request

## Support

For issues and questions:
- Check the logs in `logs/` directory
- Review the health endpoint status
- Verify model file integrity
- Check system resources (RAM, disk space)