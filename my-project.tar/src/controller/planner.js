import { createLogger, format, transports } from 'winston';
import { toolExecutor } from './tool_executor.js';
import { outputNormalizer } from './normalizer.js';
import { storeMemory, getAllMemories } from '../memory/database.js';
import crypto from 'crypto';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
);

class Planner {
  constructor() {
    this.plans = new Map();
    this.activePlans = new Map();
  }

  async createPlan(userRequest, context = {}) {
    const planId = crypto.randomUUID();
    
    logger.info('Creating plan for user request', { planId, userRequest });

    // Analyze the request to determine required tools
    const analysis = await this.analyzeRequest(userRequest, context);
    
    const plan = {
      id: planId,
      user_request: userRequest,
      analysis: analysis,
      steps: this.generateSteps(analysis),
      status: 'created',
      current_step: 0,
      created_at: new Date().toISOString(),
      context: context
    };

    this.plans.set(planId, plan);
    
    logger.info('Plan created', { 
      planId, 
      stepCount: plan.steps.length,
      estimatedComplexity: analysis.complexity 
    });

    return plan;
  }

  async analyzeRequest(userRequest, context = {}) {
    const analysis = {
      intent: 'unknown',
      complexity: 'low',
      required_tools: [],
      estimated_steps: 1,
      requires_memory: false,
      requires_planning: false,
      keywords: [],
      entities: []
    };

    // Extract keywords and simple entities
    const keywords = this.extractKeywords(userRequest);
    analysis.keywords = keywords;

    // Determine intent and required tools
    if (this.containsAny(userRequest, ['system info', 'computer info', 'os info', 'hardware'])) {
      analysis.intent = 'system_information';
      analysis.required_tools.push('system_info');
      analysis.complexity = 'low';
    }

    if (this.containsAny(userRequest, ['search', 'find information', 'look up', 'web search'])) {
      analysis.intent = 'web_search';
      analysis.required_tools.push('web_search');
      analysis.complexity = 'medium';
    }

    if (this.containsAny(userRequest, ['download', 'fetch', 'get url', 'http request'])) {
      analysis.intent = 'http_request';
      analysis.required_tools.push('http_get');
      analysis.complexity = 'medium';
    }

    if (this.containsAny(userRequest, ['run command', 'execute', 'shell', 'terminal'])) {
      analysis.intent = 'command_execution';
      analysis.required_tools.push('run_command');
      analysis.complexity = 'high';
    }

    if (this.containsAny(userRequest, ['generate image', 'create image', 'make picture'])) {
      analysis.intent = 'image_generation';
      analysis.required_tools.push('generate_image');
      analysis.complexity = 'medium';
    }

    // Multi-step request detection
    if (this.containsAny(userRequest, ['and then', 'after that', 'also', 'additionally']) ||
        analysis.required_tools.length > 1) {
      analysis.requires_planning = true;
      analysis.estimated_steps = Math.max(2, analysis.required_tools.length);
      analysis.complexity = 'high';
    }

    // Memory requirements
    if (this.containsAny(userRequest, ['remember', 'save', 'store', 'keep track of'])) {
      analysis.requires_memory = true;
    }

    // Check if request requires current information
    if (this.containsAny(userRequest, ['current', 'latest', 'today', 'now', 'recent'])) {
      analysis.requires_current_data = true;
    }

    return analysis;
  }

  generateSteps(analysis) {
    const steps = [];
    
    if (analysis.required_tools.length === 0) {
      // Simple conversation, no tools needed
      steps.push({
        type: 'respond',
        description: 'Provide direct response to user query',
        tool: null,
        dependencies: []
      });
      return steps;
    }

    // Generate steps based on required tools
    const toolOrder = this.determineToolOrder(analysis.required_tools);
    
    toolOrder.forEach((toolName, index) => {
      const step = {
        type: 'tool_execution',
        description: `Execute ${toolName} to gather information`,
        tool: toolName,
        dependencies: index > 0 ? [steps[index - 1].id] : [],
        status: 'pending'
      };
      step.id = `step_${index + 1}`;
      steps.push(step);
    });

    // Add final synthesis step
    steps.push({
      type: 'synthesize',
      description: 'Synthesize results and provide comprehensive response',
      tool: null,
      dependencies: steps.filter(s => s.type === 'tool_execution').map(s => s.id),
      status: 'pending'
    });

    return steps;
  }

  determineToolOrder(requiredTools) {
    // Define tool execution priorities
    const priorities = {
      'system_info': 1,
      'web_search': 2,
      'http_get': 3,
      'run_command': 4,
      'exec_shell': 5,
      'generate_image': 6
    };

    return requiredTools
      .map(tool => ({ tool, priority: priorities[tool] || 999 }))
      .sort((a, b) => a.priority - b.priority)
      .map(item => item.tool);
  }

  extractKeywords(text) {
    // Simple keyword extraction
    const stopWords = ['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'can', 'this', 'that', 'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they', 'what', 'which', 'who', 'when', 'where', 'why', 'how'];
    
    return text.toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 2 && !stopWords.includes(word))
      .slice(0, 10);
  }

  containsAny(text, patterns) {
    return patterns.some(pattern => 
      text.toLowerCase().includes(pattern.toLowerCase())
    );
  }

  async executePlan(planId, context = {}) {
    const plan = this.plans.get(planId);
    if (!plan) {
      throw new Error(`Plan not found: ${planId}`);
    }

    logger.info('Executing plan', { planId, stepCount: plan.steps.length });
    
    this.activePlans.set(planId, {
      plan: plan,
      started_at: new Date().toISOString(),
      results: []
    });

    plan.status = 'executing';

    try {
      for (let i = 0; i < plan.steps.length; i++) {
        const step = plan.steps[i];
        plan.current_step = i + 1;
        
        logger.info('Executing step', { 
          planId, 
          stepId: step.id, 
          stepType: step.type,
          description: step.description 
        });

        step.status = 'executing';
        step.started_at = new Date().toISOString();

        try {
          const result = await this.executeStep(step, context, this.activePlans.get(planId));
          
          step.status = 'completed';
          step.completed_at = new Date().toISOString();
          step.result = result;
          
          this.activePlans.get(planId).results.push(result);
          
          logger.info('Step completed', { 
            planId, 
            stepId: step.id, 
            status: result.status 
          });

        } catch (error) {
          step.status = 'failed';
          step.error = error.message;
          step.failed_at = new Date().toISOString();
          
          logger.error('Step failed', { 
            planId, 
            stepId: step.id, 
            error: error.message 
          });
          
          throw error;
        }
      }

      plan.status = 'completed';
      plan.completed_at = new Date().toISOString();
      
      const finalResult = this.synthesizeResults(plan);
      
      this.activePlans.delete(planId);
      
      logger.info('Plan execution completed', { planId });
      
      return finalResult;

    } catch (error) {
      plan.status = 'failed';
      plan.failed_at = new Date().toISOString();
      plan.error = error.message;
      
      this.activePlans.delete(planId);
      
      logger.error('Plan execution failed', { planId, error: error.message });
      
      throw error;
    }
  }

  async executeStep(step, context, executionContext) {
    switch (step.type) {
      case 'tool_execution':
        return await this.executeToolStep(step, context, executionContext);
      
      case 'synthesize':
        return await this.synthesizeStep(step, context, executionContext);
      
      case 'respond':
        return await this.respondStep(step, context, executionContext);
      
      default:
        throw new Error(`Unknown step type: ${step.type}`);
    }
  }

  async executeToolStep(step, context, executionContext) {
    // For now, we'll need to extract tool arguments from the user request
    // In a more sophisticated implementation, you could use LLM to extract parameters
    
    const toolArgs = this.extractToolArguments(step.tool, executionContext.plan.user_request, context);
    
    const toolCall = {
      id: crypto.randomUUID(),
      type: 'function',
      function: {
        name: step.tool,
        arguments: JSON.stringify(toolArgs)
      }
    };

    const results = await toolExecutor.executeToolCalls([toolCall], context);
    
    return results[0];
  }

  async synthesizeStep(step, context, executionContext) {
    const previousResults = executionContext.results;
    
    // Create a summary of all previous results
    const synthesis = {
      status: 'success',
      summary: `Synthesized ${previousResults.length} tool execution results`,
      data: {
        tool_results: previousResults,
        synthesis_summary: this.createSynthesisSummary(previousResults)
      },
      artifacts: [],
      timestamp: new Date().toISOString()
    };

    return synthesis;
  }

  async respondStep(step, context, executionContext) {
    // For simple responses without tools
    return {
      status: 'success',
      summary: 'Direct response provided',
      data: {
        response: 'Processing your request...',
        requires_model: true
      },
      artifacts: [],
      timestamp: new Date().toISOString()
    };
  }

  extractToolArguments(toolName, userRequest, context) {
    // Simple argument extraction - in production, you'd use more sophisticated NLP
    const args = {};

    switch (toolName) {
      case 'system_info':
        args.include_network = userRequest.toLowerCase().includes('network');
        args.include_processes = userRequest.toLowerCase().includes('process');
        break;

      case 'web_search':
        // Extract search query - very basic implementation
        const searchMatch = userRequest.match(/(?:search|find).+?(?:for|about)\s+(.+?)(?:\.(?:\s|$)|$|\?)/i);
        if (searchMatch) {
          args.query = searchMatch[1].trim();
        } else {
          args.query = userRequest; // Fallback to full request
        }
        args.num_results = 10;
        break;

      case 'http_get':
        // Extract URL - very basic implementation
        const urlMatch = userRequest.match(/https?:\/\/[^\s]+/i);
        if (urlMatch) {
          args.url = urlMatch[0];
        }
        break;

      case 'run_command':
      case 'exec_shell':
        // Extract command - very basic implementation
        const commandMatch = userRequest.match(/(?:run|execute)\s+["']?([^"']+)["']?/i);
        if (commandMatch) {
          args.command = commandMatch[1];
        }
        break;

      case 'generate_image':
        // Extract prompt - very basic implementation
        const promptMatch = userRequest.match(/(?:generate|create).+?(?:image|picture).+?(?:of|described as)\s+(.+?)(?:\.(?:\s|$)|$|\?)/i);
        if (promptMatch) {
          args.prompt = promptMatch[1].trim();
        } else {
          args.prompt = userRequest; // Fallback
        }
        args.width = 512;
        args.height = 512;
        break;
    }

    return args;
  }

  createSynthesisSummary(results) {
    const summaries = results.map(result => {
      if (result.result && result.result.summary) {
        return result.result.summary;
      }
      return `Tool ${result.tool_name} executed with status: ${result.status}`;
    });

    return summaries.join('; ');
  }

  synthesizeResults(plan) {
    const results = plan.steps
      .filter(step => step.result)
      .map(step => step.result);

    return {
      plan_id: plan.id,
      status: plan.status,
      summary: `Plan completed with ${results.length} steps executed`,
      data: {
        original_request: plan.user_request,
        analysis: plan.analysis,
        steps_executed: plan.steps.length,
        results: results,
        execution_summary: this.createExecutionSummary(plan)
      },
      artifacts: this.extractArtifactsFromResults(results),
      timestamp: new Date().toISOString()
    };
  }

  createExecutionSummary(plan) {
    const completedSteps = plan.steps.filter(step => step.status === 'completed');
    const failedSteps = plan.steps.filter(step => step.status === 'failed');
    
    return {
      total_steps: plan.steps.length,
      completed_steps: completedSteps.length,
      failed_steps: failedSteps.length,
      execution_time: plan.completed_at ? 
        new Date(plan.completed_at) - new Date(plan.created_at) : 
        null,
      tools_used: plan.analysis.required_tools
    };
  }

  extractArtifactsFromResults(results) {
    const artifacts = [];
    
    results.forEach(result => {
      if (result.result && result.result.artifacts) {
        artifacts.push(...result.result.artifacts);
      }
    });

    return artifacts;
  }

  getPlan(planId) {
    return this.plans.get(planId);
  }

  getAllPlans() {
    return Array.from(this.plans.values());
  }

  getActivePlans() {
    return Array.from(this.activePlans.entries()).map(([id, execution]) => ({
      plan_id: id,
      plan: execution.plan,
      started_at: execution.started_at,
      current_step: execution.plan.current_step,
      total_steps: execution.plan.steps.length
    }));
  }

  cancelPlan(planId) {
    const plan = this.plans.get(planId);
    if (plan && (plan.status === 'created' || plan.status === 'executing')) {
      plan.status = 'cancelled';
      plan.cancelled_at = new Date().toISOString();
      this.activePlans.delete(planId);
      
      logger.info('Plan cancelled', { planId });
      return true;
    }
    return false;
  }
}

export const planner = new Planner();
export { Planner };