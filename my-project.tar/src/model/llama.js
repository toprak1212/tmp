import { createLogger, format, transports } from 'winston';
import path from 'path';
import { fileURLToPath } from 'url';
import { getLlama, LlamaChatSession } from 'node-llama-cpp';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

let modelInitialized = false;
let llama = null;
let model = null;
let context = null;

async function initializeModel() {
  try {
    logger.info('Initializing LLaMA model...');
    
    const modelPath = path.join(__dirname, '../../models/qwen2.5-0.5b-instruct-q4_k_m.gguf');
    
    // Check if model file exists
    try {
      const fs = await import('fs/promises');
      await fs.access(modelPath);
      logger.info('Model file found at:', modelPath);
    } catch (error) {
      throw new Error(`Model file not found at: ${modelPath}`);
    }

    // Actually load the model using node-llama-cpp
    logger.info('Loading Qwen2.5 model...');
    llama = await getLlama();
    model = await llama.loadModel({
      modelPath: modelPath,
      nCtx: 4096,
      nGpuLayers: 0,
      useMlock: true,
      embedding: false,
      threads: 4
    });

    // Create context for the model
    context = await model.createContext({
      nCtx: 4096,
      threads: 4
    });

    modelInitialized = true;
    logger.info('Model and context initialized successfully');
    return true;
  } catch (error) {
    logger.error('Failed to initialize model:', error);
    throw error;
  }
}

async function generateChatCall(originalContent, lowerContent) {
  // IMPORTANT: Always use the loaded model. If model not loaded, say it crystal clear.
  if (!modelInitialized || !model) {
    return "MODEL NOT LOADED. CANNOT PROCESS REQUEST.";
  }
  
  // Send message directly to AI without any mapping or pattern matching
  try {
    // Use the existing LLaMA model integration
    const messages = [
      { role: 'system', content: 'You are a helpful assistant.' },
      { role: 'user', content: originalContent }
    ];
    
    // Generate response using LLaMA model
    const response = await model(messages.map(m => `${m.role}: ${m.content}`).join('\n'), {
      max_tokens: 4096,
      temperature: 0.7,
      stop: ['user:', 'assistant:', 'system:']
    });
    
    return response.trim() || "MODEL ERROR. CANNOT PROCESS REQUEST.";
  } catch (error) {
    logger.error('LLaMA model error in generateChatCall:', error);
    return "MODEL ERROR. CANNOT PROCESS REQUEST.";
  }
}

async function generateAIResponse(messages, options = {}) {
  // IMPORTANT: Always use loaded model. If model not loaded, say it crystal clear.
  if (!modelInitialized || !model || !context) {
    return "MODEL NOT LOADED. CANNOT PROCESS REQUEST.";
  }
  
  // DIRECT call to model - NO logic at all
  try {
    // Create prompt from messages
    const prompt = messages.map(m => `${m.role}: ${m.content}`).join('\n');
    
    // Direct model call using correct pattern from example
    const response = await llama.createCompletion({
      prompt: prompt,
      nPredict: 2048,
      temperature: options.temperature || 0.7
    });
    
    return response || "MODEL ERROR. CANNOT PROCESS REQUEST.";
  } catch (error) {
    logger.error('LLaMA model error in generateAIResponse:', error);
    return "MODEL ERROR. CANNOT PROCESS REQUEST.";
  }
}

async function generateCompletion(messages, options = {}) {
  if (!modelInitialized) {
    throw new Error('Model not initialized. Call initializeModel() first.');
  }

  try {
    logger.info('Generating completion...', { 
      messageCount: messages.length,
      maxTokens: options.maxTokens || 4096
    });

    // Check if there are NO / commands - if so, use AI model directly
    const hasToolCommand = messages.some(m => 
      m.role === 'user' && isToolRequest(m.content)
    );
    
    if (!hasToolCommand) {
      // Use AI model for natural conversation
      const completion = await generateAIResponse(messages, options);
      
      logger.info('AI completion generated', { 
        responseLength: completion.length,
        maxTokens: options.maxTokens || 4096
      });
      
      return completion;
    }

    // Fallback to tool detection for messages without system prompts
    const completion = generateEnhancedFallbackResponse(messages);

    logger.info('Fallback completion generated', { 
      responseLength: completion.length,
      maxTokens: options.maxTokens || 4096
    });

    // Ensure we don't exceed max tokens
    const maxTokens = options.maxTokens || 4096;
    if (completion.length > maxTokens) {
      logger.warn('Response truncated due to token limit', { 
        originalLength: completion.length,
        maxTokens: maxTokens 
      });
      return completion.substring(0, maxTokens);
    }

    return completion.trim();
  } catch (error) {
    logger.error('Failed to generate completion:', error);
    throw error;
  }
}

function generateEnhancedFallbackResponse(messages) {
  const lastUserMessage = messages.filter(m => m.role === 'user').pop();
  
  // Check if we already have tool results in conversation
  const hasToolResults = messages.some(m => m.role === 'tool');
  
  // Check for exact / commands - only these use tools
  if (lastUserMessage && !hasToolResults) {
    if (isToolRequest(lastUserMessage.content)) {
      const toolCall = generateToolCall(lastUserMessage.content, lastUserMessage.content);
      if (toolCall) {
        return toolCall;
      }
    }
  }

  // If we have tool results, synthesize a response
  if (hasToolResults) {
    const toolResults = messages.filter(m => m.role === 'tool');
    if (toolResults.length > 0) {
      const result = toolResults[0].content;
      // Return the full tool result without truncation
      return `I've successfully executed your request. Here are the results:\n\n${result}`;
    }
  }

  // Natural conversation response
  return generateAIResponse(messages, options);
}

function isToolRequest(content) {
  // Only check for exact / command prefixes - no natural language detection
  const trimmedContent = content.trim();
  
  // Exact command prefix patterns only
  if (trimmedContent === '/info' || trimmedContent.startsWith('/info ')) {
    return true;
  }
  
  if (trimmedContent === '/search' || trimmedContent.startsWith('/search ')) {
    return true;
  }
  
  if (trimmedContent === '/cmd' || trimmedContent.startsWith('/cmd ')) {
    return true;
  }
  
  if (trimmedContent === '/image' || trimmedContent.startsWith('/image ')) {
    return true;
  }
  
  if (trimmedContent === '/get' || trimmedContent.startsWith('/get ')) {
    return true;
  }
  
  return false;
}

function generateToolCall(originalContent, lowerContent) {
  const trimmedContent = originalContent.trim();
  
  // System info tool (/info) - exact command only
  if (trimmedContent === '/info' || trimmedContent.startsWith('/info ')) {
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function",
        function: {
          name: "system_info",
          arguments: JSON.stringify({ include_network: false, include_processes: false })
        }
      }]
    });
  }
  
  // Web search tool (/search) - exact command only
  if (trimmedContent === '/search' || trimmedContent.startsWith('/search ')) {
    const query = trimmedContent.startsWith('/search ') ? trimmedContent.substring(8).trim() : "latest news";
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function", 
        function: {
          name: "web_search",
          arguments: JSON.stringify({ query: query, num_results: 5 })
        }
      }]
    });
  }
  
  // Command execution tool (/cmd) - exact command only
  if (trimmedContent === '/cmd' || trimmedContent.startsWith('/cmd ')) {
    let command = "echo 'Hello from JustAI!'";
    
    if (trimmedContent.startsWith('/cmd ')) {
      command = trimmedContent.substring(5).trim();
    }
    
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function",
        function: {
          name: "run_command",
          arguments: JSON.stringify({ command: command, capture_output: true })
        }
      }]
    });
  }
  
  // Image generation tool (/image) - exact command only
  if (trimmedContent === '/image' || trimmedContent.startsWith('/image ')) {
    let prompt = "AI generated image";
    
    if (trimmedContent.startsWith('/image ')) {
      prompt = trimmedContent.substring(7).trim();
    }
    
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function",
        function: {
          name: "generate_image",
          arguments: JSON.stringify({ prompt: prompt, width: 512, height: 512, format: 'png', method: 'web' })
        }
      }]
    });
  }
  
  // HTTP GET tool (/get) - exact command only
  if (trimmedContent === '/get' || trimmedContent.startsWith('/get ')) {
    let url = "";
    if (trimmedContent.startsWith('/get ')) {
      url = trimmedContent.substring(5).trim();
    }
    
    return JSON.stringify({
      tool_calls: [{
        id: "call_" + Date.now(),
        type: "function",
        function: {
          name: "http_get",
          arguments: JSON.stringify({ url: url })
        }
      }]
    });
  }
  
  return null;
}

function getModelInfo() {
  return {
    loaded: modelInitialized && model !== null,
    modelPath: modelInitialized && model !== null ? path.join(__dirname, '../../models/qwen2.5-0.5b-instruct-q4_k_m.gguf') : null,
    contextSize: 4096,
    gpuLayers: 0,
    llamaVersion: null,
    fallback: false,
    enhanced: true
  };
}

export { 
  initializeModel, 
  generateCompletion, 
  generateChatCall,
  getModelInfo,
  isToolRequest
};