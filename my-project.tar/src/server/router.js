import { Router } from 'express';
import { chatCompletionsHandler } from './api.js';

const router = Router();

// OpenAI-compatible chat completions endpoint
router.post('/chat/completions', chatCompletionsHandler);

// Models endpoint (for OpenAI compatibility)
router.get('/models', (req, res) => {
  res.json({
    object: 'list',
    data: [
      {
        id: 'qwen2.5-0.5b-instruct',
        object: 'model',
        created: Math.floor(Date.now() / 1000),
        owned_by: 'JustAI',
        permission: [],
        root: 'qwen2.5-0.5b-instruct',
        parent: null
      }
    ]
  });
});

export { router as apiRouter };