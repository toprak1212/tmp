import { createLogger, format, transports } from 'winston';
import { spawn } from 'child_process';
import fs from 'fs/promises';
import path from 'path';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

export const execShellTool = {
  name: 'exec_shell',
  description: 'Execute shell commands with real-time output streaming and interactive capabilities',
  parameters: {
    type: 'object',
    properties: {
      command: {
        type: 'string',
        description: 'Shell command to execute'
      },
      shell: {
        type: 'string',
        description: 'Shell interpreter to use (default: /bin/bash)',
        default: '/bin/bash'
      },
      working_directory: {
        type: 'string',
        description: 'Directory to execute the command in (default: current directory)',
        default: null
      },
      timeout: {
        type: 'integer',
        description: 'Command timeout in milliseconds (default: 60000)',
        default: 60000
      },
      env: {
        type: 'object',
        description: 'Additional environment variables for the command',
        default: {}
      },
      interactive: {
        type: 'boolean',
        description: 'Whether to run in interactive mode (default: false)',
        default: false
      }
    },
    required: ['command']
  },
  executor: async (args) => {
    return new Promise((resolve) => {
      const startTime = Date.now();
      const outputLines = [];
      const errorLines = [];
      
      try {
        const env = { ...process.env, ...args.env };
        const cwd = args.working_directory || process.cwd();
        
        const child = spawn(args.shell, ['-c', args.command], {
          cwd: cwd,
          env: env,
          stdio: args.interactive ? 'inherit' : 'pipe',
          timeout: args.timeout
        });

        let timeoutId;
        
        if (args.timeout) {
          timeoutId = setTimeout(() => {
            child.kill('SIGTERM');
            resolve({
              status: 'timeout',
              summary: `Command timed out after ${args.timeout}ms: "${args.command}"`,
              data: {
                command: args.command,
                working_directory: cwd,
                exit_code: null,
                execution_time_ms: args.timeout,
                stdout: outputLines.join('\n'),
                stderr: errorLines.join('\n'),
                timeout: true
              },
              artifacts: [],
              timestamp: new Date().toISOString()
            });
          }, args.timeout);
        }

        if (!args.interactive) {
          child.stdout?.on('data', (data) => {
            const lines = data.toString().split('\n');
            lines.forEach(line => {
              if (line.trim()) outputLines.push(line);
            });
          });

          child.stderr?.on('data', (data) => {
            const lines = data.toString().split('\n');
            lines.forEach(line => {
              if (line.trim()) errorLines.push(line);
            });
          });
        }

        child.on('close', (code, signal) => {
          if (timeoutId) clearTimeout(timeoutId);
          
          const endTime = Date.now();
          const executionTime = endTime - startTime;

          const response = {
            status: code === 0 ? 'success' : 'error',
            summary: `Command ${code === 0 ? 'completed' : 'failed'} with exit code ${code}: "${args.command}"`,
            data: {
              command: args.command,
              working_directory: cwd,
              exit_code: code,
              signal: signal,
              execution_time_ms: executionTime,
              stdout: args.interactive ? '[Interactive mode - output not captured]' : outputLines.join('\n'),
              stderr: args.interactive ? '[Interactive mode - error output not captured]' : errorLines.join('\n'),
              interactive: args.interactive
            },
            artifacts: [],
            timestamp: new Date().toISOString()
          };

          // Store large outputs as artifacts
          if (!args.interactive) {
            if (outputLines.join('\n').length > 10000) {
              response.data.stdout_preview = outputLines.slice(0, 100).join('\n') + '\n...';
              response.data.stdout = '[Output truncated due to size. Full output available in artifacts.]';
              
              response.artifacts.push({
                type: 'shell_output',
                filename: `shell_stdout_${Date.now()}.txt`,
                content: outputLines.join('\n'),
                size: outputLines.join('\n').length
              });
            }

            if (errorLines.join('\n').length > 10000) {
              response.data.stderr_preview = errorLines.slice(0, 100).join('\n') + '\n...';
              response.data.stderr = '[Error output truncated due to size. Full output available in artifacts.]';
              
              response.artifacts.push({
                type: 'shell_error',
                filename: `shell_stderr_${Date.now()}.txt`,
                content: errorLines.join('\n'),
                size: errorLines.join('\n').length
              });
            }
          }

          resolve(response);
        });

        child.on('error', (error) => {
          if (timeoutId) clearTimeout(timeoutId);
          
          const endTime = Date.now();
          const executionTime = endTime - startTime;

          resolve({
            status: 'error',
            summary: `Failed to execute command: "${args.command}" - ${error.message}`,
            data: {
              command: args.command,
              working_directory: cwd,
              exit_code: null,
              execution_time_ms: executionTime,
              stdout: '',
              stderr: '',
              error: error.message
            },
            artifacts: [],
            timestamp: new Date().toISOString()
          });
        });

      } catch (error) {
        logger.error('Exec shell tool error:', error);
        
        resolve({
          status: 'error',
          summary: `Failed to start command execution: "${args.command}" - ${error.message}`,
          data: {
            command: args.command,
            working_directory: args.working_directory || process.cwd(),
            exit_code: null,
            execution_time_ms: 0,
            stdout: '',
            stderr: '',
            error: error.message
          },
          artifacts: [],
          timestamp: new Date().toISOString()
        });
      }
    });
  }
};