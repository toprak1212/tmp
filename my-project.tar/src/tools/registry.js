import { createLogger, format, transports } from 'winston';
import { systemInfoTool } from './system_info.js';
import { webSearchTool } from './web_search.js';
import { httpGetTool } from './http_get.js';
import { runCommandTool } from './run_command.js';
import { execShellTool } from './exec_shell.js';
import { generateImageTool } from './generate_image.js';
import crypto from 'crypto';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console({ format: format.simple() })
  ]
});

class ToolRegistry {
  constructor() {
    this.tools = new Map();
    this.executionHistory = [];
    this.registerDefaultTools();
  }

  registerDefaultTools() {
    this.registerTool(systemInfoTool);
    this.registerTool(webSearchTool);
    this.registerTool(httpGetTool);
    this.registerTool(runCommandTool);
    this.registerTool(execShellTool);
    this.registerTool(generateImageTool);
  }

  registerTool(tool) {
    if (!tool.name || !tool.description || !tool.executor) {
      throw new Error('Tool must have name, description, and executor');
    }

    this.tools.set(tool.name, tool);
    logger.info(`Registered tool: ${tool.name}`);
  }

  getTool(name) {
    return this.tools.get(name);
  }

  getAllTools() {
    return Array.from(this.tools.values()).map(tool => ({
      name: tool.name,
      description: tool.description,
      parameters: tool.parameters
    }));
  }

  async executeTool(toolName, args, context = {}) {
    const tool = this.getTool(toolName);
    if (!tool) {
      throw new Error(`Tool not found: ${toolName}`);
    }

    const executionId = crypto.randomUUID();
    const startTime = Date.now();

    logger.info('Executing tool', { 
      toolName, 
      args, 
      executionId,
      context 
    });

    try {
      // Validate arguments against tool parameters
      this.validateArguments(tool, args);

      // Execute the tool
      const result = await tool.executor(args, context);

      const endTime = Date.now();
      const executionTime = endTime - startTime;

      // Add execution metadata
      const enhancedResult = {
        ...result,
        execution: {
          id: executionId,
          tool_name: toolName,
          args: args,
          execution_time_ms: executionTime,
          timestamp: new Date().toISOString()
        }
      };

      // Store in execution history
      this.executionHistory.push({
        id: executionId,
        tool_name: toolName,
        args: args,
        result: enhancedResult,
        timestamp: new Date().toISOString()
      });

      // Keep history size manageable
      if (this.executionHistory.length > 1000) {
        this.executionHistory = this.executionHistory.slice(-500);
      }

      logger.info('Tool execution completed', {
        toolName,
        executionId,
        executionTime,
        status: enhancedResult.status
      });

      return enhancedResult;
    } catch (error) {
      const endTime = Date.now();
      const executionTime = endTime - startTime;

      const errorResult = {
        status: 'error',
        summary: `Tool execution failed: ${error.message}`,
        data: {
          error: error.message,
          stack: error.stack
        },
        artifacts: [],
        execution: {
          id: executionId,
          tool_name: toolName,
          args: args,
          execution_time_ms: executionTime,
          timestamp: new Date().toISOString()
        },
        timestamp: new Date().toISOString()
      };

      // Store failed execution in history
      this.executionHistory.push({
        id: executionId,
        tool_name: toolName,
        args: args,
        result: errorResult,
        timestamp: new Date().toISOString()
      });

      logger.error('Tool execution failed', {
        toolName,
        executionId,
        error: error.message
      });

      return errorResult;
    }
  }

  validateArguments(tool, args) {
    if (!tool.parameters) return;

    const { properties, required = [] } = tool.parameters;

    // Check required arguments
    for (const requiredArg of required) {
      if (!(requiredArg in args)) {
        throw new Error(`Missing required argument: ${requiredArg}`);
      }
    }

    // Check argument types and constraints
    for (const [argName, argValue] of Object.entries(args)) {
      const argSchema = properties?.[argName];
      if (!argSchema) continue;

      // Type validation
      if (argSchema.type) {
        let actualType = typeof argValue;
        
        // Handle integer vs number distinction
        if (argSchema.type === 'integer' && actualType === 'number' && Number.isInteger(argValue)) {
          // This is fine, it's an integer
        } else if (argSchema.type === 'number' && actualType === 'number') {
          // This is fine, it's a number
        } else if (actualType !== argSchema.type) {
          throw new Error(`Argument ${argName} must be of type ${argSchema.type}, got ${actualType}`);
        }
      }

      // Range validation for numbers
      if (typeof argValue === 'number') {
        if (argSchema.minimum !== undefined && argValue < argSchema.minimum) {
          throw new Error(`Argument ${argName} must be >= ${argSchema.minimum}, got ${argValue}`);
        }
        if (argSchema.maximum !== undefined && argValue > argSchema.maximum) {
          throw new Error(`Argument ${argName} must be <= ${argSchema.maximum}, got ${argValue}`);
        }
      }

      // Enum validation
      if (argSchema.enum && !argSchema.enum.includes(argValue)) {
        throw new Error(`Argument ${argName} must be one of: ${argSchema.enum.join(', ')}, got ${argValue}`);
      }
    }
  }

  getExecutionHistory(toolName = null, limit = 50) {
    let history = this.executionHistory;
    
    if (toolName) {
      history = history.filter(exec => exec.tool_name === toolName);
    }

    return history.slice(-limit).reverse();
  }

  getToolStats() {
    const stats = {};
    
    for (const execution of this.executionHistory) {
      const toolName = execution.tool_name;
      if (!stats[toolName]) {
        stats[toolName] = {
          total_executions: 0,
          successful_executions: 0,
          failed_executions: 0,
          total_execution_time_ms: 0,
          average_execution_time_ms: 0
        };
      }

      const toolStats = stats[toolName];
      toolStats.total_executions++;
      
      if (execution.result.status === 'success') {
        toolStats.successful_executions++;
      } else {
        toolStats.failed_executions++;
      }
      
      toolStats.total_execution_time_ms += execution.result.execution.execution_time_ms;
      toolStats.average_execution_time_ms = toolStats.total_execution_time_ms / toolStats.total_executions;
    }

    return stats;
  }

  clearHistory() {
    this.executionHistory = [];
    logger.info('Tool execution history cleared');
  }
}

export const toolRegistry = new ToolRegistry();
export { ToolRegistry };