import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    // Accept any API key - no validation required
    const apiKey = request.headers.get('authorization');
    
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const model = formData.get('model') as string || 'whisper-1';
    const language = formData.get('language') as string || 'en';
    const responseFormat = formData.get('response_format') as string || 'json';
    const temperature = parseFloat(formData.get('temperature') as string) || 0.0;

    if (!file) {
      return NextResponse.json(
        { error: { message: 'Audio file is required' } },
        { status: 400 }
      );
    }

    // Convert file to buffer
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // Initialize ZAI
    const zai = await ZAI.create();

    // Create translation request
    const translation = await zai.audio.translations.create({
      file: buffer,
      model: model,
      language: language,
      response_format: responseFormat,
      temperature: temperature,
    });

    return NextResponse.json(translation);

  } catch (error: any) {
    console.error('Translation error:', error);
    return NextResponse.json(
      { 
        error: {
          message: error.message || 'An error occurred during translation',
          type: 'invalid_request_error'
        }
      },
      { status: 500 }
    );
  }
}

// Handle OPTIONS requests for CORS
export async function OPTIONS() {
  return new Response(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}