import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

interface ChatMessage {
  role: string;
  content: string;
}

interface ChatCompletionRequest {
  model: string;
  messages: ChatMessage[];
  stream?: boolean;
  temperature?: number;
  max_tokens?: number;
  top_p?: number;
  frequency_penalty?: number;
  presence_penalty?: number;
}

// Helper function to convert OpenAI model names to ZAI model names
function getZAIModel(openaiModel: string): string {
  const modelMap: { [key: string]: string } = {
    // OpenAI models
    'gpt-4o': 'gpt-4o',
    'gpt-4o-mini': 'gpt-4o-mini',
    'gpt-4.1': 'gpt-4-turbo',
    'gpt-4-turbo': 'gpt-4-turbo',
    'gpt-3.5-turbo': 'gpt-3.5-turbo',
    
    // Anthropic models
    'claude-3-opus': 'claude-3-opus-20240229',
    'claude-3-sonnet': 'claude-3-sonnet-20240229',
    'claude-3-haiku': 'claude-3-haiku-20240307',
    
    // Google models
    'gemini-pro': 'gemini-pro',
    'gemini-pro-vision': 'gemini-pro-vision',
    
    // Meta models
    'llama-3.1-70b': 'llama-3.1-70b',
    'llama-3.1-8b': 'llama-3.1-8b',
    
    // Mistral models
    'mixtral-8x7b': 'mixtral-8x7b',
    'mistral-7b': 'mistral-7b',
    
    // Zhipu models
    'glm-4.6': 'glm-4',
    
    // Alibaba models
    'qwen-2.5-72b': 'qwen-2.5-72b',
    'qwen-2.5-32b': 'qwen-2.5-32b',
    
    // DeepSeek models
    'deepseek-v2': 'deepseek-v2',
    
    // 01.AI models
    'yi-large': 'yi-large',
    
    // Cohere models
    'command-r-plus': 'command-r-plus',
    
    // Whisper models (Speech-to-Text)
    'whisper-1': 'whisper-1',
    'whisper-large-v3': 'whisper-large-v3',
    'whisper-medium': 'whisper-medium',
    'whisper-small': 'whisper-small',
    'whisper-base': 'whisper-base'
  };
  return modelMap[openaiModel] || openaiModel;
}

// Helper function to create OpenAI format response
function createOpenAIResponse(content: string, model: string, finishReason: string = 'stop') {
  return {
    id: `chatcmpl-${Math.random().toString(36).substring(7)}`,
    object: 'chat.completion',
    created: Math.floor(Date.now() / 1000),
    model: model,
    choices: [{
      index: 0,
      message: {
        role: 'assistant',
        content: content,
      },
      finish_reason: finishReason,
    }],
    usage: {
      prompt_tokens: 0,
      completion_tokens: 0,
      total_tokens: 0,
    },
  };
}

// Helper function to create streaming chunk
function createStreamChunk(content: string, model: string, finishReason: string = null) {
  const chunk = {
    id: `chatcmpl-${Math.random().toString(36).substring(7)}`,
    object: 'chat.completion.chunk',
    created: Math.floor(Date.now() / 1000),
    model: model,
    choices: [{
      index: 0,
      delta: finishReason ? {} : { content: content },
      finish_reason: finishReason,
    }],
  };
  
  return `data: ${JSON.stringify(chunk)}\n\n`;
}

export async function POST(request: NextRequest) {
  try {
    // Accept any API key - no validation required
    const apiKey = request.headers.get('authorization');
    
    const body: ChatCompletionRequest = await request.json();
    const { model, messages, stream = false, ...params } = body;

    if (!model || !messages) {
      return NextResponse.json(
        { error: { message: 'Model and messages are required' } },
        { status: 400 }
      );
    }

    // Initialize ZAI
    const zai = await ZAI.create();

    // Convert messages to ZAI format
    const zaiMessages = messages.map(msg => ({
      role: msg.role,
      content: msg.content
    }));

    const zaiModel = getZAIModel(model);

    if (stream) {
      // Streaming response
      const encoder = new TextEncoder();
      const stream = new ReadableStream({
        async start(controller) {
          try {
            const completion = await zai.chat.completions.create({
              messages: zaiMessages,
              model: zaiModel,
              stream: true,
              ...params
            });

            // Handle streaming response
            for await (const chunk of completion) {
              const content = chunk.choices[0]?.delta?.content || '';
              if (content) {
                const streamChunk = createStreamChunk(content, model);
                controller.enqueue(encoder.encode(streamChunk));
              }
            }

            // Send final chunk
            const finalChunk = createStreamChunk('', model, 'stop');
            controller.enqueue(encoder.encode(finalChunk));
            controller.enqueue(encoder.encode('data: [DONE]\n\n'));
            
          } catch (error) {
            const errorChunk = createStreamChunk(`Error: ${error.message}`, model, 'error');
            controller.enqueue(encoder.encode(errorChunk));
            controller.enqueue(encoder.encode('data: [DONE]\n\n'));
          } finally {
            controller.close();
          }
        }
      });

      return new Response(stream, {
        headers: {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        },
      });
    } else {
      // Non-streaming response
      const completion = await zai.chat.completions.create({
        messages: zaiMessages,
        model: zaiModel,
        ...params
      });

      const content = completion.choices[0]?.message?.content || '';
      const response = createOpenAIResponse(content, model);

      return NextResponse.json(response);
    }
  } catch (error: any) {
    console.error('Chat completion error:', error);
    return NextResponse.json(
      { 
        error: {
          message: error.message || 'An error occurred during chat completion',
          type: 'invalid_request_error'
        }
      },
      { status: 500 }
    );
  }
}

// Handle OPTIONS requests for CORS
export async function OPTIONS() {
  return new Response(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}