import { NextRequest, NextResponse } from 'next/server';

const MODELS = [
  {
    id: 'glm-4.6',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'zhipu',
  },
  {
    id: 'claude-3-opus',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'anthropic',
  },
  {
    id: 'claude-3-sonnet',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'anthropic',
  },
  {
    id: 'claude-3-haiku',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'anthropic',
  },
  {
    id: 'gpt-4o',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'openai',
  },
  {
    id: 'gpt-4o-mini',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'openai',
  },
  {
    id: 'gpt-4.1',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'openai',
  },
  {
    id: 'gpt-4-turbo',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'openai',
  },
  {
    id: 'gpt-3.5-turbo',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'openai',
  },
  {
    id: 'gemini-pro',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'google',
  },
  {
    id: 'gemini-pro-vision',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'google',
  },
  {
    id: 'llama-3.1-70b',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'meta',
  },
  {
    id: 'llama-3.1-8b',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'meta',
  },
  {
    id: 'mixtral-8x7b',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'mistral',
  },
  {
    id: 'mistral-7b',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'mistral',
  },
  {
    id: 'qwen-2.5-72b',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'alibaba',
  },
  {
    id: 'qwen-2.5-32b',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'alibaba',
  },
  {
    id: 'deepseek-v2',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'deepseek',
  },
  {
    id: 'yi-large',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: '01-ai',
  },
  {
    id: 'command-r-plus',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'cohere',
  },
  {
    id: 'whisper-1',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'openai',
  },
  {
    id: 'whisper-large-v3',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'openai',
  },
  {
    id: 'whisper-medium',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'openai',
  },
  {
    id: 'whisper-small',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'openai',
  },
  {
    id: 'whisper-base',
    object: 'model',
    created: Math.floor(Date.now() / 1000),
    owned_by: 'openai',
  }
];

export async function GET(request: NextRequest) {
  // Accept any API key - no validation required
  const apiKey = request.headers.get('authorization');
  
  return NextResponse.json({
    object: 'list',
    data: MODELS
  });
}