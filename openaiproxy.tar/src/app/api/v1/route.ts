import { NextRequest, NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    message: 'OpenAI Compatible API Service',
    version: 'v1',
    endpoints: {
      models: '/api/v1/models',
      chat: '/api/v1/chat/completions',
      transcriptions: '/api/v1/audio/transcriptions',
      translations: '/api/v1/audio/translations'
    },
    supported_models: [
      'glm-4.6',
      'claude-3-opus',
      'claude-3-sonnet',
      'claude-3-haiku',
      'gpt-4o',
      'gpt-4o-mini',
      'gpt-4.1',
      'gpt-4-turbo',
      'gpt-3.5-turbo',
      'gemini-pro',
      'gemini-pro-vision',
      'llama-3.1-70b',
      'llama-3.1-8b',
      'mixtral-8x7b',
      'mistral-7b',
      'qwen-2.5-72b',
      'qwen-2.5-32b',
      'deepseek-v2',
      'yi-large',
      'command-r-plus',
      'whisper-1',
      'whisper-large-v3',
      'whisper-medium',
      'whisper-small',
      'whisper-base'
    ]
  });
}