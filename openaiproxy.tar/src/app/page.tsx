'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Copy, Send, Play, Square, CheckCircle, XCircle, Info, Upload, FileAudio, Mic } from 'lucide-react';

interface Model {
  id: string;
  object: string;
  created: number;
  owned_by: string;
}

interface ChatMessage {
  role: string;
  content: string;
}

interface ChatResponse {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: Array<{
    index: number;
    message: {
      role: string;
      content: string;
    };
    finish_reason: string;
  }>;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

export default function Home() {
  const [baseUrl, setBaseUrl] = useState('');
  const [apiKey, setApiKey] = useState('sk-any-key-works');
  const [models, setModels] = useState<Model[]>([]);
  const [selectedModel, setSelectedModel] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [response, setResponse] = useState<ChatResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [streaming, setStreaming] = useState(false);
  const [streamEnabled, setStreamEnabled] = useState(false);
  const [streamResponse, setStreamResponse] = useState('');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [transcription, setTranscription] = useState('');
  const [transcriptionLoading, setTranscriptionLoading] = useState(false);
  const [selectedWhisperModel, setSelectedWhisperModel] = useState('whisper-1');
  const [audioLanguage, setAudioLanguage] = useState('');

  useEffect(() => {
    // Set base URL to current origin
    setBaseUrl(window.location.origin);
    fetchModels();
  }, []);

  const fetchModels = async () => {
    try {
      const response = await fetch(`${window.location.origin}/api/v1/models`, {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
        },
      });
      const data = await response.json();
      setModels(data.data || []);
      if (data.data && data.data.length > 0) {
        setSelectedModel(data.data[0].id);
      }
    } catch (err) {
      setError('Failed to fetch models');
    }
  };

  const addMessage = (role: string, content: string) => {
    setMessages(prev => [...prev, { role, content }]);
  };

  const sendChatRequest = async () => {
    if (!currentMessage.trim() || !selectedModel) return;

    setLoading(true);
    setError('');
    setResponse(null);
    setStreamResponse('');

    const userMessage = currentMessage.trim();
    addMessage('user', userMessage);
    setCurrentMessage('');

    try {
      const response = await fetch(`${baseUrl}/api/v1/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: selectedModel,
          messages: [...messages, { role: 'user', content: userMessage }],
          stream: streamEnabled,
          temperature: 0.7,
          max_tokens: 2000,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      if (streamEnabled) {
        setStreaming(true);
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let fullResponse = '';

        if (reader) {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value);
            const lines = chunk.split('\n');

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6);
                if (data === '[DONE]') {
                  setStreaming(false);
                  addMessage('assistant', fullResponse);
                  return;
                }
                try {
                  const parsed = JSON.parse(data);
                  const content = parsed.choices[0]?.delta?.content || '';
                  if (content) {
                    fullResponse += content;
                    setStreamResponse(fullResponse);
                  }
                } catch (e) {
                  // Ignore parsing errors for malformed chunks
                }
              }
            }
          }
        }
        setStreaming(false);
      } else {
        const data: ChatResponse = await response.json();
        setResponse(data);
        addMessage('assistant', data.choices[0]?.message?.content || '');
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const clearChat = () => {
    setMessages([]);
    setResponse(null);
    setStreamResponse('');
    setError('');
  };

  const handleAudioUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setAudioFile(file);
      setTranscription('');
      setError('');
    }
  };

  const transcribeAudio = async () => {
    if (!audioFile) return;

    setTranscriptionLoading(true);
    setError('');
    setTranscription('');

    try {
      const formData = new FormData();
      formData.append('file', audioFile);
      formData.append('model', selectedWhisperModel);
      if (audioLanguage) {
        formData.append('language', audioLanguage);
      }

      const response = await fetch(`${baseUrl}/api/v1/audio/transcriptions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setTranscription(data.text || '');
    } catch (err: any) {
      setError(err.message || 'An error occurred during transcription');
    } finally {
      setTranscriptionLoading(false);
    }
  };

  const testEndpoint = async (endpoint: string) => {
    try {
      const response = await fetch(`${baseUrl}${endpoint}`, {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
        },
      });
      const data = await response.json();
      return JSON.stringify(data, null, 2);
    } catch (err: any) {
      return `Error: ${err.message}`;
    }
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold">OpenAI Compatible API Service</h1>
          <p className="text-muted-foreground">Test your API endpoints with multiple models</p>
        </div>

        {/* Configuration */}
        <Card>
          <CardHeader>
            <CardTitle>API Configuration</CardTitle>
            <CardDescription>Configure your API settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="baseUrl">Base URL</Label>
                <Input
                  id="baseUrl"
                  value={baseUrl}
                  onChange={(e) => setBaseUrl(e.target.value)}
                  placeholder="http://localhost:3000"
                />
              </div>
              <div>
                <Label htmlFor="apiKey">API Key (Any key works)</Label>
                <Input
                  id="apiKey"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="sk-any-key-works"
                />
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch
                id="stream"
                checked={streamEnabled}
                onCheckedChange={setStreamEnabled}
              />
              <Label htmlFor="stream">Enable Streaming</Label>
            </div>
          </CardContent>
        </Card>

        {/* API Endpoints */}
        <Card>
          <CardHeader>
            <CardTitle>API Endpoints</CardTitle>
            <CardDescription>Available API endpoints with full URLs</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div>
                  <code className="text-sm font-mono">GET /api/v1</code>
                  <p className="text-xs text-muted-foreground mt-1">Base API information</p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => testEndpoint('/api/v1')}
                >
                  Test
                </Button>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div>
                  <code className="text-sm font-mono">GET /api/v1/models</code>
                  <p className="text-xs text-muted-foreground mt-1">List available models</p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => testEndpoint('/api/v1/models')}
                >
                  Test
                </Button>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div>
                  <code className="text-sm font-mono">POST /api/v1/chat/completions</code>
                  <p className="text-xs text-muted-foreground mt-1">Chat completions with streaming support</p>
                </div>
                <Badge variant="secondary">Main Endpoint</Badge>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div>
                  <code className="text-sm font-mono">POST /api/v1/audio/transcriptions</code>
                  <p className="text-xs text-muted-foreground mt-1">Audio transcription with Whisper models</p>
                </div>
                <Badge variant="outline">Audio</Badge>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div>
                  <code className="text-sm font-mono">POST /api/v1/audio/translations</code>
                  <p className="text-xs text-muted-foreground mt-1">Audio translation with Whisper models</p>
                </div>
                <Badge variant="outline">Audio</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Models */}
        <Card>
          <CardHeader>
            <CardTitle>Available Models</CardTitle>
            <CardDescription>Supported AI models</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2">
              {models.map((model) => (
                <Badge
                  key={model.id}
                  variant={selectedModel === model.id ? "default" : "outline"}
                  className="cursor-pointer justify-center py-2"
                  onClick={() => setSelectedModel(model.id)}
                >
                  {model.id}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Chat Interface */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Chat Interface</CardTitle>
                <CardDescription>Test the chat completions API</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                {selectedModel && (
                  <Badge variant="outline">
                    Model: {selectedModel}
                  </Badge>
                )}
                <Button variant="outline" size="sm" onClick={clearChat}>
                  Clear
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="chat" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="chat">Chat</TabsTrigger>
                <TabsTrigger value="audio">Audio Transcription</TabsTrigger>
                <TabsTrigger value="raw">Raw Response</TabsTrigger>
              </TabsList>
              
              <TabsContent value="chat" className="space-y-4">
                {/* Messages */}
                <ScrollArea className="h-96 w-full border rounded-lg p-4">
                  <div className="space-y-4">
                    {messages.map((message, index) => (
                      <div
                        key={index}
                        className={`flex ${
                          message.role === 'user' ? 'justify-end' : 'justify-start'
                        }`}
                      >
                        <div
                          className={`max-w-[80%] rounded-lg p-3 ${
                            message.role === 'user'
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-muted'
                          }`}
                        >
                          <div className="text-sm font-medium mb-1">{message.role}</div>
                          <div className="text-sm">{message.content}</div>
                        </div>
                      </div>
                    ))}
                    
                    {streaming && (
                      <div className="flex justify-start">
                        <div className="max-w-[80%] rounded-lg p-3 bg-muted">
                          <div className="text-sm font-medium mb-1">assistant</div>
                          <div className="text-sm">{streamResponse}</div>
                          <div className="flex items-center gap-1 mt-2">
                            <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                            <div className="w-2 h-2 bg-primary rounded-full animate-bounce delay-100"></div>
                            <div className="w-2 h-2 bg-primary rounded-full animate-bounce delay-200"></div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </ScrollArea>

                {/* Input */}
                <div className="flex gap-2">
                  <Textarea
                    value={currentMessage}
                    onChange={(e) => setCurrentMessage(e.target.value)}
                    placeholder="Type your message here..."
                    className="flex-1"
                    rows={3}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        sendChatRequest();
                      }
                    }}
                  />
                  <Button
                    onClick={sendChatRequest}
                    disabled={loading || !currentMessage.trim() || !selectedModel}
                    className="self-end"
                  >
                    {loading ? (
                      <Square className="w-4 h-4" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="audio" className="space-y-4">
                <div className="space-y-4">
                  {/* Audio Upload */}
                  <div className="space-y-2">
                    <Label htmlFor="audio-upload">Upload Audio File</Label>
                    <div className="flex items-center gap-4">
                      <div className="flex-1">
                        <Input
                          id="audio-upload"
                          type="file"
                          accept="audio/*"
                          onChange={handleAudioUpload}
                          className="cursor-pointer"
                        />
                      </div>
                      {audioFile && (
                        <div className="flex items-center gap-2">
                          <FileAudio className="w-4 h-4" />
                          <span className="text-sm text-muted-foreground">
                            {audioFile.name}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Whisper Model Selection */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="whisper-model">Whisper Model</Label>
                      <Select value={selectedWhisperModel} onValueChange={setSelectedWhisperModel}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Whisper model" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="whisper-1">whisper-1</SelectItem>
                          <SelectItem value="whisper-large-v3">whisper-large-v3</SelectItem>
                          <SelectItem value="whisper-medium">whisper-medium</SelectItem>
                          <SelectItem value="whisper-small">whisper-small</SelectItem>
                          <SelectItem value="whisper-base">whisper-base</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="audio-language">Language (Optional)</Label>
                      <Input
                        id="audio-language"
                        value={audioLanguage}
                        onChange={(e) => setAudioLanguage(e.target.value)}
                        placeholder="e.g., en, es, fr, zh"
                      />
                    </div>
                  </div>

                  {/* Transcribe Button */}
                  <Button
                    onClick={transcribeAudio}
                    disabled={!audioFile || transcriptionLoading}
                    className="w-full"
                  >
                    {transcriptionLoading ? (
                      <>
                        <Square className="w-4 h-4 mr-2" />
                        Transcribing...
                      </>
                    ) : (
                      <>
                        <Mic className="w-4 h-4 mr-2" />
                        Transcribe Audio
                      </>
                    )}
                  </Button>

                  {/* Transcription Result */}
                  {transcription && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label>Transcription Result</Label>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyToClipboard(transcription)}
                        >
                          {copied ? (
                            <CheckCircle className="w-4 h-4" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </Button>
                      </div>
                      <ScrollArea className="h-64 w-full border rounded-lg p-4">
                        <p className="text-sm whitespace-pre-wrap">{transcription}</p>
                      </ScrollArea>
                    </div>
                  )}

                  {/* Supported Formats Info */}
                  <Alert>
                    <Info className="h-4 w-4" />
                    <AlertDescription>
                      <strong>Supported formats:</strong> mp3, mp4, mpeg, mpga, m4a, wav, webm
                      <br />
                      <strong>Tip:</strong> For best results, use audio with clear speech and minimal background noise.
                    </AlertDescription>
                  </Alert>
                </div>
              </TabsContent>
              
              <TabsContent value="raw" className="space-y-4">
                {error && (
                  <Alert variant="destructive">
                    <XCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
                
                {response && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>Response JSON</Label>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(JSON.stringify(response, null, 2))}
                      >
                        {copied ? (
                          <CheckCircle className="w-4 h-4" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                    <ScrollArea className="h-96 w-full border rounded-lg p-4">
                      <pre className="text-xs font-mono whitespace-pre-wrap">
                        {JSON.stringify(response, null, 2)}
                      </pre>
                    </ScrollArea>
                  </div>
                )}
                
                {streamResponse && !response && (
                  <div className="space-y-2">
                    <Label>Streaming Response</Label>
                    <ScrollArea className="h-96 w-full border rounded-lg p-4">
                      <pre className="text-sm whitespace-pre-wrap">
                        {streamResponse}
                      </pre>
                    </ScrollArea>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Usage Example */}
        <Card>
          <CardHeader>
            <CardTitle>Usage Example</CardTitle>
            <CardDescription>Example code for using the API</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-64 w-full border rounded-lg p-4">
              <pre className="text-xs font-mono whitespace-pre-wrap">
{`// Example usage with fetch
const response = await fetch('${baseUrl}/api/v1/chat/completions', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer any-api-key-works',
  },
  body: JSON.stringify({
    model: 'gpt-4o',
    messages: [
      { role: 'user', content: 'Hello, how are you?' }
    ],
    stream: false,
    temperature: 0.7,
  }),
});

const data = await response.json();
console.log(data.choices[0].message.content);

// Streaming example
const response = await fetch('${baseUrl}/api/v1/chat/completions', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer any-api-key-works',
  },
  body: JSON.stringify({
    model: 'gpt-4o',
    messages: [
      { role: 'user', content: 'Tell me a story' }
    ],
    stream: true,
  }),
});

const reader = response.body.getReader();
const decoder = new TextDecoder();

while (true) {
  const { done, value } = await reader.read();
  if (done) break;
  
  const chunk = decoder.decode(value);
  const lines = chunk.split('\\n');
  
  for (const line of lines) {
    if (line.startsWith('data: ')) {
      const data = line.slice(6);
      if (data === '[DONE]') return;
      
      const parsed = JSON.parse(data);
      const content = parsed.choices[0]?.delta?.content || '';
      if (content) {
        console.log(content);
      }
    }
  }
}

// Audio transcription example
const formData = new FormData();
formData.append('file', audioFile);
formData.append('model', 'whisper-1');
formData.append('language', 'en');

const transcriptionResponse = await fetch('${baseUrl}/api/v1/audio/transcriptions', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer any-api-key-works',
  },
  body: formData,
});

const transcriptionData = await transcriptionResponse.json();
console.log('Transcription:', transcriptionData.text);

// Audio translation example (translates to English)
const translationResponse = await fetch('${baseUrl}/api/v1/audio/translations', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer any-api-key-works',
  },
  body: formData,
});

const translationData = await translationResponse.json();
console.log('Translation:', translationData.text);`}
              </pre>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}