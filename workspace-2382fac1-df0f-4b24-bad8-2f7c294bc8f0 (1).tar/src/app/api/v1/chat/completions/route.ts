import { NextRequest, NextResponse } from 'next/server';
import { apiClient } from '@/lib/api-client';

export async function POST(request: NextRequest) {
  try {
    // Get the request body from the client
    const body = await request.json();
    
    // Use the base API client to forward the request
    const result = await apiClient.chatCompletions(body);
    
    return NextResponse.json(result);

  } catch (error) {
    console.error('Chat completions proxy error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal server error' },
      { status: 500 }
    );
  }
}