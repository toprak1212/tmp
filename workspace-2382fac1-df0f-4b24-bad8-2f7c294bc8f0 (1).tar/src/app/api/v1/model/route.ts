import { NextResponse } from 'next/server';

interface Model {
  id: string;
  object: string;
  created: number;
  owned_by: string;
}

interface ModelsResponse {
  object: string;
  data: Model[];
}

export async function GET() {
  try {
    // Available models including the ones you specified
    const models: Model[] = [
      {
        id: "claude-3-sonnet-20240229",
        object: "model",
        created: 1708405600,
        owned_by: "anthropic"
      },
      {
        id: "claude-3-opus-20240229",
        object: "model",
        created: 1708405600,
        owned_by: "anthropic"
      },
      {
        id: "claude-3-haiku-20240307",
        object: "model",
        created: 1709875200,
        owned_by: "anthropic"
      },
      {
        id: "glm-4.6",
        object: "model",
        created: 1717200000,
        owned_by: "zhipu"
      },
      {
        id: "glm-4-plus",
        object: "model",
        created: 1717200000,
        owned_by: "zhipu"
      },
      {
        id: "glm-4",
        object: "model",
        created: 1717200000,
        owned_by: "zhipu"
      },
      {
        id: "gpt-4.1",
        object: "model",
        created: 1720000000,
        owned_by: "openai"
      },
      {
        id: "gpt-4-turbo",
        object: "model",
        created: 1710000000,
        owned_by: "openai"
      },
      {
        id: "gpt-4",
        object: "model",
        created: 1678608000,
        owned_by: "openai"
      },
      {
        id: "gpt-3.5-turbo",
        object: "model",
        created: 1677610602,
        owned_by: "openai"
      }
    ];

    const response: ModelsResponse = {
      object: "list",
      data: models
    };

    return NextResponse.json(response);

  } catch (error) {
    console.error('Models endpoint error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch models' },
      { status: 500 }
    );
  }
}