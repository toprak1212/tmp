import { API_CONFIG, getExternalEndpointUrl } from './api-config';

// Base API client for v1 endpoints
export class BaseAPIClient {
  private baseUrl: string;
  private externalBaseUrl: string;
  private headers: Record<string, string>;

  constructor() {
    this.baseUrl = API_CONFIG.BASE_URL;
    this.externalBaseUrl = API_CONFIG.EXTERNAL_API.BASE_URL;
    this.headers = API_CONFIG.EXTERNAL_API.HEADERS;
  }

  // Generic method to forward requests to external API
  private async forwardRequest(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<Response> {
    const externalUrl = `${this.externalBaseUrl}${endpoint}`;
    
    console.log(`Forwarding request to: ${externalUrl}`);
    
    // Forward the request to external API
    const response = await fetch(externalUrl, {
      ...options,
      headers: {
        ...this.headers,
        ...options.headers,
      },
    });

    console.log(`External API response status: ${response.status}`);

    if (!response.ok) {
      const errorBody = await response.text();
      console.error('External API error:', errorBody);
      throw new Error(`API request failed with status ${response.status}: ${errorBody}`);
    }

    return response;
  }

  // Chat completions endpoint
  async chatCompletions(body: any): Promise<any> {
    const response = await this.forwardRequest('/chat/completions', {
      method: 'POST',
      body: JSON.stringify(body),
    });

    const result = await response.json();
    console.log('Chat completions response:', result);
    return result;
  }

  // Image generations endpoint
  async generateImages(body: any): Promise<any> {
    const response = await this.forwardRequest('/images/generations', {
      method: 'POST',
      body: JSON.stringify(body),
    });

    const result = await response.json();
    console.log('Image generations response:', result);
    return result;
  }

  // Function invocation endpoint
  async invokeFunction(functionName: string, args: any): Promise<any> {
    const body = {
      function_name: functionName,
      arguments: args,
    };

    const response = await this.forwardRequest('/functions/invoke', {
      method: 'POST',
      body: JSON.stringify(body),
    });

    const result = await response.json();
    console.log('Function invoke response:', result);
    return result;
  }

  // Get base URL
  getBaseUrl(): string {
    return this.baseUrl;
  }

  // Get endpoint URL
  getEndpointUrl(endpoint: string): string {
    return `${this.baseUrl}${endpoint}`;
  }
}

// Export singleton instance
export const apiClient = new BaseAPIClient();