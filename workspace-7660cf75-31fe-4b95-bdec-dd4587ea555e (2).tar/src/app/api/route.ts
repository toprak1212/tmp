import { NextResponse } from "next/server";
import { API_CONFIG, API_ENDPOINTS } from "@/lib/api-config";

export async function GET() {
  return NextResponse.json({
    message: "AI API Proxy - Base Endpoint",
    version: "v1",
    base_url: API_CONFIG.BASE_URL,
    description: "Next.js API proxy for external AI services",
    authentication: {
      required: true,
      type: "API Key",
      description: API_CONFIG.API_KEY.DESCRIPTION,
      methods: [
        "Authorization: Bearer <your-api-key>",
        "X-API-Key: <your-api-key>", 
        "?api_key=<your-api-key>"
      ]
    },
    endpoints: {
      models: {
        path: "/model",
        description: "Get available AI models",
        method: "GET",
        requires_auth: true,
        full_url: API_ENDPOINTS.MODELS
      },
      chat_completions: {
        path: "/chat/completions", 
        description: "Create chat completions",
        method: "POST",
        requires_auth: true,
        full_url: API_ENDPOINTS.CHAT_COMPLETIONS
      },
      image_generations: {
        path: "/images/generations",
        description: "Generate images using AI",
        method: "POST",
        requires_auth: true, 
        full_url: API_ENDPOINTS.IMAGES_GENERATIONS
      },
      functions_invoke: {
        path: "/functions/invoke",
        description: "Invoke AI functions (e.g., web search)",
        method: "POST",
        requires_auth: true,
        full_url: API_ENDPOINTS.FUNCTIONS_INVOKE
      }
    },
    usage: {
      base_endpoint: API_CONFIG.BASE_URL,
      example_with_bearer: {
        method: "GET",
        url: API_ENDPOINTS.MODELS,
        headers: {
          "Authorization": "Bearer your-api-key-here"
        }
      },
      example_with_header: {
        method: "GET", 
        url: API_ENDPOINTS.MODELS,
        headers: {
          "X-API-Key": "your-api-key-here"
        }
      },
      example_with_query: {
        method: "GET",
        url: `${API_ENDPOINTS.MODELS}?api_key=your-api-key-here`
      }
    }
  });
}

// Handle OPTIONS requests for CORS
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}