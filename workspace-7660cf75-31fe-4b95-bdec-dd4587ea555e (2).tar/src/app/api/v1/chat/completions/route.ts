import { NextRequest, NextResponse } from 'next/server';
import { apiClient } from '@/lib/api-client';
import { withAPIKeyValidation } from '@/lib/api-key-validation';

async function handleChatCompletionRequest(request: NextRequest) {
  try {
    // Get the request body from the client
    const body = await request.json();
    
    console.log('Chat completion request received with API key validation');
    
    // Use the base API client to forward the request
    const result = await apiClient.chatCompletions(body);
    
    return NextResponse.json(result);

  } catch (error) {
    console.error('Chat completions proxy error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal server error' },
      { status: 500 }
    );
  }
}

// Export the handler with API key validation middleware
export const POST = withAPIKeyValidation(handleChatCompletionRequest);

// Handle OPTIONS requests for CORS
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, X-API-Key",
    },
  });
}