import { NextRequest, NextResponse } from 'next/server';
import { apiClient } from '@/lib/api-client';
import { withAPIKeyValidation } from '@/lib/api-key-validation';

async function handleFunctionInvokeRequest(request: NextRequest) {
  try {
    // Get the request body from the client
    const body = await request.json();
    
    console.log('Function invoke request received with API key validation');
    
    // Use the base API client to forward the request
    const result = await apiClient.invokeFunction(body.function_name, body.arguments);
    
    return NextResponse.json(result);

  } catch (error) {
    console.error('Function invoke proxy error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal server error' },
      { status: 500 }
    );
  }
}

// Export the handler with API key validation middleware
export const POST = withAPIKeyValidation(handleFunctionInvokeRequest);

// Handle OPTIONS requests for CORS
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, X-API-Key",
    },
  });
}