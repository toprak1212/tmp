import { NextRequest, NextResponse } from 'next/server';
import { apiClient } from '@/lib/api-client';
import { withAPIKeyValidation } from '@/lib/api-key-validation';

async function handleImageGenerationRequest(request: NextRequest) {
  try {
    // Get the request body from the client
    const body = await request.json();
    
    console.log('Image generation request received with API key validation');
    
    // Use the base API client to forward the request
    const result = await apiClient.generateImages(body);
    
    return NextResponse.json(result);

  } catch (error) {
    console.error('Image generation proxy error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal server error' },
      { status: 500 }
    );
  }
}

// Export the handler with API key validation middleware
export const POST = withAPIKeyValidation(handleImageGenerationRequest);

// Handle OPTIONS requests for CORS
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, X-API-Key",
    },
  });
}