import { NextResponse } from "next/server";
import { API_CONFIG, API_ENDPOINTS } from "@/lib/api-config";

export async function GET() {
  return NextResponse.json({
    message: "AI API Proxy - v1 Base Endpoint",
    version: "v1",
    base_url: API_CONFIG.BASE_URL,
    description: "Next.js API proxy for external AI services - Version 1",
    authentication: {
      required: true,
      type: "API Key",
      description: API_CONFIG.API_KEY.DESCRIPTION,
      methods: [
        "Authorization: Bearer <your-api-key>",
        "X-API-Key: <your-api-key>", 
        "?api_key=<your-api-key>"
      ]
    },
    endpoints: {
      models: {
        path: "/model",
        description: "Get available AI models",
        method: "GET",
        requires_auth: true,
        full_url: API_ENDPOINTS.MODELS
      },
      chat_completions: {
        path: "/chat/completions", 
        description: "Create chat completions",
        method: "POST",
        requires_auth: true,
        full_url: API_ENDPOINTS.CHAT_COMPLETIONS,
        parameters: {
          model: "string (required)",
          messages: "array (required)",
          temperature: "number (optional)",
          max_tokens: "number (optional)"
        }
      },
      image_generations: {
        path: "/images/generations",
        description: "Generate images using AI",
        method: "POST",
        requires_auth: true, 
        full_url: API_ENDPOINTS.IMAGES_GENERATIONS,
        parameters: {
          prompt: "string (required)",
          size: "string (optional, default: 1024x1024)"
        }
      },
      functions_invoke: {
        path: "/functions/invoke",
        description: "Invoke AI functions (e.g., web search)",
        method: "POST",
        requires_auth: true,
        full_url: API_ENDPOINTS.FUNCTIONS_INVOKE,
        parameters: {
          function_name: "string (required)",
          arguments: "object (required)"
        }
      }
    },
    usage_examples: {
      get_models: {
        method: "GET",
        url: API_ENDPOINTS.MODELS,
        headers: {
          "Authorization": "Bearer your-api-key-here"
        }
      },
      chat_completion: {
        method: "POST",
        url: API_ENDPOINTS.CHAT_COMPLETIONS,
        headers: {
          "Authorization": "Bearer your-api-key-here",
          "Content-Type": "application/json"
        },
        body: {
          model: "gpt-3.5-turbo",
          messages: [
            { role: "user", content: "Hello!" }
          ]
        }
      },
      generate_image: {
        method: "POST", 
        url: API_ENDPOINTS.IMAGES_GENERATIONS,
        headers: {
          "X-API-Key": "your-api-key-here",
          "Content-Type": "application/json"
        },
        body: {
          prompt: "A beautiful sunset over mountains",
          size: "1024x1024"
        }
      },
      web_search: {
        method: "POST",
        url: `${API_ENDPOINTS.FUNCTIONS_INVOKE}?api_key=your-api-key-here`,
        headers: {
          "Content-Type": "application/json"
        },
        body: {
          function_name: "web_search",
          arguments: {
            query: "Next.js 15 features",
            num: 5
          }
        }
      }
    }
  });
}

// Handle OPTIONS requests for CORS
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}