import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "JustAI - Experience the Power of AI",
  description: "JustAI - Your gateway to powerful AI capabilities. Chat, generate images, and search the web with cutting-edge AI technology.",
  keywords: ["JustAI", "AI", "Chat", "Image Generation", "Web Search", "Next.js", "TypeScript", "Tailwind CSS"],
  authors: [{ name: "JustAI Team" }],
  icons: {
    icon: "/favicon.ico",
  },
  openGraph: {
    title: "JustAI - Experience the Power of AI",
    description: "Chat, generate images, and search the web with cutting-edge AI technology",
    url: "https://justai.example.com",
    siteName: "JustAI",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "JustAI - Experience the Power of AI",
    description: "Chat, generate images, and search the web with cutting-edge AI technology",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
