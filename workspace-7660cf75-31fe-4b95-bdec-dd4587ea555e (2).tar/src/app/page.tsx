import JustAI from '@/components/enhanced-ai-demo';

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <JustAI />
    </div>
  )
}