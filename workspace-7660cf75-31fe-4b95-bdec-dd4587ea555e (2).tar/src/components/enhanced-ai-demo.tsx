'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, MessageCircle, Bot, Send, Image, Search, Code, Key } from 'lucide-react';

// Helper function for authenticated API requests
const authenticatedFetch = async (url: string, options: RequestInit = {}) => {
  const defaultApiKey = 'demo-api-key-12345'; // Default API key for demo
  
  return fetch(url, {
    ...options,
    headers: {
      ...options.headers,
      'Authorization': `Bearer ${defaultApiKey}`,
      'Content-Type': 'application/json',
    },
  });
};

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface Model {
  id: string;
  object: string;
  created: number;
  owned_by: string;
}

interface ModelsResponse {
  object: string;
  data: Model[];
}

interface SearchResult {
  url: string;
  name: string;
  snippet: string;
  host_name: string;
  rank: number;
  date: string;
  favicon: string;
}

interface FunctionResponse {
  result: SearchResult[];
}

export default function JustAI() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [selectedModel, setSelectedModel] = useState<string>('gpt-3.5-turbo');
  const [availableModels, setAvailableModels] = useState<Model[]>([]);
  const [modelsLoading, setModelsLoading] = useState(true);

  // Image generation states
  const [imagePrompt, setImagePrompt] = useState('');
  const [imageSize, setImageSize] = useState('1024x1024');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [imageLoading, setImageLoading] = useState(false);

  // Function invocation states
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchNum, setSearchNum] = useState('5');

  // Fetch available models on component mount
  useEffect(() => {
    const fetchModels = async () => {
      try {
        const response = await authenticatedFetch('/api/v1/model');
        const data: ModelsResponse = await response.json();
        setAvailableModels(data.data || []);
      } catch (error) {
        console.error('Failed to fetch models:', error);
      } finally {
        setModelsLoading(false);
      }
    };

    fetchModels();
  }, []);

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await authenticatedFetch('/api/v1/chat/completions', {
        method: 'POST',
        body: JSON.stringify({
          model: selectedModel,
          messages: [
            { role: 'system', content: 'You are a helpful AI assistant.' },
            ...messages.map(msg => ({ role: msg.role, content: msg.content })),
            { role: 'user', content: input }
          ],
          temperature: 0.7,
          max_tokens: 150
        })
      });

      const data = await response.json();
      setApiResponse(data);

      if (response.ok && data.choices?.[0]?.message?.content) {
        const assistantMessage: Message = {
          role: 'assistant',
          content: data.choices[0].message.content,
          timestamp: new Date()
        };
        setMessages(prev => [...prev, assistantMessage]);
      } else {
        throw new Error(data.error || 'Failed to get response');
      }
    } catch (error) {
      console.error('Error:', error);
      const errorMessage: Message = {
        role: 'assistant',
        content: `Error: ${error instanceof Error ? error.message : 'Unknown error occurred'}`,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const generateImage = async () => {
    if (!imagePrompt.trim()) return;

    setImageLoading(true);
    setGeneratedImage(null);

    try {
      const response = await authenticatedFetch('/api/v1/images/generations', {
        method: 'POST',
        body: JSON.stringify({
          prompt: imagePrompt,
          size: imageSize
        })
      });

      const data = await response.json();

      if (response.ok && data.data && data.data.length > 0) {
        setGeneratedImage(data.data[0].url);
        setApiResponse(data);
      } else {
        throw new Error(data.error || 'Failed to generate image');
      }
    } catch (error) {
      console.error('Image generation error:', error);
      alert(`Error: ${error instanceof Error ? error.message : 'Unknown error occurred'}`);
    } finally {
      setImageLoading(false);
    }
  };

  const invokeFunction = async () => {
    if (!searchQuery.trim()) return;

    setSearchLoading(true);
    setSearchResults([]);

    try {
      const response = await authenticatedFetch('/api/v1/functions/invoke', {
        method: 'POST',
        body: JSON.stringify({
          function_name: 'web_search',
          arguments: {
            query: searchQuery,
            num: parseInt(searchNum)
          }
        })
      });

      const data: FunctionResponse = await response.json();

      if (response.ok && data.result) {
        setSearchResults(data.result);
        setApiResponse(data);
      } else {
        throw new Error(data.error || 'Failed to invoke function');
      }
    } catch (error) {
      console.error('Function invoke error:', error);
      alert(`Error: ${error instanceof Error ? error.message : 'Unknown error occurred'}`);
    } finally {
      setSearchLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-6">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-black to-gray-800 bg-clip-text text-transparent">
          JustAI
        </h1>
      </div>

      <Tabs defaultValue="chat" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 h-12 bg-muted/50 p-1 rounded-xl">
          <TabsTrigger value="chat" className="flex items-center gap-2 data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-lg transition-all duration-200">
            <MessageCircle className="h-4 w-4" />
            <span className="font-medium">Chat</span>
          </TabsTrigger>
          <TabsTrigger value="images" className="flex items-center gap-2 data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-lg transition-all duration-200">
            <Image className="h-4 w-4" alt="" />
            <span className="font-medium">Images</span>
          </TabsTrigger>
          <TabsTrigger value="functions" className="flex items-center gap-2 data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-lg transition-all duration-200">
            <Search className="h-4 w-4" />
            <span className="font-medium">Search</span>
          </TabsTrigger>
        </TabsList>

        {/* Chat Tab */}
        <TabsContent value="chat" className="space-y-6">
          <Card className="h-[650px] flex flex-col border-0 shadow-lg bg-gradient-to-br from-slate-50 to-white dark:from-slate-900 dark:to-slate-800 lg:col-span-4">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <MessageCircle className="h-5 w-5 text-purple-600" />
                  AI Chat Interface
                </CardTitle>
                <Select value={selectedModel} onValueChange={setSelectedModel} disabled={modelsLoading}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Select model..." />
                  </SelectTrigger>
                  <SelectContent>
                    {availableModels.map((model) => (
                      <SelectItem key={model.id} value={model.id}>
                        <div className="flex flex-col">
                          <span className="font-medium">{model.id}</span>
                          <span className="text-xs text-muted-foreground">{model.owned_by}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <CardDescription className="text-sm">
                Start a conversation with our AI assistant
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col px-6">
                <div className="flex-1 overflow-y-auto space-y-4 mb-4 p-4 border rounded-xl bg-muted/10 backdrop-blur-sm">
                  {messages.map((message, index) => (
                    <div
                      key={index}
                      className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[80%] rounded-2xl p-4 shadow-sm ${
                          message.role === 'user'
                            ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-blue-200'
                            : 'bg-muted border border-border/50'
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant={message.role === 'user' ? 'secondary' : 'outline'} className="text-xs font-medium">
                            {message.role}
                          </Badge>
                          <span className="text-xs opacity-70">
                            {message.timestamp.toLocaleTimeString()}
                          </span>
                        </div>
                        <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
                      </div>
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="max-w-[80%] rounded-2xl p-4 bg-muted border border-border/50">
                        <div className="flex items-center gap-3">
                          <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
                          <span className="text-sm font-medium">Thinking...</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex gap-3">
                  <Textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Type your message here..."
                    className="flex-1 min-h-[60px] resize-none border-2 focus:border-blue-500 rounded-xl transition-colors"
                    disabled={isLoading}
                  />
                  <Button
                    onClick={sendMessage}
                    disabled={!input.trim() || isLoading}
                    size="icon"
                    className="shrink-0 h-12 w-12 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 transition-all duration-200"
                  >
                    {isLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
        </TabsContent>

        {/* Images Tab */}
        <TabsContent value="images" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="border-0 shadow-lg bg-gradient-to-br from-slate-50 to-white dark:from-slate-900 dark:to-slate-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Image className="h-5 w-5 text-green-600" alt="" />
                  Image Generation
                </CardTitle>
                <CardDescription className="text-sm">
                  Create stunning images with AI
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 px-6">
                <div>
                  <label className="text-sm font-medium mb-2 block">Prompt</label>
                  <Textarea
                    value={imagePrompt}
                    onChange={(e) => setImagePrompt(e.target.value)}
                    placeholder="Describe the image you want to generate..."
                    className="min-h-[100px] resize-none"
                    disabled={imageLoading}
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">Size</label>
                  <Select value={imageSize} onValueChange={setImageSize} disabled={imageLoading}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1024x1024">1024x1024 (Square)</SelectItem>
                      <SelectItem value="768x1344">768x1344 (Portrait)</SelectItem>
                      <SelectItem value="1344x768">1344x768 (Landscape)</SelectItem>
                      <SelectItem value="512x512">512x512 (Small)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button 
                  onClick={generateImage} 
                  disabled={!imagePrompt.trim() || imageLoading}
                  className="w-full"
                >
                  {imageLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Image className="h-4 w-4 mr-2" alt="" />
                      Generate Image
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Generated Image</CardTitle>
                <CardDescription>
                  Result from image generation
                </CardDescription>
              </CardHeader>
              <CardContent>
                {generatedImage ? (
                  <div className="space-y-4">
                    <img 
                      src={generatedImage} 
                      alt="AI generated image"
                      className="w-full rounded-lg border"
                    />
                    <div className="text-sm text-muted-foreground">
                      <p><strong>Prompt:</strong> {imagePrompt}</p>
                      <p><strong>Size:</strong> {imageSize}</p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center text-muted-foreground py-12">
                    <Image className="h-12 w-12 mx-auto mb-2 opacity-50" alt="" />
                    <p>Generate an image to see the result here</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Functions Tab */}
        <TabsContent value="functions" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="border-0 shadow-lg bg-gradient-to-br from-slate-50 to-white dark:from-slate-900 dark:to-slate-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Search className="h-5 w-5 text-orange-600" />
                  Web Search
                </CardTitle>
                <CardDescription className="text-sm">
                  Search the web with AI-powered results
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 px-6">
                <div>
                  <label className="text-sm font-medium mb-2 block">Search Query</label>
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Enter search query..."
                    disabled={searchLoading}
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">Number of Results</label>
                  <Select value={searchNum} onValueChange={setSearchNum} disabled={searchLoading}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="3">3 results</SelectItem>
                      <SelectItem value="5">5 results</SelectItem>
                      <SelectItem value="10">10 results</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button 
                  onClick={invokeFunction} 
                  disabled={!searchQuery.trim() || searchLoading}
                  className="w-full h-12 rounded-xl bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 transition-all duration-200"
                >
                  {searchLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      Searching...
                    </>
                  ) : (
                    <>
                      <Search className="h-4 w-4 mr-2" />
                      Search Web
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-gradient-to-br from-slate-50 to-white dark:from-slate-900 dark:to-slate-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Search className="h-5 w-5 text-orange-600" />
                  Search Results
                </CardTitle>
                <CardDescription className="text-sm">
                  Web search results from AI-powered search
                </CardDescription>
              </CardHeader>
              <CardContent className="px-6">
                {searchResults.length > 0 ? (
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {searchResults.map((result, index) => (
                      <div key={index} className="p-4 border rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors">
                        <div className="flex items-start justify-between mb-3">
                          <h4 className="font-medium text-sm flex-1 pr-2 line-clamp-2">{result.name}</h4>
                          <Badge variant="outline" className="ml-2 text-xs bg-blue-50 text-blue-700 border-blue-200">#{result.rank + 1}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3 leading-relaxed">{result.snippet}</p>
                        <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
                          <span className="font-mono bg-muted/50 px-2 py-1 rounded">{result.host_name}</span>
                          <span>{result.date || 'No date'}</span>
                        </div>
                        <a 
                          href={result.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-xs text-blue-600 hover:text-blue-800 hover:underline mt-2 block font-medium"
                        >
                          Visit Website →
                        </a>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center text-muted-foreground py-12">
                    <Search className="h-12 w-12 mx-auto mb-2 opacity-50" alt="" />
                    <p>Search for something to see results here</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* API Response Details */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>API Response Details</CardTitle>
          <CardDescription>
            Latest response from the external API (proxied through localhost)
          </CardDescription>
        </CardHeader>
        <CardContent>
          {apiResponse ? (
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Response Structure</h4>
                <pre className="text-xs bg-muted p-3 rounded-md overflow-x-auto max-h-64 overflow-y-auto">
                  {JSON.stringify(apiResponse, null, 2)}
                </pre>
              </div>
            </div>
          ) : (
            <div className="text-center text-muted-foreground py-8">
              <p>Interact with the API to see response details here</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}