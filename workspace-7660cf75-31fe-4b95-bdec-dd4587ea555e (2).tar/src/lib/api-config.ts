// API Configuration for v1 endpoints
export const API_CONFIG = {
  // Base URL for all v1 API endpoints
  BASE_URL: 'http://localhost:3000/api/v1',
  
  // API Key Configuration
  API_KEY: {
    REQUIRED: true,
    ACCEPT_ANY_KEY: true,
    HEADER_NAMES: ['authorization', 'x-api-key'],
    QUERY_PARAM: 'api_key',
    DESCRIPTION: 'Provide any non-empty API key via Authorization header (Bearer <key>), X-API-Key header, or api_key query parameter'
  },
  
  // External API configuration
  EXTERNAL_API: {
    BASE_URL: 'http://172.25.136.193:8080/v1',
    HEADERS: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer Z.ai',
      'X-Z-AI-From': 'Z',
      'X-User-Id': 'z',
    }
  },
  
  // Endpoint mappings
  ENDPOINTS: {
    MODELS: '/model',
    CHAT_COMPLETIONS: '/chat/completions',
    IMAGES_GENERATIONS: '/images/generations',
    FUNCTIONS_INVOKE: '/functions/invoke'
  }
};

// Helper function to get full endpoint URLs
export const getEndpointUrl = (endpoint: keyof typeof API_CONFIG.ENDPOINTS): string => {
  return `${API_CONFIG.BASE_URL}${API_CONFIG.ENDPOINTS[endpoint]}`;
};

// Helper function to get external endpoint URLs
export const getExternalEndpointUrl = (endpoint: keyof typeof API_CONFIG.ENDPOINTS): string => {
  return `${API_CONFIG.EXTERNAL_API.BASE_URL}${API_CONFIG.ENDPOINTS[endpoint]}`;
};

// Export individual endpoint URLs for convenience
export const API_ENDPOINTS = {
  MODELS: getEndpointUrl('MODELS'),
  CHAT_COMPLETIONS: getEndpointUrl('CHAT_COMPLETIONS'),
  IMAGES_GENERATIONS: getEndpointUrl('IMAGES_GENERATIONS'),
  FUNCTIONS_INVOKE: getEndpointUrl('FUNCTIONS_INVOKE')
};

// Export external endpoint URLs for reference
export const EXTERNAL_ENDPOINTS = {
  MODELS: getExternalEndpointUrl('MODELS'),
  CHAT_COMPLETIONS: getExternalEndpointUrl('CHAT_COMPLETIONS'),
  IMAGES_GENERATIONS: getExternalEndpointUrl('IMAGES_GENERATIONS'),
  FUNCTIONS_INVOKE: getExternalEndpointUrl('FUNCTIONS_INVOKE')
};