import { NextRequest } from 'next/server';

export interface APIKeyValidationResult {
  isValid: boolean;
  error?: string;
  apiKey?: string;
}

/**
 * Validates API key from request headers or query parameters
 * Accepts any non-empty API key
 */
export function validateAPIKey(request: NextRequest): APIKeyValidationResult {
  // Try to get API key from Authorization header (Bearer token)
  const authHeader = request.headers.get('authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const apiKey = authHeader.substring(7).trim();
    if (apiKey.length > 0) {
      return { isValid: true, apiKey };
    }
  }

  // Try to get API key from X-API-Key header
  const apiKeyHeader = request.headers.get('x-api-key');
  if (apiKeyHeader && apiKeyHeader.trim().length > 0) {
    return { isValid: true, apiKey: apiKeyHeader.trim() };
  }

  // Try to get API key from query parameter
  const { searchParams } = new URL(request.url);
  const apiKeyParam = searchParams.get('api_key');
  if (apiKeyParam && apiKeyParam.trim().length > 0) {
    return { isValid: true, apiKey: apiKeyParam.trim() };
  }

  return {
    isValid: false,
    error: 'API key required. Provide via Authorization header (Bearer <key>), X-API-Key header, or api_key query parameter'
  };
}

/**
 * Middleware function to validate API key and return error response if invalid
 */
export function withAPIKeyValidation(handler: (request: NextRequest, context?: any) => Promise<Response>) {
  return async (request: NextRequest, context?: any): Promise<Response> => {
    const validation = validateAPIKey(request);
    
    if (!validation.isValid) {
      return new Response(
        JSON.stringify({
          error: 'Authentication required',
          message: validation.error,
          status: 401
        }),
        {
          status: 401,
          headers: {
            'Content-Type': 'application/json',
            'WWW-Authenticate': 'Bearer realm="API", scheme="Bearer"'
          }
        }
      );
    }

    // Add API key to request headers for downstream use
    const requestWithAuth = new Request(request, {
      headers: {
        ...Object.fromEntries(request.headers.entries()),
        'x-validated-api-key': validation.apiKey || ''
      }
    });

    return handler(requestWithAuth, context);
  };
}

/**
 * Get the validated API key from request headers
 */
export function getValidatedAPIKey(request: NextRequest): string | null {
  return request.headers.get('x-validated-api-key');
}