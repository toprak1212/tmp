import express from 'express';
import { spawn } from 'child_process';

const app = express();
const PORT = 3000;

app.use(express.json());

function exec(cmd: string): Promise<{stdout: string, stderr: string, code: number|null}> {
  return new Promise((resolve) => {
    const child = spawn(cmd, { shell: true, stdio: 'pipe' });
    let stdout = '', stderr = '';
    
    child.stdout?.on('data', (data) => stdout += data);
    child.stderr?.on('data', (data) => stderr += data);
    
    child.on('close', (code) => resolve({ stdout, stderr, code }));
  });
}

app.post('/exec', async (req, res) => {
  try {
    const { command } = req.body;
    if (!command) return res.status(400).json({ error: 'Command required' });
    
    const result = await exec(command);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/', (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
    <title>Shell</title>
    <style>
        body { font-family: monospace; background: #000; color: #ccc; margin: 0; padding: 0; }
        input { background: #111; color: #ccc; border: 1px solid #333; padding: 8px; width: 100%; box-sizing: border-box; }
        .output { background: #111; border: 1px solid #333; padding: 15px; white-space: pre; min-height: calc(100vh - 50px); width: 100%; box-sizing: border-box; }
    </style>
</head>
<body>
    <input type="text" id="cmd" placeholder="Command" autofocus>
    <div id="out" class="output"></div>
    <script>
        async function run() {
            const cmd = document.getElementById('cmd').value;
            if (!cmd) return;
            
            document.getElementById('out').textContent = '$ ' + cmd + '\\n\\n';
            
            try {
                const r = await fetch('/exec', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ command: cmd })
                });
                const result = await r.json();
                document.getElementById('out').textContent += 
                    (result.stdout || '') + (result.stderr ? '\\nSTDERR:\\n' + result.stderr : '');
            } catch (e) {
                document.getElementById('out').textContent += 'Error: ' + e.message;
            }
            document.getElementById('cmd').value = '';
        }
        document.getElementById('cmd').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') run();
        });
    </script>
</body>
</html>`);
});

app.listen(PORT, () => {
  console.log(`Shell running on http://localhost:${PORT}`);
});