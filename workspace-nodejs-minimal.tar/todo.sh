#!/bin/bash

pkill -f pkill -f "next dev"
nohup npm run dev > web-shell.log 2>&1 &