import express from 'express';
import { spawn } from 'child_process';
import multer from 'multer';
import path from 'path';
import fs from 'fs';

const app = express();
const PORT = 3000;

app.use(express.json());

const upload = multer({ dest: process.env.HOME || process.env.USERPROFILE || '/tmp' });

function exec(cmd: string): Promise<{stdout: string, stderr: string, code: number|null}> {
  return new Promise((resolve) => {
    const child = spawn(cmd, { shell: '/bin/bash', stdio: 'pipe' });
    let stdout = '', stderr = '';
    
    child.stdout?.on('data', (data) => stdout += data);
    child.stderr?.on('data', (data) => stderr += data);
    
    child.on('close', (code) => resolve({ stdout, stderr, code }));
  });
}

app.post('/exec', async (req, res) => {
  try {
    const { command } = req.body;
    if (!command) return res.status(400).json({ error: 'Command required' });
    
    const result = await exec(command);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/upload', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  
  const uploadDir = process.env.HOME || process.env.USERPROFILE || '/tmp';
  const originalPath = req.file.path;
  const newPath = `${uploadDir}/${req.file.originalname}`;
  
  fs.rename(originalPath, newPath, (err) => {
    if (err) {
      res.status(500).json({ error: 'Failed to save file' });
    } else {
      res.json({ filename: req.file.originalname, path: newPath });
    }
  });
});

function isBinary(filePath: string): boolean {
  try {
    const buffer = fs.readFileSync(filePath, { encoding: null });
    const chunk = buffer.slice(0, 512);
    let nullBytes = 0;
    for (let i = 0; i < chunk.length; i++) {
      if (chunk[i] === 0) nullBytes++;
      if (nullBytes > 1) return true;
    }
    return false;
  } catch {
    return true;
  }
}

app.get('/browse', (req, res) => {
  try {
    const path = req.query.path as string || process.env.HOME || process.env.USERPROFILE || '/tmp';
    const uploadDir = process.env.HOME || process.env.USERPROFILE || '/tmp';
    
    // Security: prevent path traversal
    const resolvedPath = path.startsWith(uploadDir) ? path : uploadDir;
    
    const files = fs.readdirSync(resolvedPath).map(file => {
      const filePath = `${resolvedPath}/${file}`;
      const stats = fs.statSync(filePath);
      return {
        name: file,
        size: stats.size,
        modified: stats.mtime,
        isBinary: stats.isFile() ? isBinary(filePath) : false,
        isDirectory: stats.isDirectory(),
        path: resolvedPath
      };
    });
    res.json({ files, currentPath: resolvedPath });
  } catch (error) {
    res.json({ files: [], currentPath: '', error: error.message });
  }
});

app.get('/view/:filename', (req, res) => {
  try {
    const filename = req.params.filename;
    const path = req.query.path as string || process.env.HOME || process.env.USERPROFILE || '/tmp';
    const uploadDir = process.env.HOME || process.env.USERPROFILE || '/tmp';
    
    // Security: prevent path traversal
    const resolvedPath = path.startsWith(uploadDir) ? path : uploadDir;
    const filePath = `${resolvedPath}/${filename}`;
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File not found' });
    }
    
    if (isBinary(filePath)) {
      return res.json({ error: 'Binary file - cannot view' });
    }
    
    const content = fs.readFileSync(filePath, 'utf8');
    res.json({ content });
  } catch (error) {
    res.status(500).json({ error: 'Failed to read file' });
  }
});

app.get('/download/:filename', (req, res) => {
  try {
    const filename = req.params.filename;
    const path = req.query.path as string || process.env.HOME || process.env.USERPROFILE || '/tmp';
    const uploadDir = process.env.HOME || process.env.USERPROFILE || '/tmp';
    
    // Security: prevent path traversal
    const resolvedPath = path.startsWith(uploadDir) ? path : uploadDir;
    const filePath = `${resolvedPath}/${filename}`;
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File not found' });
    }
    
    res.download(filePath, filename);
  } catch (error) {
    res.status(500).json({ error: 'Failed to download file' });
  }
});

app.delete('/delete/:filename', (req, res) => {
  try {
    const filename = req.params.filename;
    const path = req.query.path as string || process.env.HOME || process.env.USERPROFILE || '/tmp';
    const uploadDir = process.env.HOME || process.env.USERPROFILE || '/tmp';
    
    // Security: prevent path traversal
    const resolvedPath = path.startsWith(uploadDir) ? path : uploadDir;
    const filePath = `${resolvedPath}/${filename}`;
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File not found' });
    }
    
    fs.unlinkSync(filePath);
    res.json({ success: true, filename });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete file' });
  }
});

app.post('/tar/:foldername', async (req, res) => {
  try {
    const foldername = req.params.foldername;
    const path = req.query.path as string || process.env.HOME || process.env.USERPROFILE || '/tmp';
    const uploadDir = process.env.HOME || process.env.USERPROFILE || '/tmp';
    
    // Security: prevent path traversal
    const resolvedPath = path.startsWith(uploadDir) ? path : uploadDir;
    const folderPath = `${resolvedPath}/${foldername}`;
    
    if (!fs.existsSync(folderPath)) {
      return res.status(404).json({ error: 'Folder not found' });
    }
    
    if (!fs.statSync(folderPath).isDirectory()) {
      return res.status(400).json({ error: 'Not a directory' });
    }
    
    const tarCommand = `/bin/bash -c "cd '${resolvedPath}' && tar -czf '${foldername}.tar.gz' '${foldername}'"`;
    const result = await exec(tarCommand);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create tar archive' });
  }
});

app.post('/run/:filename', async (req, res) => {
  try {
    const filename = req.params.filename;
    const path = req.query.path as string || process.env.HOME || process.env.USERPROFILE || '/tmp';
    const uploadDir = process.env.HOME || process.env.USERPROFILE || '/tmp';
    
    // Security: prevent path traversal
    const resolvedPath = path.startsWith(uploadDir) ? path : uploadDir;
    const filePath = `${resolvedPath}/${filename}`;
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File not found' });
    }
    
    // Check if file is actually accessible
    try {
      fs.accessSync(filePath, fs.constants.F_OK);
    } catch (error) {
      return res.status(404).json({ error: 'File not accessible' });
    }
    
    // Convert Windows line endings to Unix line endings for shell scripts
    if (filename.endsWith('.sh')) {
      const content = fs.readFileSync(filePath, 'utf8');
      const convertedContent = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
      fs.writeFileSync(filePath, convertedContent, 'utf8');
    }
    
    // Make file executable
    await new Promise<void>((resolve, reject) => {
      spawn(`chmod +x "${filePath}"`, { shell: '/bin/bash', stdio: 'pipe' })
        .on('close', (code) => {
          if (code === 0) resolve();
          else reject(new Error(`chmod failed with code ${code}`));
        })
        .on('error', reject);
    });
    
    // Execute file with explicit path
    const result = await exec(`/bin/bash "${filePath}"`);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: 'Failed to run file: ' + error.message });
  }
});

app.post('/extract/:filename', async (req, res) => {
  try {
    const filename = req.params.filename;
    const path = req.query.path as string || process.env.HOME || process.env.USERPROFILE || '/tmp';
    const uploadDir = process.env.HOME || process.env.USERPROFILE || '/tmp';
    
    // Security: prevent path traversal
    const resolvedPath = path.startsWith(uploadDir) ? path : uploadDir;
    const filePath = `${resolvedPath}/${filename}`;
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File not found' });
    }
    
    let extractCmd = '';
    if (filename.endsWith('.tar.gz') || filename.endsWith('.tgz')) {
      extractCmd = `/bin/bash -c "tar -xzf '${filePath}' -C '${resolvedPath}'"`;
    } else if (filename.endsWith('.tar')) {
      extractCmd = `/bin/bash -c "tar -xf '${filePath}' -C '${resolvedPath}'"`;
    } else if (filename.endsWith('.zip')) {
      extractCmd = `/bin/bash -c "unzip -o '${filePath}' -d '${resolvedPath}'"`;
    } else if (filename.endsWith('.rar')) {
      extractCmd = `/bin/bash -c "unrar x '${filePath}' '${resolvedPath}'"`;
    } else if (filename.endsWith('.7z')) {
      extractCmd = `/bin/bash -c "7z x '${filePath}' -o'${resolvedPath}'"`;
    } else {
      return res.status(400).json({ error: 'Unsupported archive format' });
    }
    
    const result = await exec(extractCmd);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: 'Failed to extract file' });
  }
});

app.get('/', (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
    <title>Shell</title>
    <style>
        body { font-family: monospace; background: #000; color: #ccc; margin: 0; padding: 0; }
        input { background: #111; color: #ccc; border: 1px solid #333; padding: 8px; width: 100%; box-sizing: border-box; }
        .output { background: #111; border: 1px solid #333; padding: 15px; white-space: pre; min-height: calc(100vh - 140px); width: 100%; box-sizing: border-box; }
        .browse { border: 1px solid #333; padding: 8px; margin: 5px 0; font-size: 12px; }
        .file-list { max-height: 150px; overflow-y: auto; }
        .file-item { padding: 4px 8px; cursor: pointer; border-bottom: 1px solid #222; }
        .file-item:hover { background: #111; }
        .file-binary { opacity: 0.7; }
        .file-actions { float: right; }
        .file-actions button { margin-left: 5px; padding: 2px 6px; font-size: 10px; background: #333; color: #ccc; border: none; cursor: pointer; }
        .file-actions button:hover { background: #555; }
        .file-actions button.delete { background: #444; }
        .file-actions button.delete:hover { background: #666; }
        .file-actions button.run { background: #555; }
        .file-actions button.run:hover { background: #777; }
        .file-actions button.extract { background: #666; }
        .file-actions button.extract:hover { background: #888; }
        .file-actions button.tar { background: #555; }
        .file-actions button.tar:hover { background: #777; }
        .browse a { color: #ccc; text-decoration: underline; }
        .browse a:hover { color: #fff; }
        .status { background: #111; border: 1px solid #333; padding: 8px; margin: 5px 0; font-size: 12px; text-align: center; }
        .progress { width: 100%; height: 4px; background: #333; margin: 4px 0; }
        .progress-bar { height: 100%; background: #0f0; transition: width 0.3s ease; }
        .upload { border: 1px dashed #333; padding: 10px; margin: 5px 0; text-align: center; font-size: 12px; cursor: pointer; }
        .upload:hover { border-color: #555; }
        .upload.dragover { border-color: #666; background: #111; }
    </style>
</head>
<body>
    <input type="text" id="cmd" placeholder="Command" autofocus>
    <div class="upload" id="upload">📁 Drop file here or click to upload</div>
    <div class="browse" id="browse">
        <div>📂 Files (<a href="#" onclick="refreshFiles()">refresh</a>) | <a href="#" onclick="clearOutput()">clear</a></div>
        <div id="currentPath" style="padding: 4px; font-size: 10px; opacity: 0.7;"></div>
        <div class="file-list" id="fileList"></div>
    </div>
    <div class="status" id="status" style="display: none;">
        <div id="statusText">Ready</div>
        <div class="progress" id="progress">
            <div class="progress-bar" id="progressBar" style="width: 0%;"></div>
        </div>
    </div>
    <div id="out" class="output"></div>
    <script>
        async function run() {
            const cmd = document.getElementById('cmd').value;
            if (!cmd) return;
            
            document.getElementById('out').textContent = '$ ' + cmd + '\\n\\n';
            
            try {
                const r = await fetch('/exec', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ command: cmd })
                });
                const result = await r.json();
                document.getElementById('out').textContent += 
                    (result.stdout || '') + (result.stderr ? '\\nSTDERR:\\n' + result.stderr : '');
            } catch (e) {
                document.getElementById('out').textContent += 'Error: ' + e.message;
            }
            document.getElementById('cmd').value = '';
        }
        
        document.getElementById('cmd').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') run();
        });
        
        const upload = document.getElementById('upload');
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.style.display = 'none';
        document.body.appendChild(fileInput);
        
        upload.addEventListener('click', () => fileInput.click());
        
        upload.addEventListener('dragover', (e) => {
            e.preventDefault();
            upload.classList.add('dragover');
        });
        
        upload.addEventListener('dragleave', () => {
            upload.classList.remove('dragover');
        });
        
        upload.addEventListener('drop', async (e) => {
            e.preventDefault();
            upload.classList.remove('dragover');
            const files = e.dataTransfer.files;
            if (files.length > 0) await uploadFile(files[0]);
        });
        
        fileInput.addEventListener('change', async (e) => {
            if (e.target.files.length > 0) await uploadFile(e.target.files[0]);
        });
        
        function showStatus(text, progress = 0) {
            const statusDiv = document.getElementById('status');
            const statusText = document.getElementById('statusText');
            const progressBar = document.getElementById('progressBar');
            
            statusDiv.style.display = 'block';
            statusText.textContent = text;
            progressBar.style.width = progress + '%';
        }
        
        function hideStatus() {
            document.getElementById('status').style.display = 'none';
        }
        
        async function uploadFile(file) {
            showStatus('Uploading: ' + file.name, 25);
            
            const formData = new FormData();
            formData.append('file', file);
            
            try {
                const r = await fetch('/upload', {
                    method: 'POST',
                    body: formData
                });
                const result = await r.json();
                document.getElementById('out').textContent = '📁 Uploaded: ' + result.filename + ' -> ' + result.path + '\\n\\n';
                refreshFiles();
                hideStatus();
            } catch (e) {
                document.getElementById('out').textContent = '❌ Upload failed: ' + e.message + '\\n\\n';
                hideStatus();
            }
        }
        
        let currentPath = '';
        
        async function refreshFiles(path) {
            try {
                const url = path ? '/browse?path=' + encodeURIComponent(path) : '/browse';
                const r = await fetch(url);
                const data = await r.json();
                const fileList = document.getElementById('fileList');
                const currentPathDiv = document.getElementById('currentPath');
                
                currentPath = data.currentPath || '';
                currentPathDiv.textContent = currentPath || '~';
                
                if (data.error) {
                    fileList.innerHTML = '<div style="padding: 8px; color: #666;">Error: ' + data.error + '</div>';
                    return;
                }
                
                if (!data.files || data.files.length === 0) {
                    fileList.innerHTML = '<div style="padding: 8px; opacity: 0.5;">No files</div>';
                } else {
                    // Add parent directory option if not in root
                    const homeDir = '/home/z'; // This should be dynamic but hardcoded for now
                    let fileItems = '';
                    
                    if (currentPath && currentPath !== homeDir) {
                        const parentPath = currentPath.split('/').slice(0, -1).join('/') || homeDir;
                        fileItems = \`
                            <div class="file-item" onclick="navigateToFolder('\${parentPath}')">
                                📁 ../ (Parent Directory)
                            </div>
                        \`;
                    }
                    
                    // Sort: directories first, then files
                    const sortedFiles = data.files.sort((a, b) => {
                        if (a.isDirectory && !b.isDirectory) return -1;
                        if (!a.isDirectory && b.isDirectory) return 1;
                        return a.name.localeCompare(b.name);
                    });
                    
                    fileItems += sortedFiles.map(file => {
                        const size = (file.size / 1024).toFixed(1) + 'KB';
                        const isExecutable = file.name.endsWith('.sh') || file.name.endsWith('.py') || file.name.endsWith('.js') || file.name.endsWith('.pl') || file.name.endsWith('.rb') || file.name.endsWith('.php') || file.name.endsWith('.bat') || file.name.endsWith('.cmd');
                        const isArchive = file.name.endsWith('.tar.gz') || file.name.endsWith('.tgz') || file.name.endsWith('.tar') || file.name.endsWith('.zip') || file.name.endsWith('.rar') || file.name.endsWith('.7z');
                        
                        let actions = '';
                        let clickAction = '';
                        
                        if (file.isDirectory) {
                            actions = \`<button onclick="event.stopPropagation(); navigateToFolder('\${file.path}/\${file.name}')">Enter</button> <button class="tar" onclick="event.stopPropagation(); tarFolder('\${file.name}')">Tar</button>\`;
                            clickAction = \`navigateToFolder('\${file.path}/\${file.name}')\`;
                        } else {
                            if (!file.isBinary) {
                                actions += \`<button onclick="event.stopPropagation(); viewFile('\${file.name}')">View</button>\`;
                                clickAction = \`viewFile('\${file.name}')\`;
                            } else {
                                clickAction = \`downloadFile('\${file.name}')\`;
                            }
                            if (isExecutable) actions += \`<button class="run" onclick="event.stopPropagation(); runFile('\${file.name}')">Run</button>\`;
                            actions += \`<button onclick="event.stopPropagation(); downloadFile('\${file.name}')">Download</button>\`;
                            if (isArchive) actions += \`<button class="extract" onclick="event.stopPropagation(); extractFile('\${file.name}')">Extract</button>\`;
                            actions += \`<button class="delete" onclick="event.stopPropagation(); deleteFile('\${file.name}')">Delete</button>\`;
                        }
                        
                        const icon = file.isDirectory ? '📁' : '📄';
                        const displayName = file.isDirectory ? file.name + '/' : file.name;
                        const sizeDisplay = file.isDirectory ? '' : \` (\${size})\`;
                        
                        return \`
                            <div class="file-item" onclick="\${clickAction}">
                                \${icon} \${displayName}\${sizeDisplay}
                                <div class="file-actions">
                                    \${actions}
                                </div>
                            </div>
                        \`;
                    }).join('');
                    
                    fileList.innerHTML = fileItems;
                }
            } catch (e) {
                console.error('refreshFiles error:', e);
                document.getElementById('fileList').innerHTML = '<div style="padding: 8px; color: #666;">Error loading files: ' + e.message + '</div>';
            }
        }
        
        function navigateToFolder(path) {
            refreshFiles(path);
        }
        
        function clearOutput() {
            document.getElementById('out').textContent = '';
        }
        
        async function tarFolder(foldername) {
            showStatus('Creating tar archive: ' + foldername, 50);
            
            try {
                const url = currentPath ? '/tar/' + foldername + '?path=' + encodeURIComponent(currentPath) : '/tar/' + foldername;
                const r = await fetch(url, {
                    method: 'POST'
                });
                const result = await r.json();
                
                document.getElementById('out').textContent = '📦 Creating tar archive: ' + foldername + '\\n\\n' + 
                    (result.stdout || '') + (result.stderr ? '\\nSTDERR:\\n' + result.stderr : '') + 
                    '\\nExit code: ' + result.code + '\\n\\n';
                refreshFiles(currentPath);
            } catch (e) {
                document.getElementById('out').textContent = '❌ Tar failed: ' + e.message + '\\n\\n';
            }
            hideStatus();
        }
        
        async function viewFile(filename) {
            try {
                const url = currentPath ? '/view/' + filename + '?path=' + encodeURIComponent(currentPath) : '/view/' + filename;
                const r = await fetch(url);
                const result = await r.json();
                
                if (result.error) {
                    document.getElementById('out').textContent = '📄 ' + filename + ': ' + result.error + '\\n\\n';
                } else {
                    document.getElementById('out').textContent = '📄 ' + filename + ':\\n\\n' + result.content + '\\n\\n';
                }
            } catch (e) {
                document.getElementById('out').textContent = '❌ Failed to view file: ' + e.message + '\\n\\n';
            }
        }
        
        function downloadFile(filename) {
            const url = currentPath ? '/download/' + filename + '?path=' + encodeURIComponent(currentPath) : '/download/' + filename;
            window.open(url, '_blank');
        }
        
        async function deleteFile(filename) {
            showStatus('Deleting: ' + filename, 50);
            
            try {
                const url = currentPath ? '/delete/' + filename + '?path=' + encodeURIComponent(currentPath) : '/delete/' + filename;
                const r = await fetch(url, {
                    method: 'DELETE'
                });
                const result = await r.json();
                
                if (result.success) {
                    document.getElementById('out').textContent = '🗑️ Deleted: ' + filename + '\\n\\n';
                    refreshFiles(currentPath);
                } else {
                    document.getElementById('out').textContent = '❌ Failed to delete: ' + (result.error || 'Unknown error') + '\\n\\n';
                }
                hideStatus();
            } catch (e) {
                document.getElementById('out').textContent = '❌ Delete failed: ' + e.message + '\\n\\n';
                hideStatus();
            }
        }
        
        async function runFile(filename) {
            showStatus('Running: ' + filename, 75);
            
            try {
                const url = currentPath ? '/run/' + filename + '?path=' + encodeURIComponent(currentPath) : '/run/' + filename;
                const r = await fetch(url, {
                    method: 'POST'
                });
                const result = await r.json();
                
                document.getElementById('out').textContent = '🚀 Running: ' + filename + '\\n\\n' + 
                    (result.stdout || '') + (result.stderr ? '\\nSTDERR:\\n' + result.stderr : '') + 
                    '\\nExit code: ' + result.code + '\\n\\n';
                refreshFiles(currentPath);
            } catch (e) {
                document.getElementById('out').textContent = '❌ Run failed: ' + e.message + '\\n\\n';
            }
            hideStatus();
        }
        
        async function extractFile(filename) {
            showStatus('Extracting: ' + filename, 50);
            
            try {
                const url = currentPath ? '/extract/' + filename + '?path=' + encodeURIComponent(currentPath) : '/extract/' + filename;
                const r = await fetch(url, {
                    method: 'POST'
                });
                const result = await r.json();
                
                document.getElementById('out').textContent = '📦 Extracting: ' + filename + '\\n\\n' + 
                    (result.stdout || '') + (result.stderr ? '\\nSTDERR:\\n' + result.stderr : '') + 
                    '\\nExit code: ' + result.code + '\\n\\n';
                refreshFiles(currentPath);
            } catch (e) {
                document.getElementById('out').textContent = '❌ Extract failed: ' + e.message + '\\n\\n';
            }
            hideStatus();
        }
        
        // Load files on page load
        refreshFiles();
    </script>
</body>
</html>`);
});

app.listen(PORT, () => {
  console.log(`Shell running on http://localhost:${PORT}`);
});