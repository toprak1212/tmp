import express from 'express';
import cors from 'cors';
import { spawn, exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs/promises';
import path from 'path';
import multer from 'multer';

const execAsync = promisify(exec);

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Configure multer for file uploads
const upload = multer({ dest: 'uploads/' });

// Utility function to execute shell commands
function executeCommand(command: string, cwd?: string): Promise<any> {
  return new Promise((resolve, reject) => {
    const [cmd, ...args] = command.split(' ');
    const child = spawn(cmd, args, {
      cwd: cwd || process.cwd(),
      stdio: ['pipe', 'pipe', 'pipe'],
      shell: true
    });

    let stdout = '';
    let stderr = '';

    child.stdout?.on('data', (data) => {
      stdout += data.toString();
    });

    child.stderr?.on('data', (data) => {
      stderr += data.toString();
    });

    child.on('close', (code) => {
      resolve({
        exitCode: code,
        stdout: stdout,
        stderr: stderr,
        command: command
      });
    });

    child.on('error', (error) => {
      reject({
        error: error.message,
        command: command
      });
    });

    // Timeout after 30 seconds
    setTimeout(() => {
      child.kill();
      reject({
        error: 'Command timed out after 30 seconds',
        command: command
      });
    }, 30000);
  });
}

// Routes

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', message: 'Web Shell API is running' });
});

// Execute shell command
app.post('/exec', async (req, res) => {
  try {
    const { command, cwd } = req.body;
    
    if (!command) {
      return res.status(400).json({ error: 'Command is required' });
    }

    const result = await executeCommand(command, cwd);
    res.json(result);
  } catch (error: any) {
    res.status(500).json(error);
  }
});

// Read file
app.get('/read', async (req, res) => {
  try {
    const filePath = req.query.path as string;
    
    if (!filePath) {
      return res.status(400).json({ error: 'File path is required' });
    }

    const content = await fs.readFile(filePath, 'utf-8');
    res.json({ path: filePath, content: content });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Write file
app.post('/write', async (req, res) => {
  try {
    const { path: filePath, content } = req.body;
    
    if (!filePath) {
      return res.status(400).json({ error: 'File path is required' });
    }

    await fs.writeFile(filePath, content || '', 'utf-8');
    res.json({ path: filePath, message: 'File written successfully' });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// List directory
app.get('/ls', async (req, res) => {
  try {
    const dirPath = req.query.path as string || process.cwd();
    
    const entries = await fs.readdir(dirPath, { withFileTypes: true });
    const result = entries.map(entry => ({
      name: entry.name,
      isDirectory: entry.isDirectory(),
      isFile: entry.isFile(),
      isSymbolicLink: entry.isSymbolicLink()
    }));

    res.json({ path: dirPath, entries: result });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// File upload
app.post('/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const targetPath = req.body.path || req.file.originalname;
    await fs.rename(req.file.path, targetPath);
    
    res.json({ 
      message: 'File uploaded successfully',
      originalName: req.file.originalname,
      path: targetPath,
      size: req.file.size
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Download file
app.get('/download', async (req, res) => {
  try {
    const filePath = req.query.path as string;
    
    if (!filePath) {
      return res.status(400).json({ error: 'File path is required' });
    }

    const stats = await fs.stat(filePath);
    if (!stats.isFile()) {
      return res.status(400).json({ error: 'Path is not a file' });
    }

    res.download(filePath);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Delete file/directory
app.delete('/delete', async (req, res) => {
  try {
    const { path: filePath } = req.body;
    
    if (!filePath) {
      return res.status(400).json({ error: 'Path is required' });
    }

    const stats = await fs.stat(filePath);
    
    if (stats.isDirectory()) {
      await fs.rmdir(filePath, { recursive: true });
    } else {
      await fs.unlink(filePath);
    }

    res.json({ path: filePath, message: 'Deleted successfully' });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Create directory
app.post('/mkdir', async (req, res) => {
  try {
    const { path: dirPath } = req.body;
    
    if (!dirPath) {
      return res.status(400).json({ error: 'Directory path is required' });
    }

    await fs.mkdir(dirPath, { recursive: true });
    res.json({ path: dirPath, message: 'Directory created successfully' });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Get system info
app.get('/info', async (req, res) => {
  try {
    const os = require('os');
    const info = {
      platform: os.platform(),
      arch: os.arch(),
      hostname: os.hostname(),
      uptime: os.uptime(),
      totalmem: os.totalmem(),
      freemem: os.freemem(),
      cpus: os.cpus(),
      networkInterfaces: os.networkInterfaces(),
      cwd: process.cwd(),
      env: process.env,
      user: os.userInfo()
    };
    
    res.json(info);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Web interface
app.get('/', (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
    <title>Web Shell API</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .section { margin-bottom: 30px; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
        h1, h2 { color: #333; }
        input, textarea, button { padding: 10px; margin: 5px; border: 1px solid #ddd; border-radius: 4px; }
        button { background: #007bff; color: white; cursor: pointer; }
        button:hover { background: #0056b3; }
        .output { background: #f8f9fa; border: 1px solid #e9ecef; padding: 15px; border-radius: 4px; white-space: pre-wrap; font-family: monospace; margin-top: 10px; }
        .error { background: #f8d7da; color: #721c24; }
        .success { background: #d4edda; color: #155724; }
        .file-list { list-style: none; padding: 0; }
        .file-list li { padding: 8px; border-bottom: 1px solid #eee; }
        .file-list li:hover { background: #f8f9fa; }
        .tabs { display: flex; border-bottom: 1px solid #ddd; }
        .tab { padding: 10px 20px; cursor: pointer; border: none; background: #f8f9fa; }
        .tab.active { background: white; border-bottom: 2px solid #007bff; }
        .tab-content { display: none; padding: 20px 0; }
        .tab-content.active { display: block; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🐚 Web Shell API</h1>
        <p>Unrestricted shell access and file management interface</p>
        
        <div class="tabs">
            <button class="tab active" onclick="showTab('shell')">Shell</button>
            <button class="tab" onclick="showTab('files')">Files</button>
            <button class="tab" onclick="showTab('info')">System Info</button>
        </div>

        <div id="shell" class="tab-content active">
            <div class="section">
                <h2>Command Execution</h2>
                <div>
                    <input type="text" id="command" placeholder="Enter command..." style="width: 70%;">
                    <input type="text" id="cwd" placeholder="Working directory (optional)" style="width: 25%;">
                    <button onclick="executeCommand()">Execute</button>
                </div>
                <div id="command-output" class="output"></div>
            </div>
        </div>

        <div id="files" class="tab-content">
            <div class="section">
                <h2>File Management</h2>
                <div>
                    <input type="text" id="filepath" placeholder="File path..." style="width: 50%;">
                    <button onclick="readFile()">Read</button>
                    <button onclick="listFiles()">List Directory</button>
                </div>
                <div id="file-output" class="output"></div>
            </div>

            <div class="section">
                <h3>Write File</h3>
                <div>
                    <input type="text" id="write-path" placeholder="File path..." style="width: 50%;">
                    <button onclick="showWriteArea()">Set Path</button>
                </div>
                <textarea id="write-content" placeholder="File content..." style="width: 100%; height: 200px; display: none;"></textarea>
                <button id="save-btn" onclick="writeFile()" style="display: none;">Save File</button>
            </div>

            <div class="section">
                <h3>Upload File</h3>
                <input type="file" id="upload-file">
                <input type="text" id="upload-path" placeholder="Target path (optional)">
                <button onclick="uploadFile()">Upload</button>
            </div>
        </div>

        <div id="info" class="tab-content">
            <div class="section">
                <h2>System Information</h2>
                <button onclick="getSystemInfo()">Get Info</button>
                <div id="info-output" class="output"></div>
            </div>
        </div>
    </div>

    <script>
        function showTab(tabName) {
            document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            
            event.target.classList.add('active');
            document.getElementById(tabName).classList.add('active');
        }

        async function executeCommand() {
            const command = document.getElementById('command').value;
            const cwd = document.getElementById('cwd').value;
            const output = document.getElementById('command-output');
            
            if (!command) return;
            
            output.textContent = 'Executing...';
            
            try {
                const response = await fetch('/exec', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ command, cwd: cwd || undefined })
                });
                
                const result = await response.json();
                
                if (result.error) {
                    output.className = 'output error';
                    output.textContent = 'Error: ' + result.error;
                } else {
                    output.className = 'output';
                    output.textContent = \`Exit Code: \${result.exitCode}\\n\\nSTDOUT:\\n\${result.stdout}\`;
                    if (result.stderr) {
                        output.textContent += \`\\n\\nSTDERR:\\n\${result.stderr}\`;
                    }
                }
            } catch (error) {
                output.className = 'output error';
                output.textContent = 'Request failed: ' + error.message;
            }
        }

        async function readFile() {
            const path = document.getElementById('filepath').value;
            const output = document.getElementById('file-output');
            
            if (!path) return;
            
            try {
                const response = await fetch('/read?path=' + encodeURIComponent(path));
                const result = await response.json();
                
                if (result.error) {
                    output.className = 'output error';
                    output.textContent = 'Error: ' + result.error;
                } else {
                    output.className = 'output';
                    output.textContent = result.content;
                }
            } catch (error) {
                output.className = 'output error';
                output.textContent = 'Request failed: ' + error.message;
            }
        }

        async function listFiles() {
            const path = document.getElementById('filepath').value || '.';
            const output = document.getElementById('file-output');
            
            try {
                const response = await fetch('/ls?path=' + encodeURIComponent(path));
                const result = await response.json();
                
                if (result.error) {
                    output.className = 'output error';
                    output.textContent = 'Error: ' + result.error;
                } else {
                    output.className = 'output';
                    let html = \`Directory: \${result.path}\\n\\n\`;
                    result.entries.forEach(entry => {
                        const icon = entry.isDirectory ? '📁' : entry.isFile ? '📄' : '🔗';
                        html += \`\${icon} \${entry.name}\\n\`;
                    });
                    output.textContent = html;
                }
            } catch (error) {
                output.className = 'output error';
                output.textContent = 'Request failed: ' + error.message;
            }
        }

        function showWriteArea() {
            const path = document.getElementById('write-path').value;
            if (!path) return;
            
            document.getElementById('write-content').style.display = 'block';
            document.getElementById('save-btn').style.display = 'inline-block';
        }

        async function writeFile() {
            const path = document.getElementById('write-path').value;
            const content = document.getElementById('write-content').value;
            const output = document.getElementById('file-output');
            
            if (!path) return;
            
            try {
                const response = await fetch('/write', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ path, content })
                });
                
                const result = await response.json();
                
                if (result.error) {
                    output.className = 'output error';
                    output.textContent = 'Error: ' + result.error;
                } else {
                    output.className = 'output success';
                    output.textContent = 'File written successfully: ' + result.path;
                }
            } catch (error) {
                output.className = 'output error';
                output.textContent = 'Request failed: ' + error.message;
            }
        }

        async function uploadFile() {
            const fileInput = document.getElementById('upload-file');
            const path = document.getElementById('upload-path').value;
            const output = document.getElementById('file-output');
            
            if (!fileInput.files[0]) return;
            
            const formData = new FormData();
            formData.append('file', fileInput.files[0]);
            if (path) formData.append('path', path);
            
            try {
                const response = await fetch('/upload', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.error) {
                    output.className = 'output error';
                    output.textContent = 'Error: ' + result.error;
                } else {
                    output.className = 'output success';
                    output.textContent = \`Uploaded: \${result.originalName} -> \${result.path} (\${result.size} bytes)\`;
                }
            } catch (error) {
                output.className = 'output error';
                output.textContent = 'Request failed: ' + error.message;
            }
        }

        async function getSystemInfo() {
            const output = document.getElementById('info-output');
            output.textContent = 'Loading...';
            
            try {
                const response = await fetch('/info');
                const info = await response.json();
                
                output.className = 'output';
                output.textContent = JSON.stringify(info, null, 2);
            } catch (error) {
                output.className = 'output error';
                output.textContent = 'Request failed: ' + error.message;
            }
        }

        // Keyboard shortcuts
        document.getElementById('command').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') executeCommand();
        });
    </script>
</body>
</html>
  `);
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Web Shell API running on http://localhost:${PORT}`);
  console.log(`📁 Web interface: http://localhost:${PORT}`);
  console.log(`⚠️  WARNING: This is an unrestricted shell interface with full system access!`);
});

export default app;