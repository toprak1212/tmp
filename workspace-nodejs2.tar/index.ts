import express from 'express';
import cors from 'cors';
import { spawn } from 'child_process';

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Utility function to execute shell commands
function executeCommand(command: string, cwd?: string): Promise<any> {
  return new Promise((resolve, reject) => {
    const [cmd, ...args] = command.split(' ');
    const child = spawn(cmd, args, {
      cwd: cwd || process.cwd(),
      stdio: ['pipe', 'pipe', 'pipe'],
      shell: true
    });

    let stdout = '';
    let stderr = '';

    child.stdout?.on('data', (data) => {
      stdout += data.toString();
    });

    child.stderr?.on('data', (data) => {
      stderr += data.toString();
    });

    child.on('close', (code) => {
      resolve({
        exitCode: code,
        stdout: stdout,
        stderr: stderr,
        command: command
      });
    });

    child.on('error', (error) => {
      reject({
        error: error.message,
        command: command
      });
    });

    // Timeout after 30 seconds
    setTimeout(() => {
      child.kill();
      reject({
        error: 'Command timed out after 30 seconds',
        command: command
      });
    }, 30000);
  });
}

// Routes

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', message: 'Command Execution API is running' });
});

// Execute shell command
app.post('/exec', async (req, res) => {
  try {
    const { command, cwd } = req.body;
    
    if (!command) {
      return res.status(400).json({ error: 'Command is required' });
    }

    const result = await executeCommand(command, cwd);
    res.json(result);
  } catch (error: any) {
    res.status(500).json(error);
  }
});

// Web interface
app.get('/', (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
    <title>Command Execution API</title>
    <style>
        body { 
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace; 
            margin: 0; 
            padding: 20px; 
            background: #1a1a1a; 
            color: #00ff00; 
        }
        .container { 
            max-width: 1000px; 
            margin: 0 auto; 
            background: #000; 
            padding: 20px; 
            border-radius: 8px; 
            border: 1px solid #333;
            box-shadow: 0 0 20px rgba(0, 255, 0, 0.1); 
        }
        h1 { 
            color: #00ff00; 
            text-align: center; 
            margin-bottom: 30px;
            text-shadow: 0 0 10px rgba(0, 255, 0, 0.5);
        }
        .input-section { 
            margin-bottom: 20px; 
            display: flex; 
            gap: 10px; 
            align-items: center;
        }
        input { 
            padding: 12px; 
            border: 1px solid #333; 
            border-radius: 4px; 
            background: #111; 
            color: #00ff00;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            flex: 1;
        }
        input:focus {
            outline: none;
            border-color: #00ff00;
            box-shadow: 0 0 5px rgba(0, 255, 0, 0.3);
        }
        button { 
            padding: 12px 24px; 
            background: #00ff00; 
            color: #000; 
            border: none; 
            border-radius: 4px; 
            cursor: pointer; 
            font-weight: bold;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            transition: all 0.3s ease;
        }
        button:hover { 
            background: #00cc00; 
            box-shadow: 0 0 10px rgba(0, 255, 0, 0.5);
        }
        button:active {
            transform: translateY(1px);
        }
        .output { 
            background: #000; 
            border: 1px solid #333; 
            padding: 20px; 
            border-radius: 4px; 
            white-space: pre-wrap; 
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace; 
            font-size: 12px;
            margin-top: 20px;
            min-height: 500px;
            max-height: 600px;
            overflow-y: auto;
        }
        .error { 
            color: #ff4444; 
            border-color: #ff4444;
        }
        .success { 
            color: #44ff44; 
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            opacity: 0.8;
        }
        .command-prompt {
            color: #ffff00;
            margin-right: 8px;
        }
        ::-webkit-scrollbar {
            width: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #111;
        }
        ::-webkit-scrollbar-thumb {
            background: #333;
            border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        .status {
            text-align: center;
            margin-bottom: 20px;
            font-size: 14px;
            opacity: 0.7;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="input-section">
            <span class="command-prompt">$</span>
            <input type="text" id="command" placeholder="Enter command..." autofocus>
            <input type="text" id="cwd" placeholder="Working directory (optional)" style="width: 300px;">
            <button onclick="executeCommand()">Execute</button>
        </div>
        
        <div id="output" class="output"></div>
    </div>

    <script>
        let commandHistory = [];
        let historyIndex = -1;

        async function executeCommand() {
            const command = document.getElementById('command').value;
            const cwd = document.getElementById('cwd').value;
            const output = document.getElementById('output');
            
            if (!command) return;
            
            // Add to history
            commandHistory.push(command);
            historyIndex = commandHistory.length;
            
            output.className = 'output';
            output.textContent = \`$ \${command}\`;
            if (cwd) {
                output.textContent += \` (in \${cwd})\`;
            }
            output.textContent += '\\n\\n';
            
            try {
                const response = await fetch('/exec', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ command, cwd: cwd || undefined })
                });
                
                const result = await response.json();
                
                if (result.error) {
                    output.className = 'output error';
                    output.textContent += '❌ Error: ' + result.error;
                } else {
                    output.className = 'output success';
                    output.textContent += '✅ Exit Code: ' + result.exitCode + '\\n\\n';
                    
                    if (result.stdout) {
                        output.textContent += '📤 STDOUT:\\n' + result.stdout;
                    }
                    
                    if (result.stderr) {
                        output.textContent += '\\n📥 STDERR:\\n' + result.stderr;
                    }
                }
            } catch (error) {
                output.className = 'output error';
                output.textContent += '❌ Request failed: ' + error.message;
            }
            
            // Clear command input
            document.getElementById('command').value = '';
        }

        // Keyboard shortcuts
        document.getElementById('command').addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                executeCommand();
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                if (historyIndex > 0) {
                    historyIndex--;
                    this.value = commandHistory[historyIndex];
                }
            } else if (e.key === 'ArrowDown') {
                e.preventDefault();
                if (historyIndex < commandHistory.length - 1) {
                    historyIndex++;
                    this.value = commandHistory[historyIndex];
                } else {
                    historyIndex = commandHistory.length;
                    this.value = '';
                }
            }
        });

        // Focus on command input
        document.getElementById('command').focus();
    </script>
</body>
</html>
  `);
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Command Execution API running on http://localhost:${PORT}`);
  console.log(`📁 Web interface: http://localhost:${PORT}`);
  console.log(`⚠️  WARNING: This is an unrestricted shell interface with full system access!`);
});

export default app;